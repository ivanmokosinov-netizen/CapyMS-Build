extends RefCounted
## Shared 3D world helpers: sky/environment, sun, materials, colliders.

static func environment(parent: Node, top: Color, horizon: Color, ground: Color, opts := {}) -> Environment:
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = top
    sm.sky_horizon_color = horizon
    sm.ground_bottom_color = ground
    sm.ground_horizon_color = horizon
    sm.sky_curve = opts.get("curve", 0.12)
    sm.ground_curve = 0.04
    sm.sun_angle_max = 30.0
    sky.sky_material = sm
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_sky_contribution = opts.get("sky_contrib", 1.0)
    env.ambient_light_color = opts.get("amb_color", Color(1, 1, 1))
    env.ambient_light_energy = opts.get("ambient", 1.0)
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.tonemap_exposure = opts.get("exposure", 1.05)
    env.tonemap_white = opts.get("white", 1.6)
    # SSAO is unavailable in the Compatibility renderer.
    var compat := str(ProjectSettings.get_setting("rendering/renderer/rendering_method", "gl_compatibility")) == "gl_compatibility"
    var mobile_look := OS.has_feature("mobile") or Game.force_touch
    env.ssao_enabled = opts.get("ssao", true) and not compat
    env.ssao_radius = 1.0
    env.ssao_intensity = 1.6
    env.ssao_power = 1.4
    env.glow_enabled = true
    env.glow_intensity = opts.get("glow", 0.35)
    env.glow_strength = 0.9
    env.glow_bloom = 0.03
    env.glow_hdr_threshold = 1.1
    env.adjustment_enabled = true
    env.adjustment_saturation = opts.get("sat", 1.12)
    env.adjustment_contrast = opts.get("contrast", 1.04)
    env.adjustment_brightness = opts.get("bright", 1.0)
    if mobile_look and not opts.get("original_mobile_look", false):
        # Prevent overexposed highlights and keep warm directional modelling.
        env.ambient_light_energy *= float(opts.get("mobile_ambient_scale", 0.70))
        env.tonemap_exposure *= float(opts.get("mobile_exposure_scale", 0.78))
        env.adjustment_saturation = float(opts.get("mobile_sat", 1.06))
        env.adjustment_contrast = float(opts.get("mobile_contrast", 1.12))
        env.adjustment_brightness = float(opts.get("mobile_bright", 0.96))
        env.glow_intensity *= 0.7
        env.glow_bloom = float(opts.get("mobile_bloom", 0.0))
    if opts.has("fog"):
        env.fog_enabled = true
        env.fog_light_color = opts.fog
        env.fog_density = opts.get("fog_density", 0.006)
        env.fog_sky_affect = opts.get("fog_sky", 0.25)
        env.fog_aerial_perspective = 0.2
    var we := WorldEnvironment.new()
    we.environment = env
    parent.add_child(we)
    return env

static func sun(parent: Node, rot_deg: Vector3, energy := 1.2, color := Color(1.0, 0.96, 0.9), shadow_dist := 80.0, original_mobile_look := false) -> DirectionalLight3D:
    var l := DirectionalLight3D.new()
    l.rotation_degrees = rot_deg
    var mobile_look := OS.has_feature("mobile") or Game.force_touch
    l.light_energy = energy * (0.88 if mobile_look and not original_mobile_look else 1.0)
    l.light_color = color
    l.shadow_enabled = true
    l.shadow_bias = 0.04
    l.shadow_normal_bias = 1.2
    l.shadow_blur = 1.2
    l.directional_shadow_max_distance = minf(shadow_dist, 65.0) if mobile_look else shadow_dist
    l.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
    l.directional_shadow_blend_splits = true
    parent.add_child(l)
    return l

static func mat(color: Color, rough := 0.85, metal := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = metal
    return m

static func tex_mat(tex: Texture2D, uv_scale := Vector3.ONE, tint := Color.WHITE, rough := 0.9) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_texture = tex
    m.albedo_color = tint
    m.uv1_scale = uv_scale
    m.roughness = rough
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    return m

static func mesh_box(parent: Node, size: Vector3, pos: Vector3, material: Material, rot_y := 0.0, shadows := true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    bm.material = material
    mi.mesh = bm
    mi.position = pos
    mi.rotation.y = rot_y
    if not shadows:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi

static func plane(parent: Node, size: Vector2, pos: Vector3, material: Material) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = size
    pm.material = material
    mi.mesh = pm
    mi.position = pos
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    return mi

static func static_body(parent: Node, layer := 1, bounce := 0.0, friction := 1.0) -> StaticBody3D:
    var sb := StaticBody3D.new()
    sb.collision_layer = layer
    sb.collision_mask = 0
    if bounce > 0.0 or friction != 1.0:
        var pm := PhysicsMaterial.new()
        pm.bounce = bounce
        pm.friction = friction
        sb.physics_material_override = pm
    parent.add_child(sb)
    return sb

static func box_shape(body: Node, size: Vector3, pos: Vector3, rot_y := 0.0) -> CollisionShape3D:
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    cs.position = pos
    cs.rotation.y = rot_y
    body.add_child(cs)
    return cs

static func cyl_shape(body: Node, radius: float, height: float, pos: Vector3) -> CollisionShape3D:
    var cs := CollisionShape3D.new()
    var c := CylinderShape3D.new()
    c.radius = radius
    c.height = height
    cs.shape = c
    cs.position = pos
    body.add_child(cs)
    return cs

## Recolour every surface that uses material `mat_name` inside `node`.
static func recolor(node: Node, mat_name: String, color: Color) -> void:
    if node is MeshInstance3D and node.mesh:
        var mi: MeshInstance3D = node
        for i in mi.mesh.get_surface_count():
            var m: Material = mi.mesh.surface_get_material(i)
            if m and m.resource_name == mat_name and m is BaseMaterial3D:
                var nm: BaseMaterial3D = m.duplicate()
                nm.albedo_color = color
                mi.set_surface_override_material(i, nm)
    for c in node.get_children():
        recolor(c, mat_name, color)

# Deeper, natural vegetation palette, using overrides without changing shared assets.
static func mature_island(node: Node) -> void:
    recolor(node, "IslandGrass", Color("225837"))
    recolor(node, "IslandGrassSide", Color("1c4930"))
    recolor(node, "IslandDirt", Color("654936"))
    recolor(node, "IslandDirtDark", Color("46372d"))

static func mature_tree(node: Node) -> void:
    recolor(node, "Leaf", Color("285f40"))
    recolor(node, "LeafDark", Color("1b4934"))
    recolor(node, "LeafLight", Color("35724a"))

static func set_shadows(node: Node, on: bool) -> void:
    if node is GeometryInstance3D:
        (node as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if on else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for c in node.get_children():
        set_shadows(c, on)
