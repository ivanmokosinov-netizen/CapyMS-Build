extends Control
## Multi-touch controls for landscape play. Each finger owns at most one control.
signal jump
signal kick
signal pass_ball
var football := false
var move := Vector2.ZERO
var sprint := false
var jump_held := false
var stick_id := -1
var finger_actions := {}
var knob := Vector2.ZERO
var playing := true
const R := 70.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    process_mode = Node.PROCESS_MODE_ALWAYS
    queue_redraw()

func _stick_center() -> Vector2:
    return Vector2(150, size.y - 145)

func _buttons() -> Dictionary:
    if football:
        return {"jump": Vector2(size.x - 110, size.y - 278), "kick": Vector2(size.x - 105, size.y - 130), "pass": Vector2(size.x - 240, size.y - 210), "sprint": Vector2(size.x - 270, size.y - 70)}
    return {"jump": Vector2(size.x - 115, size.y - 145), "sprint": Vector2(size.x - 245, size.y - 105)}

func reset_controls() -> void:
    stick_id = -1
    finger_actions.clear()
    move = Vector2.ZERO
    knob = Vector2.ZERO
    sprint = false
    jump_held = false
    queue_redraw()

func set_playing(value: bool) -> void:
    if playing != value:
        playing = value
        visible = value
        if not value: reset_controls()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        reset_controls()

func _input(event: InputEvent) -> void:
    if not playing or get_tree().paused:
        return
    if event is InputEventScreenTouch:
        var p: Vector2 = get_global_transform_with_canvas().affine_inverse() * event.position
        if event.pressed:
            for action in _buttons():
                if p.distance_to(_buttons()[action]) <= R:
                    finger_actions[event.index] = action
                    _refresh_buttons()
                    match action:
                        "jump": jump.emit()
                        "kick": kick.emit()
                        "pass": pass_ball.emit()
                    get_viewport().set_input_as_handled()
                    queue_redraw()
                    return
            if stick_id == -1 and p.distance_to(_stick_center()) <= 125.0:
                stick_id = event.index
                _set_stick(p)
                get_viewport().set_input_as_handled()
        else:
            if event.index == stick_id:
                stick_id = -1
                move = Vector2.ZERO
                knob = Vector2.ZERO
                get_viewport().set_input_as_handled()
                queue_redraw()
            elif finger_actions.has(event.index):
                finger_actions.erase(event.index)
                _refresh_buttons()
                get_viewport().set_input_as_handled()
                queue_redraw()
    elif event is InputEventScreenDrag:
        if event.index == stick_id:
            var p: Vector2 = get_global_transform_with_canvas().affine_inverse() * event.position
            _set_stick(p)
            get_viewport().set_input_as_handled()
        elif finger_actions.has(event.index):
            get_viewport().set_input_as_handled()

func _set_stick(p: Vector2) -> void:
    knob = (p - _stick_center()).limit_length(75.0)
    move = knob / 75.0
    if move.length() < 0.12: move = Vector2.ZERO
    queue_redraw()

func _refresh_buttons() -> void:
    sprint = finger_actions.values().has("sprint")
    jump_held = finger_actions.values().has("jump")

func _draw() -> void:
    var c := _stick_center()
    draw_circle(c + Vector2(0, 7), 94, Color(0.08, 0.09, 0.16, 0.32))
    draw_circle(c, 92, Color(0.10, 0.16, 0.29, 0.55))
    draw_arc(c, 92, 0, TAU, 48, Color.BLACK, 4, true)
    draw_arc(c, 88, 0, TAU, 48, Color(1, 1, 1, 0.5), 2, true)
    draw_circle(c + knob, 43, Color(0.34, 0.53, 0.60, 0.88))
    draw_arc(c + knob, 43, 0, TAU, 36, Color.BLACK, 3, true)
    draw_arc(c + knob, 39, 0, TAU, 36, Color(1, 1, 1, 0.8), 2, true)
    var colors := {"jump": Color("487990"), "sprint": Color("ac823e"), "kick": Color("a55c50"), "pass": Color("427a61")}
    var ru := {"jump":"ПРЫЖОК", "sprint":"БЕГ", "kick":"УДАР", "pass":"ПАС"}
    var en := {"jump":"JUMP", "sprint":"RUN", "kick":"KICK", "pass":"PASS"}
    for action in _buttons():
        var pos: Vector2 = _buttons()[action]
        var active := finger_actions.values().has(action)
        var col: Color = colors[action]
        draw_circle(pos + Vector2(0, 6), R, Color(0.05, 0.08, 0.16, 0.4))
        col.a = 0.92 if active else 0.75
        draw_circle(pos, R, col)
        draw_arc(pos, R, 0, TAU, 40, Color.BLACK, 4, true)
        draw_arc(pos, R - 5, 0, TAU, 40, Color(1,1,1,0.75), 2, true)
        var text: String = ru[action] if Game.lang == "ru" else en[action]
        var font: Font = Game.FONT_BLACK
        var fs := 19 if action == "jump" else 22
        var w := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
        draw_string_outline(font, pos + Vector2(-w/2, 8), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 3, Color.BLACK)
        draw_string(font, pos + Vector2(-w/2, 8), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE)
