extends RefCounted
## CapyMS particle & juice helpers (CPU particles so it runs everywhere).

const GLOW := preload("res://assets/textures/glow.png")
const CONFETTI_COLORS := [Color("f2c037"), Color("d84e6c"), Color("3f8fe0"), Color("77ab60"), Color("a05ed8"), Color("ffffff"), Color("df894d")]

static func _mat(unshaded := true, glow := false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.vertex_color_use_as_albedo = true
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    if unshaded:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    if glow:
        m.albedo_texture = GLOW
        m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    return m

static func _fade_ramp(c: Color) -> Gradient:
    var g := Gradient.new()
    g.set_color(0, Color(c.r, c.g, c.b, 1.0))
    g.set_color(1, Color(c.r, c.g, c.b, 0.0))
    return g

static func _emit(parent: Node, p: CPUParticles3D, pos: Vector3, life := 2.0) -> CPUParticles3D:
    p.one_shot = true
    p.explosiveness = 1.0
    p.emitting = true
    parent.add_child(p)
    p.global_position = pos
    p.restart()
    var tm := parent.get_tree().create_timer(p.lifetime + life, false)
    tm.timeout.connect(func():
        if is_instance_valid(p):
            p.queue_free())
    return p

## Little cubes flying out (hits, pickups).
static func burst(parent: Node, pos: Vector3, color: Color, amount := 16, speed := 5.0, size := 0.14, grav := -14.0) -> void:
    var p := CPUParticles3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3.ONE * size
    bm.material = _mat(false)
    p.mesh = bm
    p.amount = amount
    p.lifetime = 0.8
    p.direction = Vector3.UP
    p.spread = 70.0
    p.initial_velocity_min = speed * 0.5
    p.initial_velocity_max = speed
    p.gravity = Vector3(0, grav, 0)
    p.angular_velocity_min = -360.0
    p.angular_velocity_max = 360.0
    p.scale_amount_min = 0.6
    p.scale_amount_max = 1.2
    p.color_ramp = _fade_ramp(color)
    _emit(parent, p, pos)

## Soft glowing sparks (coins, power-ups, chest).
static func sparkle(parent: Node, pos: Vector3, color: Color, amount := 18, speed := 3.5, size := 0.35) -> void:
    var p := CPUParticles3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2.ONE * size
    qm.material = _mat(true, true)
    p.mesh = qm
    p.amount = amount
    p.lifetime = 0.7
    p.direction = Vector3.UP
    p.spread = 180.0
    p.initial_velocity_min = speed * 0.4
    p.initial_velocity_max = speed
    p.gravity = Vector3(0, -2.0, 0)
    p.damping_min = 2.0
    p.damping_max = 4.0
    p.scale_amount_min = 0.5
    p.scale_amount_max = 1.2
    p.color_ramp = _fade_ramp(color)
    _emit(parent, p, pos)

## Dust / smoke puff (landing, zombie infection).
static func puff(parent: Node, pos: Vector3, color := Color(0.95, 0.92, 0.85), amount := 10, size := 0.45, speed := 1.8) -> void:
    var p := CPUParticles3D.new()
    var sm := SphereMesh.new()
    sm.radius = size * 0.5
    sm.height = size
    sm.radial_segments = 8
    sm.rings = 4
    sm.material = _mat(false)
    p.mesh = sm
    p.amount = amount
    p.lifetime = 0.7
    p.direction = Vector3.UP
    p.spread = 85.0
    p.initial_velocity_min = speed * 0.5
    p.initial_velocity_max = speed
    p.gravity = Vector3(0, 0.6, 0)
    p.damping_min = 2.5
    p.damping_max = 4.0
    var c := Curve.new()
    c.add_point(Vector2(0, 0.5))
    c.add_point(Vector2(0.3, 1.0))
    c.add_point(Vector2(1, 0.2))
    p.scale_amount_curve = c
    var g := Gradient.new()
    g.set_color(0, Color(color.r, color.g, color.b, 0.85))
    g.set_color(1, Color(color.r, color.g, color.b, 0.0))
    p.color_ramp = g
    _emit(parent, p, pos)

## Colourful confetti rain.
static func confetti(parent: Node, pos: Vector3, amount := 90, spread_box := Vector3(3, 0.5, 3), speed := 9.0) -> void:
    var p := CPUParticles3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(0.16, 0.1)
    var m := _mat(false)
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    qm.material = m
    p.mesh = qm
    p.amount = amount
    p.lifetime = 3.0
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    p.emission_box_extents = spread_box
    p.direction = Vector3.UP
    p.spread = 35.0
    p.initial_velocity_min = speed * 0.6
    p.initial_velocity_max = speed
    p.gravity = Vector3(0, -6.0, 0)
    p.damping_min = 1.0
    p.damping_max = 2.0
    p.angular_velocity_min = -540.0
    p.angular_velocity_max = 540.0
    p.particle_flag_rotate_y = true
    var g := Gradient.new()
    g.offsets = PackedFloat32Array([0.0])
    g.colors = PackedColorArray([CONFETTI_COLORS[0]])
    for i in range(1, CONFETTI_COLORS.size()):
        g.add_point(float(i) / float(CONFETTI_COLORS.size() - 1), CONFETTI_COLORS[i])
    g.interpolation_mode = Gradient.GRADIENT_INTERPOLATE_CONSTANT
    p.color_initial_ramp = g
    _emit(parent, p, pos, 1.0)

## Expanding flat ring (pickup shock-wave).
static func ring(parent: Node, pos: Vector3, color: Color, max_scale := 3.0, dur := 0.45) -> void:
    var mi := MeshInstance3D.new()
    var tm := TorusMesh.new()
    tm.inner_radius = 0.42
    tm.outer_radius = 0.5
    tm.rings = 24
    tm.ring_segments = 8
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.albedo_color = color
    tm.material = m
    mi.mesh = tm
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)
    mi.global_position = pos
    mi.scale = Vector3(0.3, 0.3, 0.3)
    var tw := mi.create_tween().set_parallel(true)
    tw.tween_property(mi, "scale", Vector3(max_scale, 0.4, max_scale), dur).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
    tw.tween_property(m, "albedo_color:a", 0.0, dur)
    tw.chain().tween_callback(mi.queue_free)

## Floating 3D text ("+1", "GOAL!" ...).
static func float_text(parent: Node, pos: Vector3, text: String, color := Color.WHITE, size := 64, rise := 1.6, dur := 0.9) -> void:
    var l := Label3D.new()
    l.text = text
    l.font = preload("res://assets/fonts/Rubik-Black.ttf")
    l.font_size = size
    l.outline_size = 14
    l.modulate = color
    l.outline_modulate = Color(0.15, 0.15, 0.3, 1)
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.no_depth_test = true
    l.pixel_size = 0.01
    parent.add_child(l)
    l.global_position = pos
    l.scale = Vector3.ONE * 0.4
    var tw := l.create_tween().set_parallel(true)
    tw.tween_property(l, "scale", Vector3.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(l, "global_position", pos + Vector3(0, rise, 0), dur).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
    tw.tween_property(l, "modulate:a", 0.0, dur * 0.4).set_delay(dur * 0.6)
    tw.tween_property(l, "outline_modulate:a", 0.0, dur * 0.4).set_delay(dur * 0.6)
    tw.chain().tween_callback(l.queue_free)
