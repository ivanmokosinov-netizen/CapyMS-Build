extends CharacterBody3D
## Capybara character controller shared by the player and all bots.
## Feed it move_input / sprint_input / jump_pressed; it handles physics.

const CapyModel := preload("res://scripts/capy_model.gd")

signal jumped
signal landed(impact: float)

var model: Node3D
var is_player := false
var team := 0
var display_name := "Capy"
var ai := {}

var move_input := Vector3.ZERO
var sprint_input := false
var jump_pressed := false
var jump_held := false

var speed := 6.4
var sprint_mult := 1.55
var accel := 42.0
var decel := 30.0
var air_accel := 16.0
var gravity_up := 23.0
var gravity_down := 34.0
var jump_velocity := 9.0
var turn_speed := 15.0

var stamina := 1.0
var stamina_drain := 0.36
var stamina_regen := 0.24
var exhausted := false
var sprinting := false

var coyote := 0.0
var jump_buffer := 0.0
var was_on_floor := true
var fall_speed := 0.0
var stun := 0.0
var frozen := false
var speed_mult := 1.0
var facing := Vector3(0, 0, -1)
var kick_cd := 0.0
var step_sounds := false
var _step_t := 0.0

func _init() -> void:
    collision_layer = 2
    collision_mask = 1
    var shape := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.45
    cap.height = 1.25
    shape.shape = cap
    shape.position = Vector3(0, 0.625, 0)
    add_child(shape)
    model = CapyModel.new()
    add_child(model)
    floor_snap_length = 0.25
    floor_max_angle = deg_to_rad(50.0)

func set_skin(id: String) -> void:
    model.apply_skin(id)

func set_nametag(nickname: String, color := Color.WHITE, height := 2.1) -> void:
    var tag := Label3D.new()
    tag.name = "NameTag"
    tag.text = nickname
    tag.font = preload("res://assets/fonts/Rubik-Black.ttf")
    tag.font_size = 48
    tag.pixel_size = 0.006
    tag.modulate = color
    tag.outline_modulate = Color("162334")
    tag.outline_size = 10
    tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    tag.position.y = height
    add_child(tag)

func face(dir: Vector3) -> void:
    dir.y = 0.0
    if dir.length() > 0.01:
        rotation.y = atan2(-dir.x, -dir.z)
        facing = dir.normalized()

func knockback(v: Vector3, stun_time := 0.35) -> void:
    velocity += v
    stun = maxf(stun, stun_time)

func teleport(p: Vector3, look_dir := Vector3.ZERO) -> void:
    global_position = p
    velocity = Vector3.ZERO
    if look_dir != Vector3.ZERO:
        face(look_dir)

func _physics_process(delta: float) -> void:
    var on_floor := is_on_floor()
    if on_floor:
        coyote = 0.12
    else:
        coyote -= delta
    if jump_pressed:
        jump_buffer = 0.16
        jump_pressed = false
    else:
        jump_buffer -= delta
    kick_cd -= delta

    var inp := move_input
    inp.y = 0.0
    if inp.length() > 1.0:
        inp = inp.normalized()
    if frozen:
        inp = Vector3.ZERO
    # stamina / sprint
    sprinting = sprint_input and inp.length() > 0.3 and not exhausted and not frozen
    if sprinting:
        stamina = maxf(0.0, stamina - stamina_drain * delta)
        if stamina <= 0.0:
            exhausted = true
            sprinting = false
    else:
        stamina = minf(1.0, stamina + stamina_regen * delta)
        if exhausted and stamina > 0.35:
            exhausted = false
    var a: float
    if stun > 0.0:
        stun -= delta
        inp *= 0.15
        a = 7.0
    elif on_floor:
        a = accel if inp.length() > 0.05 else decel
    else:
        a = air_accel
    var target_speed := speed * speed_mult * (sprint_mult if sprinting else 1.0)
    var hv := Vector3(velocity.x, 0.0, velocity.z)
    hv = hv.move_toward(inp * target_speed, a * delta)
    velocity.x = hv.x
    velocity.z = hv.z
    # jump
    if jump_buffer > 0.0 and coyote > 0.0 and not frozen and stun <= 0.0:
        velocity.y = jump_velocity
        jump_buffer = 0.0
        coyote = 0.0
        on_floor = false
        model.do_jump()
        jumped.emit()
    if not on_floor:
        var g := gravity_up if velocity.y > 0.0 else gravity_down
        if velocity.y > 0.0 and not jump_held:
            g *= 1.7
        velocity.y -= g * delta
    fall_speed = velocity.y
    move_and_slide()
    var now_floor := is_on_floor()
    if now_floor and not was_on_floor:
        var impact := clampf(-fall_speed / 12.0, 0.0, 1.2)
        model.do_land(impact)
        landed.emit(impact)
    was_on_floor = now_floor
    # facing
    if inp.length() > 0.08:
        var target_yaw := atan2(-inp.x, -inp.z)
        rotation.y = lerp_angle(rotation.y, target_yaw, 1.0 - exp(-turn_speed * delta))
    facing = -global_transform.basis.z
    facing.y = 0.0
    facing = facing.normalized()
    # animation params
    model.move_amount = hv.length() / maxf(speed, 0.1)
    model.on_ground = now_floor
    model.vert_speed = velocity.y
    # footsteps
    if step_sounds and now_floor and hv.length() > 1.0:
        _step_t -= delta * hv.length()
        if _step_t <= 0.0:
            _step_t = 1.6
            Game.sfx("step", -16.0, randf_range(0.85, 1.2))
