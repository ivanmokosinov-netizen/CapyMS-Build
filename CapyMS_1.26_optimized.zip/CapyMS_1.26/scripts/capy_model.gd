extends Node3D
## Visual capybara: instances the Blender model, applies skins and
## animates it procedurally (trot cycle, jump pose, squash & stretch, ears).

const CAPY_SCENE := preload("res://assets/models/capy.glb")
const ACCS := ["Acc_Crown", "Acc_Glasses", "Acc_Cap", "Acc_Party", "Acc_Headphones", "Acc_Ninja",
    "Acc_Hood", "Acc_Pirate", "Acc_Gentleman", "Acc_HoodieBody", "Acc_Scarf"]

var root: Node3D
var body: Node3D
var head: Node3D
var ear_l: Node3D
var ear_r: Node3D
var legs: Array = []
var acc := {}
var base_pos := {}
var base_rot := {}
var surfaces: Array = []
var surfaces_by_name := {}
static var _variant_cache: Dictionary = {}
var meshes: Array = []
var skin_id := ""

# animation inputs (set by the controller)
var move_amount := 0.0
var on_ground := true
var vert_speed := 0.0
var head_yaw := 0.0
var happy := false

var t := 0.0
var phase := 0.0
var squash := 0.0
var squash_v := 0.0
var kick_t := -1.0
var ear_twitch := 0.0
var next_twitch := 2.0
var hop := 0.0
var spin := 0.0
var _flash_mat: StandardMaterial3D
var _xray_mat: ShaderMaterial
static var _xray_shader: Shader
var _sparkles: CPUParticles3D

## See-through silhouette: drawn only where the capybara is hidden behind
## something (cars, trees...), so the player never loses sight of it.
const XRAY_CODE := """
shader_type spatial;
render_mode unshaded, depth_test_disabled, depth_draw_never, cull_back;
uniform vec4 color : source_color = vec4(1.0, 0.86, 0.3, 0.6);
uniform float min_gap = 1.25;
uniform sampler2D depth_tex : hint_depth_texture, filter_nearest;
void fragment() {
    float d = texture(depth_tex, SCREEN_UV).r;
    vec4 v = INV_PROJECTION_MATRIX * vec4(SCREEN_UV * 2.0 - 1.0, d, 1.0);
    float scene_z = -v.z / v.w;
    if (scene_z > -VERTEX.z - min_gap) {
        discard;
    }
    float rim = 1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0);
    ALBEDO = color.rgb;
    ALPHA = color.a * (0.6 + 0.4 * rim);
}
"""

func _init() -> void:
    root = CAPY_SCENE.instantiate()
    add_child(root)
    body = root.find_child("Body", true, false)
    head = root.find_child("Head", true, false)
    ear_l = root.find_child("EarL", true, false)
    ear_r = root.find_child("EarR", true, false)
    for n in ["LegFL", "LegFR", "LegBL", "LegBR"]:
        legs.append(root.find_child(n, true, false))
    for a in ACCS:
        acc[a] = root.find_child(a, true, false)
    for n in [body, head, ear_l, ear_r] + legs:
        if n:
            base_pos[n] = n.position
            base_rot[n] = n.rotation
    _collect(root)
    phase = randf() * TAU
    t = randf() * 10.0
    apply_skin("classic")

func _collect(n: Node) -> void:
    if n is MeshInstance3D and n.mesh:
        meshes.append(n)
        for i in n.mesh.get_surface_count():
            var m: Material = n.mesh.surface_get_material(i)
            var entry := {"mi": n, "i": i, "name": (m.resource_name if m else ""), "mat": m}
            surfaces.append(entry)
            if not surfaces_by_name.has(entry.name):
                surfaces_by_name[entry.name] = []
            surfaces_by_name[entry.name].append(entry)
    for c in n.get_children():
        _collect(c)

func set_material(mat_name: String, color: Color, metallic := -1.0, rough := -1.0, emission := Color(0, 0, 0, 0)) -> void:
    var touched := {}
    for s in surfaces_by_name.get(mat_name, []):
        if s.mat is BaseMaterial3D:
            # Resource reference and exact Color values avoid rounded-color collisions.
            var key: Array = [s.mat, color, metallic, rough, emission]
            var m: BaseMaterial3D = _variant_cache.get(key)
            if m == null:
                m = (s.mat as BaseMaterial3D).duplicate()
                m.albedo_color = color
                if metallic >= 0.0:
                    m.metallic = metallic
                if rough >= 0.0:
                    m.roughness = rough
                if emission.a > 0.0:
                    m.emission_enabled = true
                    m.emission = emission
                if _variant_cache.size() >= 256:
                    _variant_cache.clear()
                _variant_cache[key] = m
            s.mi.set_surface_override_material(s.i, m)
            touched[s.mi] = true
    if is_inside_tree():
        for mi in touched:
            Cartoon.apply_mesh(mi)

func reset_materials() -> void:
    for s in surfaces:
        s.mi.set_surface_override_material(s.i, null)

func apply_skin(id: String) -> void:
    skin_id = id
    var s: Dictionary = Game.get_skin(id)
    for a in acc:
        if acc[a]:
            acc[a].visible = false
    for a in s.get("acc", []):
        if acc.get(a):
            acc[a].visible = true
    var hide_ears: bool = s.get("hide_ears", false)
    if ear_l:
        ear_l.visible = not hide_ears
        ear_r.visible = not hide_ears
    reset_materials()
    var fur: String = s.get("fur", "")
    if fur != "":
        var fset: Dictionary = Game.FUR[fur]
        for mname in fset:
            var v: Array = fset[mname]
            set_material(mname, v[0], v[1], v[2])
    _set_sparkles(s.rarity == "legendary")
    if is_inside_tree(): Cartoon.apply_tree(self)

## Team jersey for football bots (re-uses the hoodie body mesh).
func set_jersey(color: Color) -> void:
    if acc.get("Acc_HoodieBody"):
        acc["Acc_HoodieBody"].visible = true
        set_material("Hoodie", color, 0.0, 0.7)
        set_material("HoodieDark", color.darkened(0.3), 0.0, 0.7)
        set_material("HoodieString", Color.WHITE, 0.0, 0.7)

func show_acc(a: String, on := true) -> void:
    if acc.get(a):
        acc[a].visible = on

func _set_sparkles(on: bool) -> void:
    if on and _sparkles == null:
        _sparkles = CPUParticles3D.new()
        var qm := QuadMesh.new()
        qm.size = Vector2(0.09, 0.09)
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
        mat.albedo_texture = preload("res://assets/textures/glow.png")
        mat.albedo_color = Color(1.0, 0.92, 0.5)
        mat.vertex_color_use_as_albedo = true
        qm.material = mat
        _sparkles.mesh = qm
        _sparkles.amount = 10
        _sparkles.lifetime = 1.4
        _sparkles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
        _sparkles.emission_box_extents = Vector3(0.45, 0.45, 0.6)
        _sparkles.direction = Vector3.UP
        _sparkles.spread = 25.0
        _sparkles.gravity = Vector3(0, 0.4, 0)
        _sparkles.initial_velocity_min = 0.1
        _sparkles.initial_velocity_max = 0.35
        _sparkles.scale_amount_min = 0.6
        _sparkles.scale_amount_max = 1.4
        var g := Gradient.new()
        g.set_color(0, Color(1, 1, 1, 0))
        g.set_color(1, Color(1, 1, 1, 0))
        g.add_point(0.25, Color(1, 1, 1, 1))
        g.add_point(0.7, Color(1, 1, 1, 0.8))
        _sparkles.color_ramp = g
        _sparkles.position = Vector3(0, 0.75, -0.1)
        add_child(_sparkles)
    if _sparkles:
        _sparkles.emitting = on
        _sparkles.visible = on

# ---------------------------------------------------------------- triggers
func do_jump() -> void:
    squash = 0.22
    squash_v = 0.0

func do_land(strength := 1.0) -> void:
    squash = -0.28 * clampf(strength, 0.3, 1.2)
    squash_v = 0.0

func do_kick() -> void:
    kick_t = 0.0

func do_hop() -> void:
    hop = 1.0

func do_spin() -> void:
    spin = TAU

func flash(color := Color(1, 1, 1)) -> void:
    if _flash_mat == null:
        _flash_mat = StandardMaterial3D.new()
        _flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _flash_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        _flash_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    _flash_mat.albedo_color = Color(color.r, color.g, color.b, 0.9)
    for m in meshes:
        (m as MeshInstance3D).material_overlay = _flash_mat
    var tw := create_tween()
    tw.tween_property(_flash_mat, "albedo_color:a", 0.0, 0.35)
    tw.tween_callback(func():
        for m in meshes:
            (m as MeshInstance3D).material_overlay = _xray_mat)

func set_xray(on: bool, color := Color(1.0, 0.86, 0.3, 0.6)) -> void:
    if on:
        if _xray_shader == null:
            _xray_shader = Shader.new()
            _xray_shader.code = XRAY_CODE
        _xray_mat = ShaderMaterial.new()
        _xray_mat.shader = _xray_shader
        _xray_mat.set_shader_parameter("color", color)
    else:
        _xray_mat = null
    for m in meshes:
        (m as MeshInstance3D).material_overlay = _xray_mat

# ---------------------------------------------------------------- animation
func _process(delta: float) -> void:
    t += delta
    var m := clampf(move_amount, 0.0, 1.4)
    var moving := m > 0.04
    if moving:
        phase += delta * lerpf(7.0, 15.5, clampf(m, 0.0, 1.0))
    var k := 1.0 - exp(-delta * 14.0)
    var swing := 0.8 * clampf(m * 1.4, 0.0, 1.0)
    var s := sin(phase)
    if on_ground:
        _leg(0, s * swing, k)
        _leg(3, s * swing, k)
        _leg(1, -s * swing, k)
        _leg(2, -s * swing, k)
        var bob := absf(cos(phase)) * 0.07 * clampf(m, 0.0, 1.0)
        body.position.y = lerpf(body.position.y, base_pos[body].y + bob + sin(t * 2.4) * 0.008, 0.6)
        body.rotation.z = sin(phase) * 0.05 * m
        body.rotation.x = lerpf(body.rotation.x, base_rot[body].x - 0.07 * m, k)
    else:
        var p := clampf(vert_speed * 0.05, -0.45, 0.45)
        _leg(0, 0.75, k)
        _leg(1, 0.65, k)
        _leg(2, -0.75, k)
        _leg(3, -0.65, k)
        body.rotation.x = lerpf(body.rotation.x, base_rot[body].x + p, k)
        body.rotation.z = lerpf(body.rotation.z, 0.0, k)
    # kick: right front leg swings
    if kick_t >= 0.0:
        kick_t += delta
        var kk := kick_t / 0.32
        var a := sin(clampf(kk, 0.0, 1.0) * PI)
        legs[1].rotation.x = base_rot[legs[1]].x + 1.35 * a
        body.rotation.x += -0.12 * a
        if kk >= 1.0:
            kick_t = -1.0
    # head
    var breathe := sin(t * 2.2) * 0.02
    head.rotation.x = lerpf(head.rotation.x, base_rot[head].x + sin(phase * 2.0) * 0.05 * m + breathe, k)
    head.rotation.y = lerp_angle(head.rotation.y, base_rot[head].y + head_yaw, 1.0 - exp(-delta * 5.0))
    # ears
    next_twitch -= delta
    if next_twitch <= 0.0:
        ear_twitch = 1.0
        next_twitch = randf_range(1.2, 4.0)
    ear_twitch = maxf(0.0, ear_twitch - delta * 4.0)
    var tw := sin(ear_twitch * PI * 4.0) * 0.4 * ear_twitch
    if ear_l:
        ear_l.rotation.z = base_rot[ear_l].z + tw + sin(phase) * 0.12 * m
        ear_r.rotation.z = base_rot[ear_r].z - tw * 0.7 - sin(phase) * 0.12 * m
    # squash & stretch spring (sub-stepped so it stays stable at low FPS)
    var steps := clampi(int(ceil(delta / 0.008)), 1, 30)
    var dt := minf(delta, 0.24) / float(steps)
    for _i in steps:
        squash_v += (-squash * 210.0 - squash_v * 13.0) * dt
        squash += squash_v * dt
    squash = clampf(squash, -0.45, 0.45)
    var sy := 1.0 + squash
    var sxz := 1.0 / sqrt(maxf(sy, 0.4))
    root.scale = Vector3(sxz, sy, sxz)
    # happy hops / spin
    if happy and hop <= 0.0:
        hop = 1.0
    if hop > 0.0:
        hop = maxf(0.0, hop - delta * 2.6)
        root.position.y = sin((1.0 - hop) * PI) * 0.55
        if hop == 0.0:
            do_land(0.6)
    else:
        root.position.y = 0.0
    if spin > 0.0:
        var step := minf(spin, delta * 14.0)
        spin -= step
        root.rotation.y += step
        if spin <= 0.0:
            root.rotation.y = 0.0

func _leg(i: int, target: float, k: float) -> void:
    var l: Node3D = legs[i]
    l.rotation.x = lerpf(l.rotation.x, base_rot[l].x + target, k)
