extends Node3D
## ZOMBIE RUN — escape down a city street to the rescue bus while green
## zombie capybaras (and a whole horde behind you) try to catch you.

const UI := preload("res://scripts/ui.gd")
const TouchControls := preload("res://scripts/touch_controls.gd")
const FX := preload("res://scripts/fx.gd")
const W := preload("res://scripts/world.gd")
const CapyBody := preload("res://scripts/capy_body.gd")
const ZombieModel := preload("res://scripts/zombie_model.gd")
const M := {
    "crate": preload("res://assets/models/crate.glb"),
    "cone": preload("res://assets/models/cone.glb"),
    "barrier": preload("res://assets/models/barrier.glb"),
    "bench": preload("res://assets/models/bench.glb"),
    "car": preload("res://assets/models/car.glb"),
    "trashbin": preload("res://assets/models/trashbin.glb"),
    "hydrant": preload("res://assets/models/hydrant.glb"),
    "lamp": preload("res://assets/models/lamp.glb"),
    "tree": preload("res://assets/models/tree.glb"),
    "bus": preload("res://assets/models/bus.glb"),
    "coin": preload("res://assets/models/coin.glb"),
    "heart": preload("res://assets/models/heart.glb"),
    "bolt": preload("res://assets/models/bolt.glb"),
    "building_a": preload("res://assets/models/building_a.glb"),
    "building_b": preload("res://assets/models/building_b.glb"),
    "building_c": preload("res://assets/models/building_c.glb"),
    "building_d": preload("res://assets/models/building_d.glb"),
}
const SIZES := {"crate": Vector3(1.0, 1.0, 1.0), "cone": Vector3(0.5, 0.72, 0.5), "barrier": Vector3(1.7, 1.0, 0.5),
    "bench": Vector3(1.9, 0.95, 0.5), "car": Vector3(2.0, 1.47, 4.1), "trashbin": Vector3(0.7, 1.02, 0.7),
    "hydrant": Vector3(0.45, 0.8, 0.4)}
const JUMPABLE := {"crate": true, "cone": true, "barrier": true, "bench": true, "car": false, "trashbin": true, "hydrant": true}
const B_WIDTH := {"building_a": 9.3, "building_b": 10.3, "building_c": 8.3, "building_d": 9.3}
const LEVEL_LEN := 300.0
const BUS_Z := -300.0
# The rescue bus leaves to the right along a side street.
const EXIT_HALF_WIDTH := 11.0
const ROAD_HALF := 7.0
const WALK_HALF := 11.0
const LANES := [-9.0, -5.3, -1.8, 1.8, 5.3, 9.0]
const FACADES := [Color("8b6755"), Color("576f6a"), Color("706276"), Color("8a8063"), Color("5b6d7d"), Color("855f5d"), Color("68755d"), Color("816c58")]
const CAR_COLORS := [Color("d9534f"), Color("3f7fd9"), Color("f2c037"), Color("77ab60"), Color("f4f1ea"), Color("6a5fc0"), Color("df894d")]
const FRIENDS := ["Alex", "Max", "Sam"]
const FRIEND_SKINS := ["sporty", "party", "fan", "dj", "cool", "pirate", "ninja", "gentleman"]

enum St {INTRO, RUN, WIN, LOSE, END}

var state := St.INTRO
var state_t := 0.0
var diff := 1
var auto := false
var player
var hearts := 3
var max_hearts := 3
var invuln := 0.0
var boost_t := 0.0
var run_coins := 0
var run_time := 0.0
var obstacles: Array = []
# Spatial index for horde height checks. Visuals and collision shapes are unchanged.
const OBSTACLE_BIN_SIZE := 12.0
var obstacle_bins := {}
var pickups: Array = []
var zombies: Array = []
var horde: Array = []
var horde_z := 17.0
var horde_slow := 0.0
var survivors: Array = []
var saved := 0
var lost_friends := 0
var cam: Camera3D
var cam_pos := Vector3.ZERO
var cam_look := Vector3.ZERO
var shake := 0.0
var hud := {}
var touch_controls: Control = null
var pause_ov: Control = null
var bus: Node3D
var rng := RandomNumberGenerator.new()
var groan_t := 1.5
var vignette_mat: ShaderMaterial
var hurt_flash := 0.0
var coin_combo := 0
var coin_combo_t := 0.0
var chase_speed := 5.1
var detect := 13.0
var _shots := {}
var _horde_warned := 0.0
# Visual culling never touches collision bodies, game logic, or spawn counts.
var mobile_optimized := false
var previous_msaa := Viewport.MSAA_DISABLED
var scenery: Array = []
var active_pickups: Array = []
var visibility_timer := 0.0

func _ready() -> void:
    mobile_optimized = OS.has_feature("mobile") or Game.force_touch
    if mobile_optimized:
        # Reduce multisampling only while this heavy mode is active.
        previous_msaa = get_viewport().msaa_3d
        if previous_msaa > Viewport.MSAA_2X:
            get_viewport().msaa_3d = Viewport.MSAA_2X
    diff = Game.difficulty()
    auto = Game.autotest != ""
    rng.randomize()
    chase_speed = [4.4, 5.1, 5.75][diff]
    detect = [11.0, 13.0, 15.5][diff]
    max_hearts = [4, 3, 3][diff]
    hearts = max_hearts
    _build_world()
    _build_level()
    _spawn_player()
    _spawn_survivors()
    _spawn_zombies()
    _spawn_horde()
    _build_hud()
    _build_touch_controls()
    cam = Camera3D.new()
    cam.fov = 62.0
    cam.far = 125.0 if mobile_optimized else 230.0
    add_child(cam)
    cam.make_current()
    _update_camera(1.0, true)
    _refresh_visible()
    Game.play_music("zombie")
    state = St.INTRO
    state_t = 0.0
    _banner(Game.t("run"), Color("9be26b"), Game.t("to_bus"), 1.7)
    Game.sfx("groan1", -2.0)

func _exit_tree() -> void:
    if mobile_optimized:
        get_viewport().msaa_3d = previous_msaa

# ================================================================ world
func _build_world() -> void:
    var environment := W.environment(self, Color("39435c"), Color("a67c69"), Color("363b4a"),
        {"ambient": 1.05, "fog": Color("82737b"), "fog_density": 0.0065, "fog_sky": 0.0, "exposure": 1.05, "sat": 1.1})
    var sun := W.sun(self, Vector3(-47, 28, 0), 1.35, Color(1.0, 0.86, 0.68), 70.0)
    if mobile_optimized:
        # Keep the same lighting, but reduce costly full-screen glow and shadow work.
        environment.glow_enabled = false
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
        sun.directional_shadow_max_distance = 32.0
        sun.directional_shadow_blend_splits = false
    var z_back := 45.0
    var z_front := BUS_Z - 45.0
    var length := z_back - z_front
    var zc := (z_back + z_front) * 0.5
    W.plane(self, Vector2(ROAD_HALF * 2.0, length + 25.0), Vector3(0, 0, zc - 12.5), W.tex_mat(load("res://assets/textures/road.jpg"), Vector3(1, (length + 25.0) / 14.0, 1), Color("b4b1ae"), 0.85))
    # T-junction at the bus: the right sidewalk and curb stop at the side street.
    # The asphalt continues beyond the facades for the whole departure animation.
    var side_road := W.plane(self, Vector2(EXIT_HALF_WIDTH * 2.0, 100.0), Vector3(ROAD_HALF + 50.0, 0.018, BUS_Z), W.tex_mat(load("res://assets/textures/road.jpg"), Vector3(1, 100.0 / 14.0, 1), Color("b4b1ae"), 0.85))
    side_road.name = "BusExitRoad"
    side_road.rotation.y = PI * 0.5
    var sidewalk_tex: Texture2D = load("res://assets/textures/sidewalk.png")
    # Sidewalks and curbs frame the cross street without blocking the lane.
    var exit_walk_length := 96.0
    for edge in [-1, 1]:
        var cross_walk := W.plane(self, Vector2(4.0, exit_walk_length), Vector3(WALK_HALF + exit_walk_length * 0.5, 0.012, BUS_Z + edge * (EXIT_HALF_WIDTH + 2.0)), W.tex_mat(sidewalk_tex, Vector3(2, exit_walk_length / 2.0, 1), Color("b5aaa6"), 0.9))
        cross_walk.rotation.y = PI * 0.5
        W.mesh_box(self, Vector3(exit_walk_length, 0.14, 0.28), Vector3(WALK_HALF + exit_walk_length * 0.5, 0.07, BUS_Z + edge * EXIT_HALF_WIDTH), W.mat(Color("cfcac4"), 0.8), 0.0, false)
    for side in [-1, 1]:
        var segments: Array = [[z_back, z_front]]
        if side == 1:
            segments = [[z_back, BUS_Z + EXIT_HALF_WIDTH], [BUS_Z - EXIT_HALF_WIDTH, z_front]]
        for seg in segments:
            var seg_len: float = seg[0] - seg[1]
            var seg_center: float = (seg[0] + seg[1]) * 0.5
            W.plane(self, Vector2(4.0, seg_len), Vector3(side * 9.0, 0.012, seg_center), W.tex_mat(sidewalk_tex, Vector3(2, seg_len / 2.0, 1), Color("b5aaa6"), 0.9))
            W.mesh_box(self, Vector3(0.28, 0.14, seg_len), Vector3(side * 7.0, 0.07, seg_center), W.mat(Color("cfcac4"), 0.8), 0.0, false)
    W.plane(self, Vector2(160, length + 120), Vector3(0, -0.06, zc), W.mat(Color("8c8794"), 1.0))
    # colliders: floor + invisible side walls
    var walls := W.static_body(self)
    W.box_shape(walls, Vector3(60, 2, length + 40), Vector3(0, -1, zc))
    for s in [-1, 1]:
        W.box_shape(walls, Vector3(1, 10, length + 40), Vector3(s * (WALK_HALF + 0.4), 5, zc))
    W.box_shape(walls, Vector3(30, 10, 1), Vector3(0, 5, z_back - 2.0))
    W.box_shape(walls, Vector3(30, 10, 1), Vector3(0, 5, BUS_Z - 12.0))
    _buildings(z_back, z_front)
    _build_finish_backdrop()
    _street_furniture()
    # the rescue bus, parked across the road with its door facing the player
    bus = M.bus.instantiate()
    bus.position = Vector3(-0.6, 0, BUS_Z)
    bus.rotation.y = -PI * 0.5
    add_child(bus)
    var bb := W.static_body(self)
    W.box_shape(bb, Vector3(11.6, 3.3, 2.7), Vector3(-0.6 + 0.6, 1.65, BUS_Z))
    # rescue zone marker
    var zone := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(5.5, 5.5)
    var zm := StandardMaterial3D.new()
    zm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    zm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    zm.albedo_texture = preload("res://assets/textures/ring.png")
    zm.albedo_color = Color(0.5, 1.0, 0.4, 0.9)
    pm.material = zm
    zone.mesh = pm
    zone.position = Vector3(3.5, 0.05, BUS_Z + 3.2)
    zone.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(zone)
    hud.zone = zone
    # bouncing arrow (cone pointing down) above the bus door
    var arrow := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.62
    cm.bottom_radius = 0.0
    cm.height = 1.1
    cm.radial_segments = 4
    cm.rings = 1
    var am := StandardMaterial3D.new()
    am.albedo_color = Color("8fe05a")
    am.emission_enabled = true
    am.emission = Color("5fc23a")
    am.emission_energy_multiplier = 0.6
    am.roughness = 0.5
    cm.material = am
    arrow.mesh = cm
    arrow.position = Vector3(3.5, 5.6, BUS_Z + 1.5)
    arrow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(arrow)
    hud.bus_arrow = arrow
    var bus_sign := Label3D.new()
    bus_sign.text = Game.t("bus_sign")
    bus_sign.font = UI.FONT_BLACK
    bus_sign.font_size = 110
    bus_sign.outline_size = 22
    bus_sign.modulate = Color("ffd84a")
    bus_sign.outline_modulate = Color(0.25, 0.15, 0.05)
    bus_sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    bus_sign.position = Vector3(3.5, 7.0, BUS_Z + 1.5)
    bus_sign.pixel_size = 0.012
    add_child(bus_sign)
    hud.bus_sign = bus_sign

# Lightweight facade strip beyond the cross street: one mesh, no collision, shadows or scripts.
# It never crosses the bus exit and follows the existing mobile scenery culling.
func _build_finish_backdrop() -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var palette := [Color("806e6b"), Color("75676f"), Color("777a73"), Color("88776a"), Color("696e7a"), Color("816b69")]
    var heights := [12.0, 15.0, 10.0, 13.0, 16.0, 11.0, 14.0, 12.0]
    for i in range(16):
        var x: float = -55.0 + i * 10.0
        var h: float = heights[i % heights.size()]
        var depth: float = -float((i * 3) % 4) * 2.5
        var facade: Color = palette[i % palette.size()]
        _backdrop_quad(st, x - 0.3, 0.0, x + 10.3, h, depth, facade)
        _backdrop_quad(st, x, h - 0.22, x + 9.92, h + 0.12, depth + 0.02, Color("b1a49e"))
        _backdrop_quad(st, x, 2.95, x + 9.92, 3.17, depth + 0.02, Color("a79a95"))
        for floor_idx in range(1, int(h / 3.0)):
            var y: float = 3.7 + (floor_idx - 1) * 3.0
            for col in range(3):
                var wx: float = x + 1.25 + col * 3.0
                var lit: bool = (i * 7 + floor_idx * 3 + col * 5) % 5 == 0
                var glass := Color("d1c59d") if lit else Color("4c4758")
                _backdrop_quad(st, wx - 0.10, y - 0.08, wx + 1.24, y + 1.77, depth + 0.03, Color("b3a6a1"))
                _backdrop_quad(st, wx, y, wx + 1.14, y + 1.65, depth + 0.05, glass)
        _backdrop_quad(st, x + 1.1, 0.0, x + 8.8, 2.65, depth + 0.03, Color("57505a"))
    var mat := StandardMaterial3D.new()
    mat.vertex_color_use_as_albedo = true
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.roughness = 1.0
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    var skyline := MeshInstance3D.new()
    skyline.name = "FinishCityBackdrop"
    skyline.mesh = st.commit()
    skyline.material_override = mat
    skyline.position = Vector3(0.0, 0.0, BUS_Z - 40.0)
    skyline.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(skyline)
    _track_scenery(skyline)

func _backdrop_quad(st: SurfaceTool, x0: float, y0: float, x1: float, y1: float, z: float, color: Color) -> void:
    var points := [Vector3(x0, y0, z), Vector3(x1, y0, z), Vector3(x1, y1, z), Vector3(x0, y0, z), Vector3(x1, y1, z), Vector3(x0, y1, z)]
    for pt in points:
        st.set_color(color)
        st.set_normal(Vector3(0, 0, 1))
        st.add_vertex(pt)

func _vis_range(n: Node, dist: float) -> void:
    if n is GeometryInstance3D:
        (n as GeometryInstance3D).visibility_range_end = dist
        (n as GeometryInstance3D).visibility_range_end_margin = 10.0
        (n as GeometryInstance3D).visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
    for c in n.get_children():
        _vis_range(c, dist)

func _buildings(z_back: float, z_front: float) -> void:
    var kinds := ["building_a", "building_b", "building_c", "building_d"]
    for s in [-1, 1]:
        var z := z_back
        while z > z_front:
            var k: String = kinds[rng.randi() % kinds.size()]
            var w: float = B_WIDTH[k]
            # Omit whole facades that would block the bus exit, with a safety margin.
            if s == 1 and z >= BUS_Z - EXIT_HALF_WIDTH - 2.0 and z - w <= BUS_Z + EXIT_HALF_WIDTH + 2.0:
                z -= w + 0.2
                continue
            var b: Node3D = M[k].instantiate()
            b.rotation.y = -PI * 0.5 if s < 0 else PI * 0.5
            b.position = Vector3(s * (WALK_HALF + 4.65), 0, z - w * 0.5)
            W.recolor(b, "Facade", FACADES[rng.randi() % FACADES.size()])
            if mobile_optimized:
                W.set_shadows(b, false)
            else:
                _vis_range(b, 170.0)
            add_child(b)
            _track_scenery(b)
            z -= w + 0.2

func _exit_clear(z: float, margin := 2.0) -> bool:
    return absf(z - BUS_Z) <= EXIT_HALF_WIDTH + margin

func _street_furniture() -> void:
    var props := W.static_body(self)
    var i := 0
    var z := 30.0
    while z > BUS_Z - 30.0:
        var side := 1 if i % 2 == 0 else -1
        # Keep the right-hand side street clear of furniture and collision shapes.
        if side < 0 or not _exit_clear(z):
            var lamp: Node3D = M.lamp.instantiate()
            lamp.position = Vector3(side * 7.7, 0, z)
            add_child(lamp)
            if not mobile_optimized: _vis_range(lamp, 150.0)
            _track_scenery(lamp)
            W.cyl_shape(props, 0.18, 4.4, Vector3(side * 7.7, 2.2, z))
        if side > 0 or not _exit_clear(z - 8.0, 4.0):
            var tree: Node3D = M.tree.instantiate()
            W.mature_tree(tree)
            tree.position = Vector3(-side * 7.9, 0, z - 8.0)
            tree.rotation.y = rng.randf() * TAU
            add_child(tree)
            if not mobile_optimized: _vis_range(tree, 150.0)
            _track_scenery(tree)
            W.cyl_shape(props, 0.32, 2.2, Vector3(-side * 7.9, 1.1, z - 8.0))
        if rng.randf() < 0.5 and (side < 0 or not _exit_clear(z - 4.0)):
            var hy: Node3D = M.hydrant.instantiate()
            hy.position = Vector3(side * 7.6, 0, z - 4.0)
            add_child(hy)
            _track_scenery(hy)
            W.cyl_shape(props, 0.22, 0.8, Vector3(side * 7.6, 0.4, z - 4.0))
        if rng.randf() < 0.45 and (side > 0 or not _exit_clear(z - 3.0)):
            var tb: Node3D = M.trashbin.instantiate()
            tb.position = Vector3(-side * 10.4, 0, z - 3.0)
            add_child(tb)
            _track_scenery(tb)
            W.cyl_shape(props, 0.36, 1.0, Vector3(-side * 10.4, 0.5, z - 3.0))
        if rng.randf() < 0.45 and (side < 0 or not _exit_clear(z - 11.0)):
            var bn: Node3D = M.bench.instantiate()
            bn.position = Vector3(side * 10.35, 0, z - 11.0)
            bn.rotation.y = -side * PI * 0.5
            add_child(bn)
            _track_scenery(bn)
            W.box_shape(props, Vector3(0.5, 0.95, 1.9), Vector3(side * 10.35, 0.47, z - 11.0))
        z -= 16.0
        i += 1

# ================================================================ level generation
func _build_level() -> void:
    var z := -24.0
    var idx := 0
    var gap_mul: float = [1.15, 1.0, 0.9][diff]
    while z > BUS_Z + 22.0:
        _row(z, idx)
        z -= rng.randf_range(10.0, 13.5) * gap_mul
        idx += 1

func _row(z: float, idx: int) -> void:
    var free: Array = []
    var jumpables: Array = []
    var r := rng.randf()
    if r < 0.3:
        var road := [1, 2, 3, 4]
        road.shuffle()
        var n := 2 if rng.randf() < 0.6 else 3
        for k in n:
            var yaw := rng.randf_range(-0.45, 0.45) + (PI if rng.randf() < 0.5 else 0.0)
            _place("car", Vector3(LANES[road[k]] + rng.randf_range(-0.3, 0.3), 0, z + rng.randf_range(-1.5, 1.5)), yaw)
        free = road.slice(n)
        free.append(0)
        free.append(5)
    elif r < 0.5:
        var gap := rng.randi_range(1, 4)
        for li in [1, 2, 3, 4]:
            if li == gap:
                continue
            for off in [-0.88, 0.88]:
                jumpables.append(_place("barrier", Vector3(LANES[li] + off, 0, z), 0.0))
        free = [gap, 0, 5]
    elif r < 0.75:
        var lanes := [0, 1, 2, 3, 4, 5]
        lanes.shuffle()
        var n2 := rng.randi_range(2, 4)
        for k in n2:
            var li: int = lanes[k]
            var p := Vector3(LANES[li] + rng.randf_range(-0.5, 0.5), 0, z + rng.randf_range(-1.0, 1.0))
            var stack := rng.randf() < 0.35
            var o := _place("crate", p, rng.randf_range(-0.3, 0.3))
            if stack:
                _place("crate", p, rng.randf_range(-0.4, 0.4), 1, false)
                o.top = 2.0
                o.jump = false
            else:
                jumpables.append(o)
                if rng.randf() < 0.5:
                    jumpables.append(_place("crate", p + Vector3(1.05 * (1 if p.x < 0 else -1), 0, 0), rng.randf_range(-0.3, 0.3)))
        free = lanes.slice(n2)
    elif r < 0.88:
        for li in [1, 2, 3, 4]:
            if rng.randf() < 0.75:
                for off in [-0.85, 0.85]:
                    jumpables.append(_place("cone", Vector3(LANES[li] + off, 0, z + (0.6 if li % 2 == 0 else -0.6)), 0.0))
            else:
                free.append(li)
        free.append(0)
        free.append(5)
    else:
        var cl := rng.randi_range(1, 4)
        _place("car", Vector3(LANES[cl], 0, z), rng.randf_range(-0.3, 0.3) + PI * 0.5)
        for li in [1, 2, 3, 4]:
            if absi(li - cl) >= 2 and rng.randf() < 0.6:
                jumpables.append(_place("bench" if rng.randf() < 0.5 else "trashbin", Vector3(LANES[li], 0, z + rng.randf_range(-1, 1)), 0.0))
            elif absi(li - cl) >= 2:
                free.append(li)
        free.append(0 if cl > 2 else 5)
    # coins
    free.shuffle()
    var lines := mini(free.size(), 1 + (1 if rng.randf() < 0.5 else 0))
    for k in lines:
        var lx: float = LANES[free[k]]
        for j in 5:
            _pickup("coin", Vector3(lx, 1.0, z - 2.5 - j * 1.4))
    if jumpables.size() > 0 and rng.randf() < 0.6:
        var o2: Dictionary = jumpables.pick_random()
        for j in 5:
            var tt := float(j) / 4.0
            _pickup("coin", Vector3(o2.pos.x, 1.2 + sin(tt * PI) * 1.4, o2.pos.z + 2.6 - tt * 5.2))
    # power-ups
    if idx in [5, 13, 20] and free.size() > 0:
        _pickup("heart", Vector3(LANES[free[free.size() - 1]], 1.1, z - 6.0))
    elif idx in [3, 9, 16, 23] and free.size() > 0:
        _pickup("bolt", Vector3(LANES[free[0]], 1.1, z - 6.5))

func _place(kind: String, pos: Vector3, yaw: float, stack := 0, register := true) -> Dictionary:
    var n: Node3D = M[kind].instantiate()
    n.position = pos + Vector3(0, stack * 1.0, 0)
    n.rotation.y = yaw
    add_child(n)
    if not mobile_optimized: _vis_range(n, 120.0)
    _track_scenery(n)
    if kind == "car":
        W.recolor(n, "CarPaint", CAR_COLORS[rng.randi() % CAR_COLORS.size()])
    var size: Vector3 = SIZES[kind]
    var body := W.static_body(self)
    body.position = n.position
    body.rotation.y = yaw
    W.box_shape(body, size, Vector3(0, size.y * 0.5, 0))
    var c := absf(cos(yaw))
    var s := absf(sin(yaw))
    var o := {"pos": n.position, "hx": c * size.x * 0.5 + s * size.z * 0.5, "hz": s * size.x * 0.5 + c * size.z * 0.5,
        "top": n.position.y + size.y, "jump": JUMPABLE[kind], "kind": kind}
    if register:
        obstacles.append(o)
        # 0.8 is the largest padding used by _ground_height.
        var first := floori((float(o.pos.z) - float(o.hz) - 0.8) / OBSTACLE_BIN_SIZE)
        var last := floori((float(o.pos.z) + float(o.hz) + 0.8) / OBSTACLE_BIN_SIZE)
        for bin in range(first, last + 1):
            if not obstacle_bins.has(bin): obstacle_bins[bin] = []
            obstacle_bins[bin].append(o)
    return o

func _pickup(kind: String, pos: Vector3) -> void:
    var n: Node3D = M[kind].instantiate()
    n.position = pos
    if kind != "coin":
        n.scale = Vector3.ONE * 1.25
    add_child(n)
    W.set_shadows(n, false)
    pickups.append({"node": n, "kind": kind, "pos": pos, "taken": false})

# ================================================================ actors
func _spawn_player() -> void:
    player = CapyBody.new()
    player.is_player = true
    player.step_sounds = true
    player.display_name = Game.player_nickname()
    player.set_nametag(player.display_name, Game.player_nick_color(), 2.55)
    add_child(player)
    player.set_skin(Game.equipped())
    # The old x-ray overlay tints even unobstructed bodies on some GPUs.
    # Keep the skin opaque and mark the player with a small blue chevron instead.
    var marker := Label3D.new()
    marker.name = "PlayerMarker"
    marker.text = "▼"
    marker.font = UI.FONT_BLACK
    marker.font_size = 76
    marker.pixel_size = 0.008
    marker.position = Vector3(0, 2.05, 0)
    marker.modulate = Color("66d7ff")
    marker.outline_size = 12
    marker.outline_modulate = Color("173555")
    marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    marker.no_depth_test = true
    player.add_child(marker)
    var ring := MeshInstance3D.new()
    var rpm := PlaneMesh.new()
    rpm.size = Vector2(1.9, 1.9)
    var rmat := StandardMaterial3D.new()
    rmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    rmat.albedo_texture = preload("res://assets/textures/ring.png")
    rmat.albedo_color = Color("79d7ff")
    rpm.material = rmat
    ring.mesh = rpm
    ring.position.y = 0.05
    ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    player.add_child(ring)
    player.teleport(Vector3(0, 0, 0), Vector3(0, 0, -1))
    player.jumped.connect(func(): Game.sfx("jump", -5.0))
    player.landed.connect(func(impact: float):
        if impact > 0.4:
            Game.sfx("land", -8.0)
            FX.puff(self, player.global_position + Vector3(0, 0.1, 0), Color(0.9, 0.88, 0.85), 6, 0.4, 1.4))

func _spawn_survivors() -> void:
    var skins := FRIEND_SKINS.duplicate()
    skins.erase(Game.equipped())
    skins.shuffle()
    var spots := [Vector3(-3.2, 0, 2.2), Vector3(3.4, 0, 2.8), Vector3(0.4, 0, 4.6)]
    var bot_names := Game.random_bot_names(3)
    for i in 3:
        var s = CapyBody.new()
        s.display_name = str(bot_names[i])
        s.set_nametag(s.display_name)
        s.speed = [6.5, 6.3, 6.15][diff] * rng.randf_range(0.96, 1.04)
        s.sprint_mult = 1.4
        s.ai = {"lane": spots[i].x, "think": 0.0}
        add_child(s)
        s.set_skin(skins[i])
        s.teleport(spots[i], Vector3(0, 0, -1))
        survivors.append(s)

func _spawn_zombies() -> void:
    var n: int = [14, 21, 28][diff]
    for i in n:
        var tries := 0
        while tries < 12:
            tries += 1
            var z := lerpf(-34.0, BUS_Z + 26.0, (float(i) + rng.randf()) / float(n))
            var x := rng.randf_range(-9.5, 9.5)
            if _ground_height(x, z, 0.8) > 0.0:
                continue
            _make_zombie(Vector3(x, 0, z), false)
            break

func _make_zombie(pos: Vector3, chasing: bool) -> Dictionary:
    var body := CharacterBody3D.new()
    body.collision_layer = 0
    body.collision_mask = 1
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.38
    cap.height = 1.3
    cs.shape = cap
    cs.position.y = 0.65
    body.add_child(cs)
    var zm = ZombieModel.new()
    body.add_child(zm)
    add_child(body)
    body.global_position = pos
    body.rotation.y = rng.randf() * TAU
    var z := {"body": body, "model": zm, "state": "chase" if chasing else "idle",
        "speed": chase_speed * rng.randf_range(0.9, 1.08), "home": pos, "wander": pos, "wander_t": 0.0,
        "stun": 0.0, "stuck": 0.0, "side": 1.0 if rng.randf() < 0.5 else -1.0, "dodge": 0.0, "lunged": false}
    zombies.append(z)
    return z

func _spawn_horde() -> void:
    for i in [12, 14, 16][diff]:
        _add_horde_member(rng.randf_range(-10.0, 10.0), rng.randf_range(0.0, 6.0))

func _add_horde_member(x: float, off: float) -> void:
    var zm = ZombieModel.new()
    add_child(zm)
    if mobile_optimized: W.set_shadows(zm, false)
    zm.position = Vector3(x, 0, horde_z + off)
    horde.append({"model": zm, "x": x, "off": off, "y": 0.0, "ph": rng.randf() * TAU})

# Cull scenery around the player on mobile. Physics and collision are unaffected.
# A wide margin keeps objects from popping into view at running speed and in the intro.
func _track_scenery(n: Node3D) -> void:
    if mobile_optimized:
        scenery.append({"node": n, "z": n.position.z})

func _refresh_visible() -> void:
    if not is_instance_valid(player): return
    var pz: float = player.global_position.z
    if mobile_optimized:
        for item in scenery:
            var n: Node3D = item.node
            var dz: float = item.z - pz
            var show: bool = dz <= 55.0 and dz >= -100.0
            if n.visible != show: n.visible = show
        for z in zombies:
            var dz: float = z.body.global_position.z - pz
            var show: bool = dz <= 55.0 and dz >= -100.0
            if z.model.visible != show:
                z.model.visible = show
                z.model.set_process(show)
        var horde_visible: bool = horde_z - pz < 65.0
        for h in horde:
            if h.model.visible != horde_visible:
                h.model.visible = horde_visible
                h.model.set_process(horde_visible)
    # Rotate and test only nearby pickups each frame; keep the distant ones hidden.
    active_pickups.clear()
    for item in pickups:
        if item.taken: continue
        var dz: float = item.pos.z - pz
        var near: bool = dz <= 23.0 and dz >= -95.0
        if item.node.visible != near: item.node.visible = near
        if near: active_pickups.append(item)

# ================================================================ main loop
func _physics_process(delta: float) -> void:
    state_t += delta
    visibility_timer -= delta
    if visibility_timer <= 0.0:
        visibility_timer = 0.3
        _refresh_visible()
    match state:
        St.INTRO:
            _control_player(delta)
            player.frozen = state_t < 0.9
            for s in survivors:
                s.frozen = state_t < 0.9
            if state_t > 0.9:
                _update_survivors(delta)
            if state_t > 2.0:
                state = St.RUN
                state_t = 0.0
        St.RUN:
            run_time += delta
            _control_player(delta)
            _update_survivors(delta)
            _update_zombies(delta)
            _update_horde(delta)
            _update_pickups(delta)
            _timers(delta)
            if player.global_position.z < BUS_Z + 4.6:
                _win()
        St.WIN, St.LOSE, St.END:
            _update_zombies(delta)
            _update_horde(delta)
            _update_pickups(delta)
    _update_camera(delta)
    _update_hud(delta)

func _control_player(delta: float) -> void:
    if auto:
        _runner_ai(player, delta, true)
        return
    var mv := Game.move_vector()
    if touch_controls and touch_controls.move.length() > 0.01:
        mv = touch_controls.move
    player.move_input = Vector3(mv.x, 0, mv.y)
    player.sprint_input = Input.is_action_pressed("sprint") or (touch_controls != null and touch_controls.sprint)
    player.jump_held = Input.is_action_pressed("jump") or (touch_controls != null and touch_controls.jump_held)

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("pause"):
        _toggle_pause()
        get_viewport().set_input_as_handled()
        return
    if get_tree().paused or auto:
        return
    if event.is_action_pressed("jump") and (state == St.RUN or state == St.INTRO):
        player.jump_pressed = true

func _timers(delta: float) -> void:
    if invuln > 0.0:
        invuln -= delta
        player.model.visible = int(invuln * 14.0) % 2 == 0 or invuln <= 0.0
    if boost_t > 0.0:
        boost_t -= delta
        if boost_t <= 0.0:
            player.speed_mult = 1.0
    hurt_flash = maxf(0.0, hurt_flash - delta * 1.5)
    coin_combo_t -= delta
    if coin_combo_t <= 0.0:
        coin_combo = 0
    groan_t -= delta
    if groan_t <= 0.0:
        groan_t = rng.randf_range(1.6, 3.2)
        var near := INF
        var pp: Vector3 = player.global_position
        for z in zombies:
            near = minf(near, (z.body.global_position as Vector3).distance_to(pp))
        near = minf(near, absf(horde_z - pp.z))
        if near < 22.0:
            Game.sfx("groan%d" % rng.randi_range(1, 3), lerpf(-4.0, -20.0, near / 22.0), rng.randf_range(0.85, 1.15))

# ================================================================ AI
func _lane_blocked(x: float, z: float, ahead: float):
    var best = null
    var bd := INF
    var first := floori((z - ahead) / OBSTACLE_BIN_SIZE)
    var last := floori((z + 0.6) / OBSTACLE_BIN_SIZE)
    for bin in range(first, last + 1):
        for o in obstacle_bins.get(bin, []):
            var oz: float = o.pos.z
            if oz > z + 0.6 + o.hz or oz < z - ahead - o.hz:
                continue
            if absf(o.pos.x - x) > o.hx + 0.55:
                continue
            var d := z - oz
            if d < bd:
                bd = d
                best = o
    return best

func _best_lane(x: float, z: float, avoid_x := 999.0) -> float:
    var best: float = x
    var bs := -INF
    for lx in LANES:
        var s: float = -absf(lx - x) * 0.35
        var o = _lane_blocked(lx, z, 9.0)
        if o != null:
            s -= 1.0 if o.jump else 10.0
        if absf(lx - avoid_x) < 2.2:
            s -= 6.0
        if s > bs:
            bs = s
            best = lx
    return best

func _runner_ai(s, delta: float, is_player: bool) -> void:
    var p: Vector3 = s.global_position
    var ai: Dictionary = s.ai
    if not ai.has("lane"):
        ai.lane = p.x
        ai.think = 0.0
    ai.think -= delta
    if ai.think <= 0.0:
        ai.think = 0.14
        var o = _lane_blocked(ai.lane, p.z, 7.5)
        if o != null and not o.jump:
            ai.lane = _best_lane(p.x, p.z)
        for z in zombies:
            var zp: Vector3 = z.body.global_position
            if zp.z < p.z + 1.0 and zp.z > p.z - 8.0 and absf(zp.x - ai.lane) < 1.8:
                ai.lane = _best_lane(p.x, p.z, zp.x)
                break
    var o2 = _lane_blocked(p.x, p.z, 2.4)
    if o2 != null and o2.jump and s.is_on_floor() and p.z - o2.pos.z > 0.6:
        s.jump_pressed = true
    s.jump_held = true
    var dx := clampf((float(ai.lane) - p.x) * 0.8, -0.95, 0.95)
    var fwd := 1.0
    if is_player:
        s.sprint_input = s.stamina > 0.2
    else:
        var lead: float = player.global_position.z - p.z
        if lead > 12.0:
            fwd = 0.5
            s.sprint_input = false
        elif lead < -5.0 or horde_z - p.z < 7.0:
            s.sprint_input = true
        else:
            s.sprint_input = false
    var mv := Vector3(dx, 0, -fwd)
    if mv.length() > 1.0:
        mv = mv.normalized()
    s.move_input = mv

func _update_survivors(delta: float) -> void:
    for s in survivors.duplicate():
        if not is_instance_valid(s):
            continue
        _runner_ai(s, delta, false)
        if s.global_position.z < BUS_Z + 4.6:
            _friend_saved(s)

func _friend_saved(s) -> void:
    survivors.erase(s)
    saved += 1
    FX.sparkle(self, s.global_position + Vector3(0, 0.8, 0), Color("9be26b"), 22, 4.0)
    FX.puff(self, s.global_position + Vector3(0, 0.5, 0), Color.WHITE, 10)
    _toast(Game.t("friend_saved") % s.display_name, Color("9be26b"))
    Game.sfx("heart", -4.0)
    s.queue_free()

func _update_zombies(delta: float) -> void:
    var pp: Vector3 = player.global_position
    var targets: Array = []
    if state == St.RUN or state == St.INTRO:
        targets.append(player)
    for s in survivors:
        targets.append(s)
    # Cache positions once, updating each after movement; separation keeps the
    # original actor order and uses the same positions as the previous loop.
    var zombie_positions: Array[Vector3] = []
    for z in zombies:
        zombie_positions.append(z.body.global_position)
    for zi in zombies.size():
        var z = zombies[zi]
        var b: CharacterBody3D = z.body
        var bp: Vector3 = zombie_positions[zi]
        if bp.z > pp.z + 40.0 or bp.z < pp.z - 95.0:
            z.model.move_amount = 0.0
            continue
        z.stun = maxf(0.0, z.stun - delta)
        var target = null
        var td := INF
        for c in targets:
            var d: float = (c.global_position as Vector3).distance_to(bp)
            if d < td:
                td = d
                target = c
        var desired := Vector3.ZERO
        var spd := 0.0
        if z.state == "idle":
            if target != null and td < detect:
                z.state = "chase"
                if td < 18.0:
                    Game.sfx("groan%d" % rng.randi_range(1, 3), -10.0, rng.randf_range(0.9, 1.2))
            else:
                z.wander_t -= delta
                if z.wander_t <= 0.0:
                    z.wander_t = rng.randf_range(2.0, 4.0)
                    z.wander = z.home + Vector3(rng.randf_range(-2.5, 2.5), 0, rng.randf_range(-2.5, 2.5))
                var tw: Vector3 = z.wander - bp
                tw.y = 0.0
                if tw.length() > 0.4:
                    desired = tw.normalized()
                    spd = 0.9
        if z.state == "chase" and target != null:
            var tv: Vector3 = target.global_position - bp
            tv.y = 0.0
            desired = tv.normalized() if tv.length() > 0.01 else Vector3.ZERO
            spd = z.speed
            if td > 34.0:
                z.state = "idle"
                z.home = bp
            if td < 2.4 and not z.lunged:
                z.lunged = true
                z.model.do_lunge()
            elif td > 4.0:
                z.lunged = false
            if td < 1.0 and z.stun <= 0.0 and (state == St.RUN or state == St.INTRO):
                _zombie_hit(z, target)
        if z.dodge > 0.0:
            z.dodge -= delta
            desired = (desired + Vector3(z.side, 0, 0) * 1.4).normalized()
        if z.stun > 0.0:
            spd *= 0.15
        # separation
        for oi in zombie_positions.size():
            if oi == zi:
                continue
            var op: Vector3 = zombie_positions[oi]
            if absf(bp.z - op.z) >= 1.1 or absf(bp.x - op.x) >= 1.1:
                continue
            var dd := Vector3(bp.x - op.x, 0.0, bp.z - op.z)
            var len_sq := dd.length_squared()
            if len_sq < 1.21 and len_sq > 0.0001:
                var l := sqrt(len_sq)
                desired += dd / l * (1.1 - l) * 1.2
        var hv := Vector3(b.velocity.x, 0, b.velocity.z).move_toward(desired * spd, 18.0 * delta)
        b.velocity.x = hv.x
        b.velocity.z = hv.z
        b.velocity.y = -1.0 if b.is_on_floor() else b.velocity.y - 30.0 * delta
        b.move_and_slide()
        zombie_positions[zi] = b.global_position
        var real := Vector3(b.get_real_velocity().x, 0, b.get_real_velocity().z).length()
        if spd > 2.0 and real < spd * 0.3:
            z.stuck += delta
            if z.stuck > 0.5:
                z.stuck = 0.0
                z.dodge = 1.0
                z.side = -z.side if rng.randf() < 0.3 else z.side
        else:
            z.stuck = maxf(0.0, z.stuck - delta)
        if hv.length() > 0.3:
            b.rotation.y = lerp_angle(b.rotation.y, atan2(-hv.x, -hv.z), 1.0 - exp(-8.0 * delta))
        z.model.move_amount = hv.length() / 4.5

func _zombie_hit(z: Dictionary, target) -> void:
    if target == player:
        if invuln > 0.0:
            return
        var dir: Vector3 = player.global_position - (z.body.global_position as Vector3)
        dir.y = 0.0
        _damage(dir.normalized())
        z.stun = 1.3
    else:
        _infect(target)
        z.stun = 0.9

func _damage(dir: Vector3) -> void:
    if state != St.RUN:
        return
    hearts -= 1
    invuln = 2.0
    hurt_flash = 1.0
    player.knockback(Vector3(dir.x * 6.0, 5.5, dir.z * 6.0 - 4.0), 0.35)
    player.model.flash(Color(1.0, 0.3, 0.3))
    Game.sfx("hurt", -2.0)
    shake = 0.55
    FX.burst(self, player.global_position + Vector3(0, 0.8, 0), Color("7cb65a"), 14, 5.0)
    _refresh_hearts(true)
    if hearts <= 0:
        _lose()
    elif auto and not _shots.has("hurt"):
        _shots.hurt = true
        Game.shot("zr_hurt")

func _infect(s) -> void:
    if not survivors.has(s):
        return
    survivors.erase(s)
    lost_friends += 1
    var pos: Vector3 = s.global_position
    FX.puff(self, pos + Vector3(0, 0.6, 0), Color("8fd16a"), 16, 0.6, 2.5)
    FX.burst(self, pos + Vector3(0, 0.8, 0), Color("7cb65a"), 12, 4.0)
    Game.sfx("infect", -2.0)
    _toast(Game.t("infected") % s.display_name, Color("ff8a7a"))
    s.queue_free()
    if pos.z > horde_z - 2.0:
        _add_horde_member(clampf(pos.x, -10.0, 10.0), rng.randf_range(0.0, 2.0))
        horde[horde.size() - 1].model.do_rise()
    else:
        var z := _make_zombie(pos, true)
        z.model.do_rise()
        z.stun = 1.2

func _update_horde(delta: float) -> void:
    var pp: Vector3 = player.global_position
    if state == St.RUN:
        var spd: float = [3.35, 4.05, 4.6][diff] + run_time * 0.012
        var gap := horde_z - pp.z
        if gap > 24.0:
            spd += (gap - 24.0) * 0.3
        if horde_slow > 0.0:
            horde_slow -= delta
            spd *= 0.3
        horde_z -= spd * delta
    elif state == St.LOSE:
        horde_z = lerpf(horde_z, pp.z + 0.5, 1.0 - exp(-2.0 * delta))
    var t := Time.get_ticks_msec() * 0.001
    for h in horde:
        var hz: float = horde_z + h.off
        var hx: float = h.x + sin(t * 0.7 + h.ph) * 0.6
        var y := _ground_height(hx, hz, 0.2)
        h.y = lerpf(h.y, y, 1.0 - exp(-9.0 * delta))
        h.model.position = Vector3(hx, h.y, hz)
        h.model.move_amount = 1.0 if state == St.RUN else 0.4
    if state == St.RUN:
        if pp.z > horde_z - 0.7 and invuln <= 0.0:
            _damage(Vector3(0, 0, -1))
            horde_slow = 2.2
            horde_z += 2.5
        for s in survivors.duplicate():
            if is_instance_valid(s) and s.global_position.z > horde_z - 0.4:
                _infect(s)

func _ground_height(x: float, z: float, pad: float) -> float:
    var top := 0.0
    for o in obstacle_bins.get(floori(z / OBSTACLE_BIN_SIZE), []):
        if absf(o.pos.z - z) > o.hz + pad or absf(o.pos.x - x) > o.hx + pad:
            continue
        top = maxf(top, o.top)
    return top

func _update_pickups(delta: float) -> void:
    var pp: Vector3 = player.global_position + Vector3(0, 0.6, 0)
    var t := Time.get_ticks_msec() * 0.001
    for p in active_pickups:
        if p.taken:
            continue
        var n: Node3D = p.node
        var pz: float = p.pos.z
        n.rotation.y += delta * (3.5 if p.kind == "coin" else 2.0)
        n.position.y = p.pos.y + sin(t * 3.0 + pz) * 0.12
        if state == St.RUN and pp.distance_squared_to(n.position) < 1.44:
            _collect(p)

func _collect(p: Dictionary) -> void:
    p.taken = true
    var n: Node3D = p.node
    var pos := n.global_position
    n.queue_free()
    match p.kind:
        "coin":
            run_coins += 1
            coin_combo += 1
            coin_combo_t = 0.6
            Game.sfx("coin", -7.0, 1.0 + minf(coin_combo, 8) * 0.04)
            FX.sparkle(self, pos, Color("ffd84a"), 8, 2.5, 0.3)
            _bump(hud.coin_pill)
        "heart":
            if hearts < max_hearts:
                hearts += 1
                _refresh_hearts(true)
                FX.float_text(self, pos + Vector3(0, 0.5, 0), Game.t("plus_heart"), Color("ff7a9a"), 56)
            else:
                run_coins += 5
                FX.float_text(self, pos + Vector3(0, 0.5, 0), "+5", Color("ffd84a"), 56)
            Game.sfx("heart", -2.0)
            FX.sparkle(self, pos, Color("ff7a9a"), 18, 3.5)
            FX.ring(self, pos - Vector3(0, 0.8, 0), Color("ff7a9a"))
        "bolt":
            boost_t = 4.5
            player.speed_mult = 1.35
            player.stamina = 1.0
            player.exhausted = false
            Game.sfx("powerup", -2.0)
            FX.sparkle(self, pos, Color("ffd84a"), 22, 4.0)
            FX.ring(self, pos - Vector3(0, 0.8, 0), Color("ffd84a"))
            _toast(Game.t("boost"), Color("ffd84a"))

# ================================================================ end states
func _win() -> void:
    if touch_controls: touch_controls.set_playing(false)
    state = St.WIN
    state_t = 0.0
    player.frozen = true
    player.model.happy = true
    for s in survivors.duplicate():
        _friend_saved(s)
    Game.sfx("horn", -2.0)
    Game.sfx("win", -3.0)
    _banner(Game.t("escaped"), Color("9be26b"), "", 2.4)
    FX.confetti(self, Vector3(1.0, 6.0, BUS_Z + 2.0), 160, Vector3(6, 1, 3), 6.0)
    var door := Vector3(3.5, 0.0, BUS_Z + 1.4)
    var tw := create_tween()
    tw.tween_interval(0.5)
    tw.tween_property(player, "global_position", door + Vector3(0, 0, 0.8), 0.6).set_trans(Tween.TRANS_SINE)
    tw.tween_callback(func():
        player.model.happy = false
        FX.puff(self, door + Vector3(0, 1.0, 0), Color.WHITE, 12))
    tw.tween_property(player, "scale", Vector3(0.05, 0.05, 0.05), 0.25)
    tw.tween_callback(func():
        player.visible = false
        hud.zone.visible = false
        hud.bus_arrow.visible = false
        hud.bus_sign.visible = false
        Game.sfx("engine", -4.0))
    tw.tween_interval(0.4)
    tw.tween_property(bus, "position:x", 90.0, 3.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    get_tree().create_timer(3.6, false).timeout.connect(func(): _show_results(true))

func _lose() -> void:
    if touch_controls: touch_controls.set_playing(false)
    state = St.LOSE
    state_t = 0.0
    player.frozen = true
    player.model.visible = true
    var tw := create_tween()
    tw.tween_property(player.model, "rotation:z", PI * 0.5, 0.35).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
    Game.sfx("infect", 0.0)
    _banner(Game.t("caught"), Color("ff8a7a"), "", 2.2)
    for z in zombies:
        z.state = "chase"
    get_tree().create_timer(2.6, false).timeout.connect(func(): _show_results(false))

func _show_results(won: bool) -> void:
    if state == St.END:
        return
    state = St.END
    var dist := int(clampf(-player.global_position.z, 0.0, LEVEL_LEN))
    if won:
        dist = int(LEVEL_LEN)
    var lines: Array = []
    var total := run_coins
    lines.append([Game.t("r_coins"), run_coins])
    if won:
        lines.append([Game.t("r_escape"), 100])
        total += 100
        if saved > 0:
            lines.append([Game.t("r_friends") % saved, saved * 40])
            total += saved * 40
    else:
        var db := int(dist / 6.0)
        lines.append([Game.t("r_distance"), db])
        total += db
    var mult: float = [0.8, 1.0, 1.3][diff]
    if mult != 1.0:
        var extra := int(round(total * mult)) - total
        lines.append([Game.t("r_diff") + " x%.1f" % mult, extra])
        total += extra
    var st: Dictionary = Game.data.stats
    var record := false
    Game.stat_add("zr_played")
    if dist > int(st.get("zr_best", 0)):
        st.zr_best = dist
        record = not won
    if won:
        Game.stat_add("zr_escapes")
        Game.stat_add("zr_saved", saved)
        var bt: float = float(st.get("zr_best_time", 0.0))
        if bt <= 0.0 or run_time < bt:
            st.zr_best_time = run_time
            record = true
    var daily_bonus := Game.record_daily("zombie", 0, run_coins)
    if daily_bonus > 0:
        lines.append([Game.t("daily_reward"), daily_bonus])
        total += daily_bonus
    Game.add_coins(total)
    if not won:
        Game.sfx("lose", -2.0)
    var m := UI.modal(hud.root, 0.55)
    var p := UI.panel(UI.NAVY, 32, 30)
    p.custom_minimum_size = Vector2(560, 0)
    m[1].add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    p.add_child(v)
    v.add_child(UI.title(Game.t("escaped") if won else Game.t("caught"), 64, Color("9be26b") if won else Color("ff8a7a")))
    var info := UI.label("%s: %s   ·   %s" % [Game.t("r_time"), UI.fmt_time(run_time), Game.t("dist") % dist], 24, Color(1, 1, 1, 0.9), 0)
    info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(info)
    if record:
        var rl := UI.label(Game.t("new_record"), 26, Color("ffd84a"), 8, Color(0.3, 0.2, 0.0, 0.6), UI.FONT_BLACK)
        rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        v.add_child(rl)
    var box := UI.flat_panel(Color(0, 0, 0, 0.2), 18, 14)
    v.add_child(box)
    var lv := VBoxContainer.new()
    lv.add_theme_constant_override("separation", 6)
    box.add_child(lv)
    for ln in lines:
        lv.add_child(_reward_row(str(ln[0]), int(ln[1]), 24, Color(1, 1, 1, 0.9)))
    lv.add_child(_reward_row(Game.t("r_total"), total, 32, Color("ffd84a")))
    for unlock in Game.last_journey_unlocks:
        var unlocked := UI.label(Game.t(str(unlock)), 20, Color("a5edba"), 2, Color.BLACK, UI.FONT_BLACK)
        unlocked.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        lv.add_child(unlocked)
    v.add_child(UI.spacer(8))
    var hb := HBoxContainer.new()
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_theme_constant_override("separation", 14)
    v.add_child(hb)
    var again := UI.button(Game.t("play_again"), UI.GREEN, Vector2(240, 70), 26)
    again.pressed.connect(func(): Game.goto(Game.SCENE_ZOMBIE))
    hb.add_child(again)
    var menu := UI.button(Game.t("menu"), UI.PURPLE, Vector2(200, 70), 26)
    menu.pressed.connect(func(): Game.goto(Game.SCENE_MENU))
    hb.add_child(menu)
    UI.pop_in(p)
    Game.last_result = {"mode": "zombie", "won": won, "coins": total}
    if auto:
        print("[autotest] zombie result won=", won, " coins=", total, " dist=", dist, " saved=", saved, " time=", run_time)
        await get_tree().create_timer(1.0).timeout
        await Game.shot("zr_results")
        if Game.autotest == "zombie":
            get_tree().quit()
        else:
            Game.goto(Game.SCENE_MENU)

func _reward_row(text: String, amount: int, size: int, color: Color) -> HBoxContainer:
    var row := HBoxContainer.new()
    var l := UI.label(text, size, color, 0)
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(l)
    row.add_child(UI.label(("+" if amount >= 0 else "") + str(amount), size, color, 6, Color(0, 0, 0, 0.35), UI.FONT_BLACK))
    row.add_child(UI.tex_rect(preload("res://assets/ui/icons/coin.png"), Vector2(size + 8, size + 8)))
    return row

# ================================================================ camera
func _update_camera(delta: float, snap := false) -> void:
    var pp: Vector3 = player.global_position
    var pos := Vector3(pp.x * 0.75, 7.0 + pp.y * 0.4, pp.z + 8.8)
    var look := Vector3(pp.x * 0.85, 0.9, pp.z - 6.5)
    if state == St.INTRO:
        var k := smoothstep(0.6, 2.0, state_t)
        var ipos := Vector3(3.6, 2.4, pp.z - 6.0)
        var ilook := Vector3(0, 1.0, pp.z + 6.0)
        pos = ipos.lerp(pos, k)
        look = ilook.lerp(look, k)
        snap = true
    elif state == St.WIN or (state == St.END and hearts > 0):
        pos = Vector3(-3.0, 6.5, BUS_Z + 17.0)
        look = Vector3(2.0, 1.5, BUS_Z)
    elif state == St.LOSE or state == St.END:
        pos = pp + Vector3(2.5, 4.0, 6.0)
        look = pp + Vector3(0, 0.6, 0)
    if snap:
        cam_pos = pos
        cam_look = look
    else:
        var k2 := 1.0 - exp(-delta * (6.0 if state == St.RUN else 2.5))
        cam_pos = cam_pos.lerp(pos, k2)
        cam_look = cam_look.lerp(look, k2)
    cam.global_position = cam_pos
    cam.look_at(cam_look, Vector3.UP)
    var fov := 62.0
    if player.sprinting:
        fov += 5.0
    if boost_t > 0.0:
        fov += 5.0
    cam.fov = lerpf(cam.fov, fov, 1.0 - exp(-delta * 4.0))
    if shake > 0.0:
        shake = maxf(0.0, shake - delta * 1.8)
        cam.h_offset = randf_range(-1, 1) * shake * 0.3
        cam.v_offset = randf_range(-1, 1) * shake * 0.3
    else:
        cam.h_offset = 0.0
        cam.v_offset = 0.0

# ================================================================ HUD
func _build_touch_controls() -> void:
    if not OS.has_feature("mobile") and not Game.force_touch: return
    var layer := CanvasLayer.new()
    layer.layer = 11
    add_child(layer)
    touch_controls = TouchControls.new()
    layer.add_child(touch_controls)
    touch_controls.jump.connect(func():
        if not auto and (state == St.RUN or state == St.INTRO): player.jump_pressed = true)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(layer)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    hud.root = root
    # danger vignette
    var vg := ColorRect.new()
    vg.set_anchors_preset(Control.PRESET_FULL_RECT)
    vg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sh := Shader.new()
    sh.code = "shader_type canvas_item;\nuniform float strength = 0.0;\nuniform vec4 tint : source_color = vec4(0.85, 0.08, 0.12, 1.0);\nvoid fragment() {\n\tvec2 uv = UV - vec2(0.5);\n\tfloat d = length(uv * vec2(1.0, 0.8));\n\tfloat v = smoothstep(0.28, 0.78, d);\n\tCOLOR = vec4(tint.rgb, v * strength);\n}\n"
    vignette_mat = ShaderMaterial.new()
    vignette_mat.shader = sh
    vg.material = vignette_mat
    root.add_child(vg)
    # hearts (top-left)
    var hb := HBoxContainer.new()
    hb.position = Vector2(22, 18)
    hb.add_theme_constant_override("separation", 4)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hb)
    hud.hearts = []
    for i in max_hearts:
        var h := UI.tex_rect(preload("res://assets/ui/icons/heart.png"), Vector2(52, 52))
        hb.add_child(h)
        hud.hearts.append(h)
    # progress (top-center)
    var top := VBoxContainer.new()
    top.set_anchors_preset(Control.PRESET_TOP_WIDE)
    top.offset_top = 18
    top.alignment = BoxContainer.ALIGNMENT_BEGIN
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(top)
    var prow := HBoxContainer.new()
    prow.alignment = BoxContainer.ALIGNMENT_CENTER
    prow.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top.add_child(prow)
    var track := Control.new()
    track.custom_minimum_size = Vector2(440, 44)
    track.mouse_filter = Control.MOUSE_FILTER_IGNORE
    prow.add_child(track)
    var bar := UI.bar(440, 18, Color("9be26b"))
    bar.position = Vector2(0, 13)
    track.add_child(bar)
    hud.progress = bar
    var horde_icon := UI.tex_rect(preload("res://assets/ui/icons/zombie.png"), Vector2(44, 44))
    track.add_child(horde_icon)
    hud.horde_icon = horde_icon
    var me_icon := UI.tex_rect(preload("res://assets/ui/icons/capy.png"), Vector2(46, 46))
    track.add_child(me_icon)
    hud.me_icon = me_icon
    var bus_l := UI.label(Game.t("bus_sign"), 18, Color("ffd84a"), 6, Color(0.3, 0.2, 0, 0.8), UI.FONT_BLACK)
    bus_l.position = Vector2(446, 10)
    track.add_child(bus_l)
    var dist_l := UI.label("", 20, Color.WHITE, 6, Color(0, 0, 0, 0.45))
    dist_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    top.add_child(dist_l)
    hud.dist = dist_l
    var toast := UI.title("", 30, Color.WHITE)
    toast.modulate.a = 0.0
    top.add_child(toast)
    hud.toast = toast
    # coins (top-right)
    var pr := UI.pill(preload("res://assets/ui/icons/coin.png"), "0")
    var cp: Control = pr[0]
    cp.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    cp.position = Vector2(-250, 20)
    root.add_child(cp)
    hud.coin_pill = cp
    hud.coin_l = pr[1]
    var pb := UI.button("II", UI.NAVY, Vector2(62, 62), 26)
    pb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    pb.position = Vector2(-80, 16)
    pb.pressed.connect(_toggle_pause)
    root.add_child(pb)
    # banner
    var bn := VBoxContainer.new()
    bn.set_anchors_preset(Control.PRESET_FULL_RECT)
    bn.alignment = BoxContainer.ALIGNMENT_CENTER
    bn.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bn.offset_bottom = -140
    root.add_child(bn)
    var big := UI.title("", 104, Color.WHITE)
    var sub := UI.title("", 32, Color.WHITE)
    bn.add_child(big)
    bn.add_child(sub)
    hud.banner = big
    hud.banner_sub = sub
    hud.banner_box = bn
    bn.modulate.a = 0.0
    # bottom: stamina + hint
    var bottom := VBoxContainer.new()
    bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    bottom.offset_top = -86
    bottom.offset_bottom = -12
    bottom.alignment = BoxContainer.ALIGNMENT_END
    bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(bottom)
    var srow := HBoxContainer.new()
    srow.alignment = BoxContainer.ALIGNMENT_CENTER
    srow.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bottom.add_child(srow)
    srow.add_child(UI.tex_rect(preload("res://assets/ui/icons/bolt.png"), Vector2(34, 34)))
    var st := UI.bar(240, 16, Color("f2c037"))
    st.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    srow.add_child(st)
    hud.stamina = st
    var hint := UI.label(Game.t("hint_zr"), 17, Color(1, 1, 1, 0.92), 5, Color(0, 0, 0, 0.5))
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    if OS.has_feature("mobile") or Game.force_touch: hint.text = ""
    bottom.add_child(hint)
    hud.hint = hint
    hud.hint_t = 12.0

func _refresh_hearts(anim := false) -> void:
    for i in hud.hearts.size():
        var h: TextureRect = hud.hearts[i]
        var on: bool = i < hearts
        h.modulate = Color.WHITE if on else Color(0.2, 0.2, 0.3, 0.55)
        if anim:
            _bump(h)

func _bump(c: Control) -> void:
    c.pivot_offset = c.size * 0.5
    var tw := c.create_tween()
    tw.tween_property(c, "scale", Vector2(1.25, 1.25), 0.07)
    tw.tween_property(c, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK)

func _banner(text: String, color: Color, sub := "", hold := 1.2) -> void:
    var big: Label = hud.banner
    big.text = text
    big.label_settings.font_color = color
    hud.banner_sub.text = sub
    var box: Control = hud.banner_box
    box.pivot_offset = box.size * 0.5
    box.scale = Vector2(0.6, 0.6)
    box.modulate.a = 1.0
    if hud.has("banner_tw") and hud.banner_tw and hud.banner_tw.is_valid():
        hud.banner_tw.kill()
    var tw := box.create_tween()
    tw.tween_property(box, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_interval(hold)
    tw.tween_property(box, "modulate:a", 0.0, 0.3)
    hud.banner_tw = tw

func _toast(text: String, color: Color) -> void:
    var l: Label = hud.toast
    l.text = text
    l.label_settings.font_color = color
    l.modulate.a = 1.0
    if hud.has("toast_tw") and hud.toast_tw and hud.toast_tw.is_valid():
        hud.toast_tw.kill()
    var tw := l.create_tween()
    tw.tween_interval(1.6)
    tw.tween_property(l, "modulate:a", 0.0, 0.4)
    hud.toast_tw = tw

func _update_hud(delta: float) -> void:
    var pz: float = player.global_position.z
    var prog := clampf(-pz / LEVEL_LEN, 0.0, 1.0)
    hud.progress.value = prog
    hud.me_icon.position = Vector2(prog * 440.0 - 23.0, -2.0)
    var hprog := clampf(-horde_z / LEVEL_LEN, 0.0, 1.0)
    hud.horde_icon.position = Vector2(hprog * 440.0 - 22.0, -1.0)
    var distance_text: String = Game.t("dist") % int(maxf(0.0, pz - BUS_Z))
    if hud.dist.text != distance_text: hud.dist.text = distance_text
    var coins_text := str(run_coins)
    if hud.coin_l.text != coins_text: hud.coin_l.text = coins_text
    hud.stamina.value = player.stamina
    hud.hint_t -= delta
    if hud.hint_t < 0.0:
        hud.hint.modulate.a = maxf(0.0, hud.hint.modulate.a - delta)
    var gap := horde_z - pz
    var danger := clampf(1.0 - (gap - 2.0) / 9.0, 0.0, 1.0) if state == St.RUN else 0.0
    var pulse := 0.75 + 0.25 * sin(Time.get_ticks_msec() * 0.012)
    vignette_mat.set_shader_parameter("strength", maxf(danger * 0.55 * pulse, hurt_flash * 0.7))
    if danger > 0.6 and state == St.RUN:
        _horde_warned -= delta
        if _horde_warned <= 0.0:
            _horde_warned = 6.0
            _toast(Game.t("horde"), Color("ff8a7a"))
    var t := Time.get_ticks_msec() * 0.001
    hud.zone.scale = Vector3.ONE * (1.0 + sin(t * 4.0) * 0.06)
    hud.bus_arrow.position.y = 5.6 + sin(t * 4.0) * 0.3
    hud.bus_arrow.rotation.y += delta * 1.5
    if auto:
        _autotest_step()

func _toggle_pause() -> void:
    if touch_controls: touch_controls.reset_controls()
    if state == St.END or state == St.WIN or state == St.LOSE:
        return
    if pause_ov and is_instance_valid(pause_ov):
        get_tree().paused = false
        if touch_controls: touch_controls.set_playing(true)
        UI.close_modal(pause_ov)
        pause_ov = null
        return
    get_tree().paused = true
    if touch_controls: touch_controls.set_playing(false)
    var m := UI.modal(hud.root, 0.55)
    pause_ov = m[0]
    var p := UI.panel(UI.NAVY, 30, 30)
    m[1].add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    p.add_child(v)
    v.add_child(UI.title(Game.t("paused"), 54))
    var b1 := UI.button(Game.t("resume"), UI.GREEN, Vector2(320, 70), 28)
    b1.pressed.connect(_toggle_pause)
    v.add_child(b1)
    var b2 := UI.button(Game.t("restart"), UI.ORANGE, Vector2(320, 70), 28)
    b2.pressed.connect(func(): Game.goto(Game.SCENE_ZOMBIE))
    v.add_child(b2)
    var b3 := UI.button(Game.t("menu"), UI.PURPLE, Vector2(320, 70), 28)
    b3.pressed.connect(func(): Game.goto(Game.SCENE_MENU))
    v.add_child(b3)
    UI.pop_in(p)

# ================================================================ autotest
func _autotest_step() -> void:
    if state == St.INTRO and state_t > 0.8 and not _shots.has("intro"):
        _shots.intro = true
        Game.shot("zr_intro")
    if state == St.RUN and run_time > 5.0 and not _shots.has("run1"):
        _shots.run1 = true
        Game.shot("zr_run1")
    if state == St.RUN and run_time > 18.0 and not _shots.has("run2"):
        _shots.run2 = true
        Game.shot("zr_run2")
        print("[autotest] zombie z=", player.global_position.z, " hearts=", hearts, " coins=", run_coins, " survivors=", survivors.size())
    if state == St.WIN and state_t > 1.4 and not _shots.has("win"):
        _shots.win = true
        Game.shot("zr_win")
