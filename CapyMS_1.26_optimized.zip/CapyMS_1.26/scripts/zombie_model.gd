extends Node3D
## Visual zombie capybara: instances the Blender model with a random shirt
## and animates a goofy shamble procedurally.

const ZOMBIE_SCENE := preload("res://assets/models/zombie.glb")
const SHIRTS := [Color("5a4a8c"), Color("4f6fa8"), Color("8c5a4a"), Color("6b6b6b"), Color("a8844f"), Color("4f8c7a"), Color("9c4f72")]

var root: Node3D
var body: Node3D
var head: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var base_rot := {}
var base_pos := {}
var surfaces: Array = []
var surfaces_by_name := {}
static var _variant_cache: Dictionary = {}
var meshes: Array = []
var move_amount := 0.0
var t := 0.0
var phase := 0.0
var lunge := 0.0
var rise := 0.0

func _init() -> void:
    root = ZOMBIE_SCENE.instantiate()
    add_child(root)
    body = root.find_child("Body", true, false)
    head = root.find_child("Head", true, false)
    arm_l = root.find_child("ArmL", true, false)
    arm_r = root.find_child("ArmR", true, false)
    leg_l = root.find_child("LegL", true, false)
    leg_r = root.find_child("LegR", true, false)
    for n in [body, head, arm_l, arm_r, leg_l, leg_r]:
        base_rot[n] = n.rotation
        base_pos[n] = n.position
    _collect(root)
    t = randf() * 10.0
    phase = randf() * TAU
    var c: Color = SHIRTS.pick_random()
    _set_mat("ZShirt", c)
    _set_mat("ZShirtDark", c.darkened(0.3))
    var sc := randf_range(0.92, 1.08)
    scale = Vector3(sc, sc, sc)

func _collect(n: Node) -> void:
    if n is MeshInstance3D and n.mesh:
        meshes.append(n)
        for i in n.mesh.get_surface_count():
            var m: Material = n.mesh.surface_get_material(i)
            var entry := {"mi": n, "i": i, "name": (m.resource_name if m else ""), "mat": m}
            surfaces.append(entry)
            if not surfaces_by_name.has(entry.name):
                surfaces_by_name[entry.name] = []
            surfaces_by_name[entry.name].append(entry)
    for c in n.get_children():
        _collect(c)

func _set_mat(mat_name: String, color: Color) -> void:
    for s in surfaces_by_name.get(mat_name, []):
        if s.mat is BaseMaterial3D:
            var key: Array = [s.mat, color]
            var m: BaseMaterial3D = _variant_cache.get(key)
            if m == null:
                m = (s.mat as BaseMaterial3D).duplicate()
                m.albedo_color = color
                if _variant_cache.size() >= 128:
                    _variant_cache.clear()
                _variant_cache[key] = m
            s.mi.set_surface_override_material(s.i, m)

func do_lunge() -> void:
    lunge = 1.0

## Plays a "rising up" transformation (used when a survivor gets infected).
func do_rise() -> void:
    rise = 1.0

func _process(delta: float) -> void:
    t += delta
    var m := clampf(move_amount, 0.0, 1.3)
    phase += delta * lerpf(2.5, 10.0, clampf(m, 0.0, 1.0))
    var s := sin(phase)
    leg_l.rotation.x = base_rot[leg_l].x + s * 0.6 * m
    leg_r.rotation.x = base_rot[leg_r].x - s * 0.6 * m
    body.rotation.z = sin(phase) * (0.06 + 0.06 * m) + sin(t * 0.8) * 0.04
    body.rotation.x = base_rot[body].x - 0.12 * m - 0.35 * lunge
    body.position.y = base_pos[body].y + absf(cos(phase)) * 0.05 * m
    arm_l.rotation.x = base_rot[arm_l].x + sin(t * 3.3 + 1.0) * 0.14 - 0.4 * lunge
    arm_r.rotation.x = base_rot[arm_r].x + sin(t * 3.0) * 0.14 - 0.4 * lunge
    arm_l.rotation.z = base_rot[arm_l].z + sin(t * 1.9) * 0.06
    arm_r.rotation.z = base_rot[arm_r].z - sin(t * 2.2) * 0.06
    head.rotation.z = base_rot[head].z + sin(t * 1.3) * 0.16
    head.rotation.x = base_rot[head].x + sin(t * 2.1) * 0.08
    if lunge > 0.0:
        lunge = maxf(0.0, lunge - delta * 2.5)
    if rise > 0.0:
        rise = maxf(0.0, rise - delta * 1.4)
        var r := 1.0 - rise
        root.scale = Vector3.ONE * (0.4 + 0.6 * ease(r, 0.4))
        root.rotation.y = rise * TAU
    else:
        root.scale = Vector3.ONE
        root.rotation.y = 0.0
