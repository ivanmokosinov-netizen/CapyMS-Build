extends Node3D
## BIG FOOTBALL — 3 vs 3 arcade football with a huge ball against bots.
## Blue team (player + 2 bots) attacks to the right (+X).

const UI := preload("res://scripts/ui_football.gd")
const TouchControls := preload("res://scripts/touch_controls_football.gd")
const FX := preload("res://scripts/fx.gd")
const W := preload("res://scripts/world_football.gd")
const CapyBody := preload("res://scripts/capy_body.gd")
const BALL_SCENE := preload("res://assets/models/ball.glb")
const GOAL_SCENE := preload("res://assets/models/goal.glb")
const STADIUM_SCENE := preload("res://assets/models/stadium.glb")
const RING_TEX := preload("res://assets/textures/ring.png")

const HALF_X := 22.0
const HALF_Z := 13.0
const WALL_X := 22.6
const WALL_Z := 13.85
const GOAL_W := 3.42
const GOAL_H := 2.95
const GOAL_D := 2.05
const BALL_R := 0.55
const CHAR_R := 0.45
const MATCH_TIME := 180.0
const TEAM_COLORS := [Color("3f7fd9"), Color("e0504a")]
const GK_COLORS := [Color("27b39f"), Color("f29b30")]
const BOT_SKINS := ["sporty", "cool", "party", "fan", "dj", "ninja", "pirate", "gentleman", "king", "golden", "zombie"]

enum St {KICKOFF, PLAY, GOAL, END}

var state := St.KICKOFF
var state_t := 0.0
var time_left := MATCH_TIME
var score := [0, 0]
var player_goals := 0
var diff := 1
var chars: Array = []
var player
var gks := [null, null]
var ball: RigidBody3D
var cam: Camera3D
var cam_focus := Vector3.ZERO
var shake := 0.0
var last_touch = null
var kick_buf := 0.0
var pass_buf := 0.0
var crowd: Node3D
var crowd_y := 0.0
var excite := 0.0
var crowd_audio: AudioStreamPlayer
var trail: CPUParticles3D
var nets: Array = []
var hud := {}
var touch_controls: Control = null
var pause_ov: Control = null
var post_cd := 0.0
var bot_speed := 5.9
var auto := false
var go_done := false
var scoring_team := 0
var arrow: MeshInstance3D
var hint_t := 14.0
var _shots_taken := {}

func _ready() -> void:
    diff = Game.difficulty()
    auto = Game.autotest != ""
    if auto:
        time_left = 50.0
    bot_speed = [5.0, 5.75, 6.3][diff]
    _build_world()
    _build_colliders()
    _spawn_ball()
    _spawn_teams()
    _build_hud()
    _build_touch_controls()
    cam = Camera3D.new()
    cam.fov = 44.0
    cam.far = 400.0
    add_child(cam)
    cam.make_current()
    _update_camera(1.0, true)
    Game.play_music("football")
    crowd_audio = AudioStreamPlayer.new()
    crowd_audio.stream = load("res://assets/audio/crowd_loop.ogg")
    if crowd_audio.stream is AudioStreamOggVorbis:
        (crowd_audio.stream as AudioStreamOggVorbis).loop = true
    crowd_audio.bus = "SFX"
    crowd_audio.volume_db = -15.0
    add_child(crowd_audio)
    crowd_audio.play()
    _kickoff(0)

# ================================================================ world
func _build_world() -> void:
    W.environment(self, Color("3b74d6"), Color("b4d3f5"), Color("5d8a4a"), {"ambient": 0.9, "exposure": 1.0})
    W.sun(self, Vector3(-52, -28, 0), 1.25, Color(1.0, 0.95, 0.86), 95.0)
    # field + surrounding grass
    W.plane(self, Vector2(56, 34), Vector3.ZERO, W.tex_mat(load("res://assets/textures/field.jpg")))
    W.plane(self, Vector2(400, 400), Vector3(0, -0.04, 0), W.tex_mat(load("res://assets/textures/grass.png"), Vector3(90, 90, 1), Color(0.72, 0.85, 0.66)))
    var stadium: Node3D = STADIUM_SCENE.instantiate()
    add_child(stadium)
    crowd = stadium.find_child("Crowd", true, false)
    if crowd:
        crowd_y = crowd.position.y
    for side in [-1, 1]:
        var g: Node3D = GOAL_SCENE.instantiate()
        g.position = Vector3(HALF_X * side, 0, 0)
        g.rotation.y = deg_to_rad(90.0 * side)
        add_child(g)
        var net = g.find_child("GoalNet", true, false)
        nets.append(net)
    # advertising boards
    var board_mat := W.tex_mat(load("res://assets/textures/boards.png"), Vector3(1, 1, 1), Color.WHITE, 0.6)
    var back_mat := W.mat(Color("363a63"), 0.8)
    var bh := 0.95
    for sz in [-1, 1]:
        _board(Vector3(0, bh * 0.5, sz * (WALL_Z + 0.08)), 45.6, 0.0 if sz < 0 else PI, board_mat, back_mat, bh)
    for sx in [-1, 1]:
        for sz in [-1, 1]:
            var len := WALL_Z - 3.8
            _board(Vector3(sx * (WALL_X + 0.08), bh * 0.5, sz * (3.8 + len * 0.5)), len, -sx * PI * 0.5, board_mat, back_mat, bh)
    # corner flags
    var pole_mat := W.mat(Color.WHITE, 0.5)
    var flag_mat := W.mat(Color("f2c037"), 0.7)
    flag_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    for sx in [-1, 1]:
        for sz in [-1, 1]:
            var p := MeshInstance3D.new()
            var cm := CylinderMesh.new()
            cm.top_radius = 0.04
            cm.bottom_radius = 0.04
            cm.height = 1.6
            cm.material = pole_mat
            p.mesh = cm
            p.position = Vector3(sx * HALF_X, 0.8, sz * HALF_Z)
            add_child(p)
            var f := MeshInstance3D.new()
            var qm := QuadMesh.new()
            qm.size = Vector2(0.45, 0.32)
            qm.material = flag_mat
            f.mesh = qm
            f.position = Vector3(sx * HALF_X - sx * 0.23, 1.42, sz * HALF_Z)
            add_child(f)

func _board(pos: Vector3, length: float, rot_y: float, face_mat: StandardMaterial3D, back_mat: Material, h: float) -> void:
    var holder := Node3D.new()
    holder.position = pos
    holder.rotation.y = rot_y
    add_child(holder)
    W.mesh_box(holder, Vector3(length, h, 0.14), Vector3(0, 0, -0.08), back_mat)
    var q := MeshInstance3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(length, h * 0.86)
    var m: StandardMaterial3D = face_mat.duplicate()
    m.uv1_scale = Vector3(length / (h * 0.86 * 16.0), 1, 1)
    m.emission_enabled = true
    m.emission_texture = m.albedo_texture
    m.emission_energy_multiplier = 0.25
    qm.material = m
    q.mesh = qm
    q.position = Vector3(0, 0, 0.0)
    q.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    holder.add_child(q)

func _build_colliders() -> void:
    var walls := W.static_body(self, 1, 0.55, 0.25)
    W.box_shape(walls, Vector3(160, 2, 120), Vector3(0, -1, 0))
    for sz in [-1, 1]:
        W.box_shape(walls, Vector3(50, 12, 1), Vector3(0, 6, sz * (WALL_Z + 0.5)))
    for sx in [-1, 1]:
        var seg := WALL_Z + 0.6 - 3.75
        for sz in [-1, 1]:
            W.box_shape(walls, Vector3(1, 12, seg), Vector3(sx * (WALL_X + 0.5), 6, sz * (3.75 + seg * 0.5)))
        W.box_shape(walls, Vector3(1, 8, 7.6), Vector3(sx * (WALL_X + 0.5), 3.25 + 4.0, 0))
        # goal inside: back, sides, roof
        W.box_shape(walls, Vector3(0.4, 3.6, 7.8), Vector3(sx * (HALF_X + GOAL_D + 0.25), 1.8, 0))
        for sz in [-1, 1]:
            W.box_shape(walls, Vector3(GOAL_D + 0.7, 3.6, 0.3), Vector3(sx * (HALF_X + GOAL_D * 0.5 + 0.3), 1.8, sz * 3.78))
        W.box_shape(walls, Vector3(GOAL_D + 0.7, 0.3, 7.8), Vector3(sx * (HALF_X + GOAL_D * 0.5 + 0.3), GOAL_H + 0.3, 0))
        # corner cut-offs
        for sz in [-1, 1]:
            var c := Vector3(sx * (WALL_X - 1.0), 6, sz * (WALL_Z - 1.0)) + Vector3(sx, 0, sz) * 0.35
            W.box_shape(walls, Vector3(3.2, 12, 1.0), c, atan2(float(sz), float(sx)))
    W.box_shape(walls, Vector3(60, 1, 40), Vector3(0, 13, 0))
    # posts & crossbars (metal sound on hit)
    var posts := W.static_body(self, 1, 0.7, 0.2)
    posts.name = "Posts"
    for sx in [-1, 1]:
        for sz in [-1, 1]:
            W.cyl_shape(posts, 0.12, GOAL_H + 0.1, Vector3(sx * HALF_X, (GOAL_H + 0.1) * 0.5, sz * 3.59))
        W.box_shape(posts, Vector3(0.24, 0.24, 7.4), Vector3(sx * HALF_X, GOAL_H + 0.08, 0))

func _spawn_ball() -> void:
    ball = RigidBody3D.new()
    ball.collision_layer = 4
    ball.collision_mask = 1
    ball.mass = 1.0
    ball.gravity_scale = 1.25
    var pm := PhysicsMaterial.new()
    pm.bounce = 0.55
    pm.friction = 0.6
    ball.physics_material_override = pm
    ball.linear_damp = 0.4
    ball.angular_damp = 1.0
    ball.continuous_cd = true
    ball.can_sleep = false
    ball.contact_monitor = true
    ball.max_contacts_reported = 4
    var cs := CollisionShape3D.new()
    var sp := SphereShape3D.new()
    sp.radius = BALL_R
    cs.shape = sp
    ball.add_child(cs)
    ball.add_child(BALL_SCENE.instantiate())
    add_child(ball)
    ball.body_entered.connect(_on_ball_body)
    # speed trail
    trail = CPUParticles3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(0.8, 0.8)
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    m.albedo_texture = preload("res://assets/textures/glow.png")
    m.vertex_color_use_as_albedo = true
    qm.material = m
    trail.mesh = qm
    trail.amount = 40
    trail.lifetime = 0.35
    trail.local_coords = false
    trail.gravity = Vector3.ZERO
    trail.initial_velocity_min = 0.0
    trail.initial_velocity_max = 0.2
    var g := Gradient.new()
    g.set_color(0, Color(1, 1, 1, 0.55))
    g.set_color(1, Color(1, 1, 1, 0))
    trail.color_ramp = g
    var c := Curve.new()
    c.add_point(Vector2(0, 1))
    c.add_point(Vector2(1, 0.2))
    trail.scale_amount_curve = c
    trail.emitting = false
    ball.add_child(trail)

func _on_ball_body(body: Node) -> void:
    var v := ball.linear_velocity.length()
    if body.name == "Posts" and v > 3.0 and post_cd <= 0.0:
        post_cd = 0.3
        Game.sfx("post", linear_to_db(clampf(v / 18.0, 0.2, 1.0)))
        shake = maxf(shake, 0.15)
    elif v > 6.0 and post_cd <= 0.0 and ball.global_position.y > 0.8:
        post_cd = 0.15
        Game.sfx("bump", linear_to_db(clampf(v / 25.0, 0.1, 0.6)), 1.3)

func _spawn_teams() -> void:
    var skins := BOT_SKINS.duplicate()
    skins.shuffle()
    var bot_names := Game.random_bot_names(5)
    player = _make_char(0, "player", Game.equipped(), Game.player_nickname())
    player.is_player = true
    player.step_sounds = true
    player.jumped.connect(func(): Game.sfx("jump", -6.0))
    _make_char(0, "mate", skins[0], str(bot_names[0]))
    gks[0] = _make_char(0, "gk", skins[1], str(bot_names[1]))
    _make_char(1, "att", skins[2], str(bot_names[2]))
    _make_char(1, "def", skins[3], str(bot_names[3]))
    gks[1] = _make_char(1, "gk", skins[4], str(bot_names[4]))
    # player arrow
    arrow = MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.26
    cm.bottom_radius = 0.0
    cm.height = 0.42
    cm.radial_segments = 4
    var am := StandardMaterial3D.new()
    am.albedo_color = Color("ffd84a")
    am.emission_enabled = true
    am.emission = Color("ffb800")
    am.emission_energy_multiplier = 0.6
    cm.material = am
    arrow.mesh = cm
    arrow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(arrow)

func _make_char(team: int, role: String, skin: String, nm: String):
    var c = CapyBody.new()
    c.team = team
    c.display_name = nm
    c.set_nametag(nm, Game.player_nick_color() if role == "player" else Color.WHITE, 2.48 if role == "player" else 2.05)
    c.ai = {"role": role, "target": Vector3.ZERO, "think": 0.0, "sprint": false, "want_kick": false,
        "mode": "", "ignore": 0.0, "save_cd": 0.0}
    add_child(c)
    c.set_skin(skin)
    if role != "player":
        c.model.set_jersey(GK_COLORS[team] if role == "gk" else TEAM_COLORS[team])
        c.speed = bot_speed * (1.08 if role == "gk" else 1.0)
        c.sprint_mult = 1.38
    var ring := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    var big: bool = role == "player"
    pm.size = Vector2(2.0, 2.0) if big else Vector2(1.55, 1.55)
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.albedo_texture = RING_TEX
    m.albedo_color = Color("ffd84a") if big else Color(TEAM_COLORS[team], 0.9)
    pm.material = m
    ring.mesh = pm
    ring.position.y = 0.04
    ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    c.add_child(ring)
    chars.append(c)
    return c

# ================================================================ match flow
func _kickoff(team_with_ball: int) -> void:
    state = St.KICKOFF
    state_t = 0.0
    go_done = false
    Engine.time_scale = 1.0
    ball.global_position = Vector3(0, BALL_R + 0.05, 0)
    ball.linear_velocity = Vector3.ZERO
    ball.angular_velocity = Vector3.ZERO
    last_touch = null
    for c in chars:
        c.frozen = true
        c.model.happy = false
        c.stamina = 1.0
        var att := 1.0 if c.team == 0 else -1.0
        var role: String = c.ai.role
        var p := Vector3.ZERO
        match role:
            "player", "att":
                p = Vector3(-att * (1.6 if c.team == team_with_ball else 7.0), 0, 0)
            "mate", "def":
                p = Vector3(-att * 11.0, 0, att * 5.0)
            "gk":
                p = Vector3(-att * (HALF_X - 1.5), 0, 0)
        c.teleport(p, Vector3(att, 0, 0))
        c.ai.target = p
    _banner(Game.t("ready"), Color.WHITE, "", 1.1)

func _start_play() -> void:
    go_done = true
    state = St.PLAY
    state_t = 0.0
    for c in chars:
        c.frozen = false
    Game.sfx("whistle", -3.0)
    _banner(Game.t("go"), Color("ffd84a"), "", 0.7)

func _goal(team: int) -> void:
    state = St.GOAL
    state_t = 0.0
    scoring_team = team
    score[team] += 1
    var sub := ""
    if last_touch != null and last_touch.team == team:
        if last_touch == player:
            if not auto:
                player_goals += 1
            sub = Game.t("you_scored")
        else:
            sub = Game.t("scores") % last_touch.display_name
    else:
        sub = Game.t("own_goal")
    Game.sfx("goal", 0.0)
    Game.sfx("whistle", -8.0)
    excite = 1.0
    var gx := HALF_X * (1.0 if team == 0 else -1.0)
    FX.confetti(self, Vector3(gx, 3.0, 0), 150, Vector3(1.0, 0.5, 3.5), 9.0)
    FX.confetti(self, Vector3(gx * 0.55, 9.0, 0), 140, Vector3(10, 1, 9), 2.0)
    shake = 0.6
    var net = nets[1 if team == 0 else 0]
    if net:
        var tw := create_tween()
        tw.tween_property(net, "scale", Vector3(1.0, 1.0, 1.35), 0.12)
        tw.tween_property(net, "scale", Vector3.ONE, 0.5).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
    _banner(Game.t("goal"), TEAM_COLORS[team].lightened(0.25), sub, 2.4)
    _refresh_score(team)
    for c in chars:
        if c.team == team:
            c.model.happy = true
    Engine.time_scale = 0.4
    get_tree().create_timer(0.8, true, false, true).timeout.connect(func():
        if state == St.GOAL:
            Engine.time_scale = 1.0)

func _end_match() -> void:
    if touch_controls: touch_controls.set_playing(false)
    state = St.END
    state_t = 0.0
    time_left = 0.0
    Engine.time_scale = 1.0
    Game.sfx("whistle_end", -2.0)
    for c in chars:
        c.frozen = true
    var res := 0
    if score[0] > score[1]:
        res = 1
    elif score[0] < score[1]:
        res = -1
    for c in chars:
        if (res == 1 and c.team == 0) or (res == -1 and c.team == 1):
            c.model.happy = true
    _banner(Game.t("time_up"), Color.WHITE, "%d : %d" % [score[0], score[1]], 2.0)
    get_tree().create_timer(2.3, false).timeout.connect(_show_results)

# ================================================================ loop
func _physics_process(delta: float) -> void:
    state_t += delta
    post_cd -= delta
    match state:
        St.KICKOFF:
            if state_t > 1.35 and not go_done:
                _start_play()
        St.PLAY:
            time_left -= delta
            _control_player(delta)
            for c in chars:
                if c != player or auto:
                    _bot(c, delta)
            _ball_contacts(delta)
            _gk_saves()
            _check_goal()
            _check_out()
            if time_left <= 0.0:
                _end_match()
        St.GOAL:
            for c in chars:
                if c != player or auto:
                    c.move_input = c.move_input.move_toward(Vector3.ZERO, delta * 3.0)
            _control_player(delta)
            _ball_contacts(delta)
            if state_t > 3.2:
                _kickoff(1 - scoring_team)
        St.END:
            for c in chars:
                c.move_input = Vector3.ZERO
    _update_camera(delta)
    _update_fx(delta)
    _update_hud(delta)

func _control_player(delta: float) -> void:
    if auto:
        return
    var mv := Game.move_vector()
    if touch_controls and touch_controls.move.length() > 0.01:
        mv = touch_controls.move
    player.move_input = Vector3(mv.x, 0, mv.y)
    player.sprint_input = Input.is_action_pressed("sprint") or (touch_controls != null and touch_controls.sprint)
    player.jump_held = Input.is_action_pressed("jump") or (touch_controls != null and touch_controls.jump_held)
    if state != St.PLAY:
        return
    if kick_buf > 0.0:
        kick_buf -= delta
        if _kick(player, "shoot"):
            kick_buf = 0.0
    if pass_buf > 0.0:
        pass_buf -= delta
        if _kick(player, "pass"):
            pass_buf = 0.0

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("pause"):
        _toggle_pause()
        get_viewport().set_input_as_handled()
        return
    if get_tree().paused or auto:
        return
    if event.is_action_pressed("kick"):
        kick_buf = 0.25
    elif event.is_action_pressed("pass"):
        pass_buf = 0.25
    elif event.is_action_pressed("jump"):
        if state == St.PLAY or state == St.GOAL:
            player.jump_pressed = true

# ================================================================ ball logic
func _ball_contacts(delta: float) -> void:
    var bp := ball.global_position
    var bv := ball.linear_velocity
    for c in chars:
        c.ai.ignore = maxf(0.0, c.ai.ignore - delta)
        if c.ai.ignore > 0.0:
            continue
        var cp: Vector3 = c.global_position
        var h := bp.y - cp.y
        if h < -0.4 or h > 1.85:
            continue
        var d := Vector3(bp.x - cp.x, 0, bp.z - cp.z)
        var dist := d.length()
        var r := CHAR_R + (BALL_R if h < 1.15 else BALL_R * 0.6)
        if dist >= r:
            continue
        var n: Vector3 = d / dist if dist > 0.001 else c.facing
        if h > 0.85 and not c.is_on_floor():
            _header(c)
            return
        var cv := Vector3(c.velocity.x, 0, c.velocity.z)
        var hv := Vector3(bv.x, 0, bv.z)
        var vn := hv.dot(n)
        var cvn := cv.dot(n)
        var target_n := maxf(cvn * 1.12 + 1.3, -vn * 0.45 + maxf(cvn, 0.0) * 0.5)
        if vn < target_n:
            hv += n * (target_n - vn)
        hv += n * (r - dist) * 6.0
        # dribble assist: lateral motion follows the character
        var lat := hv - n * hv.dot(n)
        var clat := cv - n * cvn
        hv = n * hv.dot(n) + lat.lerp(clat, 0.55)
        bv = Vector3(hv.x, bv.y, hv.z)
        if h > 0.6 and bv.y < 0.0:
            bv.y = -bv.y * 0.4
        ball.linear_velocity = bv
        last_touch = c

func _header(c) -> void:
    var att := 1.0 if c.team == 0 else -1.0
    var target := Vector3(att * (HALF_X + 1.0), 1.4, clampf(-c.global_position.z * 0.25, -2.0, 2.0))
    var dir: Vector3 = (target - ball.global_position).normalized()
    if c.facing.dot(Vector3(att, 0, 0)) < 0.1 or ball.global_position.distance_to(target) > 26.0:
        dir = (c.facing + Vector3.UP * 0.3).normalized()
    ball.linear_velocity = dir * 15.5 + Vector3.UP * 2.0
    c.ai.ignore = 0.3
    last_touch = c
    Game.sfx("kick", -3.0, 1.3)
    FX.burst(self, ball.global_position, Color.WHITE, 8, 3.0, 0.08)

func _kick(c, mode: String) -> bool:
    if c.kick_cd > 0.0:
        return false
    var bp := ball.global_position
    var rel: Vector3 = bp - c.global_position
    var h := rel.y
    rel.y = 0.0
    var d := rel.length()
    if d > CHAR_R + BALL_R + 0.8 or h > 1.6:
        return false
    if d > 1.1 and rel.normalized().dot(c.facing) < -0.25:
        return false
    var r: Array
    match mode:
        "shoot":
            r = _shot_dir(c)
        "pass":
            r = _pass_dir(c)
        _:
            r = _clear_dir(c)
    var dir: Vector3 = r[0]
    ball.linear_velocity = dir * float(r[1]) + Vector3.UP * float(r[2])
    ball.angular_velocity = Vector3(randf_range(-9, 9), randf_range(-9, 9), randf_range(-9, 9))
    c.kick_cd = 0.38
    c.ai.ignore = 0.2
    c.model.do_kick()
    c.face(dir)
    last_touch = c
    var loud := mode == "shoot" or mode == "clear"
    Game.sfx("kick", -1.0 if loud else -6.0, randf_range(0.92, 1.08))
    FX.puff(self, Vector3(bp.x, 0.15, bp.z), Color(0.86, 0.95, 0.78), 6, 0.35, 1.4)
    if loud:
        shake = maxf(shake, 0.14)
    return true

func _shot_dir(c) -> Array:
    var att := 1.0 if c.team == 0 else -1.0
    var bp := ball.global_position
    bp.y = 0.0
    var gk = gks[1 - c.team]
    var aim_z := 0.0
    if gk:
        aim_z = -2.35 if gk.global_position.z > 0.0 else 2.35
    var target := Vector3(att * (HALF_X + 1.0), 0, aim_z)
    var to_goal := target - bp
    var dist := to_goal.length()
    to_goal /= maxf(dist, 0.01)
    var dir: Vector3
    if c == player and not auto:
        var f: Vector3 = c.facing
        if f.dot(to_goal) > 0.45 and dist < 34.0:
            dir = to_goal.lerp(f, 0.18).normalized()
        else:
            dir = f
    else:
        var err: float = [0.22, 0.13, 0.07][diff]
        dir = to_goal.rotated(Vector3.UP, randf_range(-err, err))
    var power := clampf(17.0 + dist * 0.45, 19.0, 27.0)
    if c.sprinting:
        power += 2.0
    var lift := clampf(1.2 + dist * 0.12, 1.4, 4.0)
    return [dir, power, lift]

func _pass_dir(c) -> Array:
    var best = null
    var best_s := -INF
    for o in chars:
        if o == c or o.team != c.team:
            continue
        var to: Vector3 = o.global_position - c.global_position
        to.y = 0.0
        var dist := to.length()
        var s: float
        if c == player and not auto:
            s = to.normalized().dot(c.facing) * 2.0 - dist / 25.0
        else:
            var att := 1.0 if c.team == 0 else -1.0
            s = o.global_position.x * att / 10.0 - dist / 30.0 + (1.5 if o == player else 0.0)
        if o.ai.role == "gk":
            s -= 1.5
        if s > best_s:
            best_s = s
            best = o
    if best == null:
        return _shot_dir(c)
    var target: Vector3 = best.global_position + best.velocity * 0.45
    var to2: Vector3 = target - ball.global_position
    to2.y = 0.0
    var d2 := to2.length()
    var dir := to2 / maxf(d2, 0.01)
    var power := clampf(d2 * 1.05 + 5.0, 8.0, 21.0)
    var lift := 1.0 if d2 < 14.0 else 3.6
    return [dir, power, lift]

func _clear_dir(c) -> Array:
    var att := 1.0 if c.team == 0 else -1.0
    var bz := ball.global_position.z
    var side := (1.0 if bz >= 0.0 else -1.0) * randf_range(0.25, 0.75)
    return [Vector3(att, 0, side).normalized(), randf_range(20.0, 24.0), randf_range(5.0, 7.0)]

func _gk_saves() -> void:
    var bp := ball.global_position
    var bv := ball.linear_velocity
    for gk in gks:
        if gk == null:
            continue
        gk.ai.save_cd = maxf(0.0, gk.ai.save_cd - get_physics_process_delta_time())
        var own_side := -1.0 if gk.team == 0 else 1.0
        if bv.x * own_side < 5.0 or gk.ai.save_cd > 0.0:
            continue
        var rel: Vector3 = bp - gk.global_position
        var reach: float = [1.45, 1.75, 2.05][diff]
        if Vector2(rel.x, rel.z).length() > reach or rel.y > 2.5:
            continue
        gk.ai.save_cd = 0.8
        var spd := bv.length()
        var chance: float = [0.4, 0.58, 0.72][diff]
        if gk == gks[0]:
            chance = 0.6
        chance *= clampf(1.35 - spd / 40.0, 0.55, 1.0)
        if randf() < chance:
            ball.linear_velocity = Vector3(-bv.x * 0.4, absf(bv.y) * 0.4 + 3.5, bv.z * 0.4 + randf_range(-5.0, 5.0))
            gk.knockback(Vector3(0, 4.5, signf(rel.z) * 3.0), 0.45)
            gk.model.do_kick()
            last_touch = gk
            Game.sfx("kick", -3.0, 0.8)
            FX.burst(self, bp, Color.WHITE, 10, 4.0, 0.1)
            FX.float_text(self, gk.global_position + Vector3(0, 2.2, 0), Game.t("save"), Color("ffd84a"), 54)
            excite = maxf(excite, 0.5)
        else:
            gk.ai.ignore = 0.6

func _check_goal() -> void:
    var bp := ball.global_position
    if absf(bp.z) < GOAL_W + 0.12 and bp.y < GOAL_H + 0.2:
        if bp.x > HALF_X + BALL_R * 0.9:
            _goal(0)
        elif bp.x < -HALF_X - BALL_R * 0.9:
            _goal(1)

func _check_out() -> void:
    var bp := ball.global_position
    if bp.y < -3.0 or absf(bp.x) > 27.0 or absf(bp.z) > 17.0 or bp.y > 20.0:
        ball.global_position = Vector3(0, 4.0, 0)
        ball.linear_velocity = Vector3(0, 2, 0)
        ball.angular_velocity = Vector3.ZERO

# ================================================================ bots
func _bot(c, delta: float) -> void:
    var ai: Dictionary = c.ai
    ai.think -= delta
    if ai.think <= 0.0:
        var react: float = [0.3, 0.18, 0.1][diff]
        ai.think = react * randf_range(0.7, 1.3)
        _decide(c)
    var to: Vector3 = ai.target - c.global_position
    to.y = 0.0
    var dist := to.length()
    var mv := Vector3.ZERO
    if dist > 0.12:
        mv = to / dist * clampf(dist / 0.8, 0.0, 1.0)
    for o in chars:
        if o == c:
            continue
        var dd: Vector3 = c.global_position - o.global_position
        dd.y = 0.0
        var l := dd.length()
        if l < 1.5 and l > 0.01:
            mv += dd / l * (1.5 - l) * (0.9 if o.team == c.team else 0.25)
    c.move_input = mv
    c.sprint_input = ai.sprint and c.stamina > 0.2
    c.jump_held = true
    if ai.want_kick and c.kick_cd <= 0.0:
        if _kick(c, ai.mode):
            ai.want_kick = false
    if ai.get("jump", false):
        ai.jump = false
        c.jump_pressed = true

func _closest_to_ball(team: int):
    var best = null
    var bd := INF
    var bp := ball.global_position
    for c in chars:
        if c.team != team or c.ai.role == "gk":
            continue
        var d: float = Vector2(c.global_position.x - bp.x, c.global_position.z - bp.z).length()
        if d < bd:
            bd = d
            best = c
    return best

func _decide(c) -> void:
    var ai: Dictionary = c.ai
    var team: int = c.team
    var att := 1.0 if team == 0 else -1.0
    var own_x := -HALF_X * att
    var opp_goal := Vector3(HALF_X * att, 0, 0)
    var bp := ball.global_position
    var high := bp.y > 1.9
    bp.y = 0.0
    var bv := ball.linear_velocity
    bv.y = 0.0
    var pred := bp + bv * 0.35
    pred.x = clampf(pred.x, -HALF_X + 0.6, HALF_X - 0.6)
    pred.z = clampf(pred.z, -HALF_Z + 0.6, HALF_Z - 0.6)
    var me: Vector3 = c.global_position
    me.y = 0.0
    var d_ball := me.distance_to(bp)
    ai.sprint = false
    ai.want_kick = false
    var role: String = ai.role
    if role == "player":
        role = "att"
    var closest = _closest_to_ball(team)
    var depth := (bp.x - own_x) * att
    match role:
        "gk":
            var home := Vector3(own_x + att * 1.3, 0, clampf(bp.z * 0.45, -2.7, 2.7))
            if depth < 9.5 and d_ball < 7.5 and absf(bp.z) < 9.0 and not high:
                ai.target = pred
                ai.sprint = true
                ai.want_kick = d_ball < 2.4
                ai.mode = "clear"
            else:
                ai.target = home
        "def":
            if (closest == c and depth < 30.0) or d_ball < 2.2:
                _chase(c, pred, opp_goal)
            else:
                var hx := own_x + att * clampf(depth * 0.45, 4.0, 16.0)
                ai.target = Vector3(hx, 0, clampf(bp.z * 0.6, -9.0, 9.0))
        "mate":
            if closest == c or d_ball < 2.0:
                _chase(c, pred, opp_goal)
            elif depth < 20.0:
                ai.target = Vector3(own_x + att * clampf(depth * 0.55, 4.0, 13.0), 0, clampf(bp.z * 0.6, -9.0, 9.0))
            else:
                ai.target = Vector3(clampf(bp.x + att * 5.0, -HALF_X + 3, HALF_X - 3), 0, clampf(-bp.z * 0.5 + (4.0 if bp.z <= 0.0 else -4.0), -10.0, 10.0))
        "att":
            if closest == c or d_ball < 2.2:
                _chase(c, pred, opp_goal)
            else:
                ai.target = Vector3(clampf(bp.x + att * 6.0, -HALF_X + 3, HALF_X - 3), 0, clampf(-bp.z * 0.5 + (3.0 if bp.z < 0.0 else -3.0), -10.0, 10.0))
    if high and d_ball < 2.5 and ball.global_position.y < 2.6 and randf() < 0.5:
        ai.jump = true

func _chase(c, pred: Vector3, opp_goal: Vector3) -> void:
    var ai: Dictionary = c.ai
    var me: Vector3 = c.global_position
    me.y = 0.0
    var bp := ball.global_position
    bp.y = 0.0
    var aim := opp_goal + Vector3(0, 0, clampf(-bp.z * 0.15, -2.0, 2.0))
    var to_goal := (aim - bp).normalized()
    var rel := me - bp
    var d := rel.length()
    var behind := pred - to_goal * (CHAR_R + BALL_R + 0.25)
    if rel.dot(to_goal) > -0.15 and d < 3.0:
        var side := Vector3(-to_goal.z, 0, to_goal.x)
        var s := 1.0 if rel.dot(side) >= 0.0 else -1.0
        ai.target = bp - to_goal * 1.3 + side * s * 1.6
        ai.sprint = d > 1.8
        if _pressured(c) and d < 1.6 and randf() < 0.5:
            ai.want_kick = true
            ai.mode = "clear"
    elif me.distance_to(behind) > 0.9:
        ai.target = behind
        ai.sprint = d > 4.0
    else:
        ai.target = bp + to_goal * 2.5
        ai.sprint = randf() < 0.35
        var dist_goal := bp.distance_to(opp_goal)
        var shoot_range: float = [12.0, 15.0, 18.0][diff]
        if dist_goal < shoot_range:
            ai.want_kick = true
            ai.mode = "shoot"
        elif c.team == 0 and c != player and randf() < 0.3 and _open(player):
            ai.want_kick = true
            ai.mode = "pass"
        elif _pressured(c) and randf() < 0.4:
            ai.want_kick = true
            ai.mode = "pass" if randf() < 0.6 else "clear"

func _pressured(c) -> bool:
    for o in chars:
        if o.team != c.team and o.global_position.distance_to(c.global_position) < 2.4:
            return true
    return false

func _open(c) -> bool:
    for o in chars:
        if o.team != c.team and o.global_position.distance_to(c.global_position) < 3.5:
            return false
    return true

# ================================================================ camera / fx
func _update_camera(delta: float, snap := false) -> void:
    var bp := ball.global_position
    var pp: Vector3 = player.global_position
    var fx := clampf(lerpf(bp.x, pp.x, 0.3), -14.0, 14.0)
    var fz := clampf(lerpf(bp.z, pp.z, 0.3), -5.5, 5.5)
    var target := Vector3(fx, 0, fz)
    if state == St.GOAL:
        target = target.lerp(Vector3(HALF_X * (1.0 if scoring_team == 0 else -1.0) * 0.7, 0, 0), 0.5)
    cam_focus = target if snap else cam_focus.lerp(target, 1.0 - exp(-delta * 3.2))
    var zoom := 1.0
    if state == St.GOAL:
        zoom = 0.85
    cam.global_position = cam_focus + Vector3(0, 15.5, 14.5) * zoom
    cam.look_at(cam_focus + Vector3(0, 0, -0.6), Vector3.UP)
    if shake > 0.0:
        shake = maxf(0.0, shake - delta * 1.8)
        cam.h_offset = randf_range(-1, 1) * shake * 0.35
        cam.v_offset = randf_range(-1, 1) * shake * 0.35
    else:
        cam.h_offset = 0.0
        cam.v_offset = 0.0

func _update_fx(delta: float) -> void:
    excite = maxf(0.0, excite - delta * 0.25)
    if crowd:
        var t := Time.get_ticks_msec() * 0.001
        crowd.position.y = crowd_y + absf(sin(t * (3.0 + 6.0 * excite))) * (0.04 + 0.35 * excite)
    if crowd_audio:
        crowd_audio.volume_db = lerpf(-16.0, -5.0, excite)
    var spd := ball.linear_velocity.length()
    trail.emitting = spd > 14.0
    if arrow and player:
        var t2 := Time.get_ticks_msec() * 0.001
        arrow.global_position = player.global_position + Vector3(0, 2.05 + sin(t2 * 5.0) * 0.12, 0)
        arrow.rotation.y += delta * 2.0

# ================================================================ HUD
func _build_touch_controls() -> void:
    if not OS.has_feature("mobile") and not Game.force_touch: return
    var layer := CanvasLayer.new()
    layer.layer = 11
    add_child(layer)
    touch_controls = TouchControls.new()
    touch_controls.football = true
    layer.add_child(touch_controls)
    touch_controls.jump.connect(func():
        if not auto and (state == St.PLAY or state == St.GOAL): player.jump_pressed = true)
    touch_controls.kick.connect(func():
        if not auto and state == St.PLAY: kick_buf = 0.25)
    touch_controls.pass_ball.connect(func():
        if not auto and state == St.PLAY: pass_buf = 0.25)

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    layer.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(layer)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    hud.root = root
    # scoreboard
    var top := HBoxContainer.new()
    top.set_anchors_preset(Control.PRESET_TOP_WIDE)
    top.offset_top = 14
    top.alignment = BoxContainer.ALIGNMENT_CENTER
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(top)
    var board := UI.panel(Color(0.14, 0.16, 0.3, 0.88), 22, 8)
    board.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top.add_child(board)
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 10)
    board.add_child(hb)
    hud.score_l = []
    hud.chips = []
    for team in 2:
        var chip := UI.flat_panel(TEAM_COLORS[team], 16, 6)
        chip.custom_minimum_size = Vector2(170, 0)
        var ch := HBoxContainer.new()
        ch.alignment = BoxContainer.ALIGNMENT_CENTER
        ch.add_theme_constant_override("separation", 12)
        chip.add_child(ch)
        var nm := UI.label(Game.t("blue") if team == 0 else Game.t("red"), 18, Color(1, 1, 1, 0.9), 0)
        nm.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        var sc := UI.label("0", 40, Color.WHITE, 8, TEAM_COLORS[team].darkened(0.5), UI.FONT_BLACK)
        if team == 0:
            ch.add_child(nm)
            ch.add_child(sc)
        else:
            ch.add_child(sc)
            ch.add_child(nm)
        hud.score_l.append(sc)
        hud.chips.append(chip)
        if team == 0:
            hb.add_child(chip)
            var tl := UI.label("3:00", 34, Color.WHITE, 6, Color(0, 0, 0, 0.4), UI.FONT_BLACK)
            tl.custom_minimum_size = Vector2(110, 0)
            tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            tl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
            hb.add_child(tl)
            hud.timer = tl
        else:
            hb.add_child(chip)
    # banner
    var bn := VBoxContainer.new()
    bn.set_anchors_preset(Control.PRESET_FULL_RECT)
    bn.alignment = BoxContainer.ALIGNMENT_CENTER
    bn.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bn.offset_bottom = -120
    root.add_child(bn)
    var big := UI.title("", 110, Color.WHITE)
    var sub := UI.title("", 34, Color.WHITE)
    bn.add_child(big)
    bn.add_child(sub)
    hud.banner = big
    hud.banner_sub = sub
    hud.banner_box = bn
    bn.modulate.a = 0.0
    # stamina
    var bottom := VBoxContainer.new()
    bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    bottom.offset_top = -86
    bottom.offset_bottom = -12
    bottom.alignment = BoxContainer.ALIGNMENT_END
    bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(bottom)
    var sh := HBoxContainer.new()
    sh.alignment = BoxContainer.ALIGNMENT_CENTER
    sh.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bottom.add_child(sh)
    sh.add_child(UI.tex_rect(preload("res://assets/ui/icons/bolt.png"), Vector2(34, 34)))
    var st := UI.bar(240, 16, Color("f2c037"))
    st.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    sh.add_child(st)
    hud.stamina = st
    var hint := UI.label(Game.t("hint_fb"), 17, Color(1, 1, 1, 0.92), 5, Color(0, 0, 0, 0.5))
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    if OS.has_feature("mobile") or Game.force_touch: hint.text = ""
    bottom.add_child(hint)
    hud.hint = hint
    # pause button
    var pb := UI.button("II", UI.NAVY, Vector2(62, 62), 26)
    pb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    pb.position = Vector2(-80, 16)
    pb.pressed.connect(_toggle_pause)
    root.add_child(pb)
    hud.pause_btn = pb

func _refresh_score(team := -1) -> void:
    for i in 2:
        hud.score_l[i].text = str(score[i])
    if team >= 0:
        var chip: Control = hud.chips[team]
        chip.pivot_offset = chip.size * 0.5
        var tw := chip.create_tween()
        tw.tween_property(chip, "scale", Vector2(1.25, 1.25), 0.12).set_trans(Tween.TRANS_BACK)
        tw.tween_property(chip, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)

func _banner(text: String, color: Color, sub := "", hold := 1.2) -> void:
    var big: Label = hud.banner
    big.text = text
    big.label_settings.font_color = color
    hud.banner_sub.text = sub
    var box: Control = hud.banner_box
    box.pivot_offset = box.size * 0.5
    box.scale = Vector2(0.6, 0.6)
    box.modulate.a = 1.0
    if hud.has("banner_tw") and hud.banner_tw and hud.banner_tw.is_valid():
        hud.banner_tw.kill()
    var tw := box.create_tween()
    tw.tween_property(box, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_interval(hold)
    tw.tween_property(box, "modulate:a", 0.0, 0.3)
    hud.banner_tw = tw

func _update_hud(delta: float) -> void:
    var timer_text := UI.fmt_time(time_left)
    if hud.timer.text != timer_text: hud.timer.text = timer_text
    if time_left < 15.0 and state == St.PLAY:
        hud.timer.label_settings.font_color = Color("ff8a7a") if int(time_left * 2.0) % 2 == 0 else Color.WHITE
    hud.stamina.value = player.stamina
    hint_t -= delta
    if hint_t < 0.0 and hud.hint.modulate.a > 0.0:
        hud.hint.modulate.a = maxf(0.0, hud.hint.modulate.a - delta)
    if auto:
        _autotest_step()

func _toggle_pause() -> void:
    if touch_controls: touch_controls.reset_controls()
    if state == St.END:
        return
    if pause_ov and is_instance_valid(pause_ov):
        get_tree().paused = false
        if touch_controls: touch_controls.set_playing(true)
        UI.close_modal(pause_ov)
        pause_ov = null
        return
    get_tree().paused = true
    if touch_controls: touch_controls.set_playing(false)
    var m := UI.modal(hud.root, 0.55)
    pause_ov = m[0]
    var p := UI.panel(UI.NAVY, 30, 30)
    m[1].add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    p.add_child(v)
    v.add_child(UI.title(Game.t("paused"), 54))
    var b1 := UI.button(Game.t("resume"), UI.GREEN, Vector2(320, 70), 28)
    b1.pressed.connect(_toggle_pause)
    v.add_child(b1)
    var b2 := UI.button(Game.t("restart"), UI.ORANGE, Vector2(320, 70), 28)
    b2.pressed.connect(func(): Game.goto(Game.SCENE_FOOTBALL))
    v.add_child(b2)
    var b3 := UI.button(Game.t("menu"), UI.PURPLE, Vector2(320, 70), 28)
    b3.pressed.connect(func(): Game.goto(Game.SCENE_MENU))
    v.add_child(b3)
    UI.pop_in(p)

func _show_results() -> void:
    var win: bool = score[0] > score[1]
    var draw: bool = score[0] == score[1]
    var lines: Array = []
    var total := 0
    if player_goals > 0:
        lines.append([Game.t("r_goals") % player_goals, player_goals * 30])
        total += player_goals * 30
    var bonus := 120 if win else (50 if draw else 20)
    lines.append([Game.t("r_win") if win else (Game.t("r_draw") if draw else Game.t("r_play")), bonus])
    total += bonus
    var mult: float = [0.8, 1.0, 1.3][diff]
    if mult != 1.0:
        var extra := int(round(total * mult)) - total
        lines.append([Game.t("r_diff") + " x%.1f" % mult, extra])
        total += extra
    Game.stat_add("fb_played")
    Game.stat_add("fb_goals", player_goals)
    Game.stat_add("fb_wins" if win else ("fb_draws" if draw else "fb_losses"))
    var daily_bonus := Game.record_daily("football", player_goals, 0)
    if daily_bonus > 0:
        lines.append([Game.t("daily_reward"), daily_bonus])
        total += daily_bonus
    Game.add_coins(total)
    Game.sfx("win" if win else ("reward" if draw else "lose"))
    var m := UI.modal(hud.root, 0.55)
    var p := UI.panel(UI.NAVY, 32, 30)
    p.custom_minimum_size = Vector2(560, 0)
    m[1].add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    p.add_child(v)
    var col := Color("ffd84a") if win else (Color.WHITE if draw else Color("ff8a7a"))
    v.add_child(UI.title(Game.t("victory") if win else (Game.t("draw") if draw else Game.t("defeat")), 64, col))
    var sc := HBoxContainer.new()
    sc.alignment = BoxContainer.ALIGNMENT_CENTER
    sc.add_theme_constant_override("separation", 18)
    v.add_child(sc)
    var a := UI.label(str(score[0]), 56, TEAM_COLORS[0].lightened(0.3), 10, Color(0, 0, 0, 0.4), UI.FONT_BLACK)
    var dash := UI.label(":", 50, Color.WHITE, 0)
    var b := UI.label(str(score[1]), 56, TEAM_COLORS[1].lightened(0.3), 10, Color(0, 0, 0, 0.4), UI.FONT_BLACK)
    sc.add_child(a)
    sc.add_child(dash)
    sc.add_child(b)
    v.add_child(UI.spacer(6))
    var box := UI.flat_panel(Color(0, 0, 0, 0.2), 18, 14)
    v.add_child(box)
    var lv := VBoxContainer.new()
    lv.add_theme_constant_override("separation", 6)
    box.add_child(lv)
    for ln in lines:
        lv.add_child(_reward_row(str(ln[0]), int(ln[1]), 24, Color(1, 1, 1, 0.9)))
    lv.add_child(_reward_row(Game.t("r_total"), total, 32, Color("ffd84a")))
    for unlock in Game.last_journey_unlocks:
        var unlocked := UI.label(Game.t(str(unlock)), 20, Color("a5edba"), 2, Color.BLACK, UI.FONT_BLACK)
        unlocked.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        lv.add_child(unlocked)
    v.add_child(UI.spacer(8))
    var hb := HBoxContainer.new()
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_theme_constant_override("separation", 14)
    v.add_child(hb)
    var again := UI.button(Game.t("play_again"), UI.GREEN, Vector2(240, 70), 26)
    again.pressed.connect(func(): Game.goto(Game.SCENE_FOOTBALL))
    hb.add_child(again)
    var menu := UI.button(Game.t("menu"), UI.PURPLE, Vector2(200, 70), 26)
    menu.pressed.connect(func(): Game.goto(Game.SCENE_MENU))
    hb.add_child(menu)
    UI.pop_in(p)
    Game.last_result = {"mode": "football", "score": score, "coins": total}
    if auto:
        await get_tree().create_timer(1.0).timeout
        await Game.shot("fb_results")
        _autotest_done()

func _reward_row(text: String, amount: int, size: int, color: Color) -> HBoxContainer:
    var row := HBoxContainer.new()
    var l := UI.label(text, size, color, 0)
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(l)
    var n := UI.label(("+" if amount >= 0 else "") + str(amount), size, color, 6, Color(0, 0, 0, 0.35), UI.FONT_BLACK)
    row.add_child(n)
    row.add_child(UI.tex_rect(preload("res://assets/ui/icons/coin.png"), Vector2(size + 8, size + 8)))
    return row

# ================================================================ autotest
func _autotest_step() -> void:
    var t := MATCH_TIME - time_left if state != St.KICKOFF else -1.0
    if state == St.KICKOFF and state_t > 0.5 and not _shots_taken.has("kick"):
        _shots_taken.kick = true
        Game.shot("fb_kickoff")
    if state == St.PLAY and time_left < 50.0 - 8.0 and not _shots_taken.has("play"):
        _shots_taken.play = true
        Game.shot("fb_play")
    if state == St.GOAL and state_t > 0.4 and not _shots_taken.has("goal"):
        _shots_taken.goal = true
        Game.shot("fb_goal")
    if state == St.PLAY and time_left < 50.0 - 12.0 and score == [0, 0] and not _shots_taken.has("force"):
        # test only: guarantee one goal so the celebration gets captured
        _shots_taken.force = true
        ball.global_position = Vector3(HALF_X - 3.0, 1.0, GOAL_W * 0.55)
        ball.linear_velocity = Vector3(18.0, 0.5, 0.0)
    if t > 0.0 and not _shots_taken.has("pause") and time_left < 50.0 - 20.0 and state == St.PLAY:
        _shots_taken.pause = true
        print("[autotest] football score ", score, " time_left ", time_left)

func _autotest_done() -> void:
    print("[autotest] football done score=", score)
    if Game.autotest == "football":
        get_tree().quit()
    else:
        Game.goto(Game.SCENE_ZOMBIE)
