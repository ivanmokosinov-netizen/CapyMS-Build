extends RefCounted
## CapyMS UI helpers: chunky rounded buttons, panels, labels, tweens.

const FONT := preload("res://assets/fonts/Rubik-Bold.ttf")
const FONT_BLACK := preload("res://assets/fonts/Rubik-Black.ttf")

const GREEN := Color("5bb88f")
const PURPLE := Color("9987ca")
const ORANGE := Color("e99b72")
const SLATE := Color("7694ad")
const NAVY := Color("3e5872")
const NAVY_DARK := Color("2e455e")
const BLUE := Color("68acd0")
const RED := Color("d47c80")
const GOLD := Color("edb84f")
const CREAM := Color("fff4e0")
const PINK := Color("d67e9d")
const TEAL := Color("57b4aa")

static func sb(color: Color, radius := 18, bottom := 0, border_color := Color(0, 0, 0, 0), pad := Vector4(16, 10, 16, 10)) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.set_corner_radius_all(radius)
    if color.a > 0.05:
        s.set_border_width_all(2)
        s.border_width_bottom = maxi(2, mini(bottom, 4))
        s.border_color = Color.BLACK
    s.content_margin_left = pad.x
    s.content_margin_top = pad.y
    s.content_margin_right = pad.z
    s.content_margin_bottom = pad.w
    s.anti_aliasing = true
    return s

static func style_button(b: Button, color: Color, radius := 18, depth := 6, font_size := 26) -> void:
    var n := sb(color, radius, depth)
    var h := sb(color.lightened(0.12), radius, depth, color.darkened(0.25))
    var p := sb(color.darkened(0.06), radius, 2)
    p.content_margin_top += depth - 2
    p.expand_margin_top = -float(depth - 2)
    var d := sb(color.lerp(Color(0.55, 0.56, 0.62), 0.65), radius, depth)
    b.add_theme_stylebox_override("normal", n)
    b.add_theme_stylebox_override("hover", h)
    b.add_theme_stylebox_override("pressed", p)
    b.add_theme_stylebox_override("hover_pressed", p)
    b.add_theme_stylebox_override("disabled", d)
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.add_theme_font_override("font", FONT_BLACK)
    b.add_theme_font_size_override("font_size", font_size)
    for c in ["font_color", "font_hover_color", "font_focus_color", "font_hover_pressed_color"]:
        b.add_theme_color_override(c, Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color(1, 1, 1, 0.92))
    b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.6))
    b.add_theme_color_override("font_outline_color", Color.BLACK)
    b.add_theme_constant_override("outline_size", 3)
    b.focus_mode = Control.FOCUS_NONE
    b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

static func button(text: String, color: Color, size := Vector2(220, 64), font_size := 26, sound := "ui_click") -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = size
    style_button(b, color, int(min(22.0, size.y * 0.3)), 6, font_size)
    juicy(b, 1.05, sound)
    return b

## Big menu button with an icon and a label (like the reference sheet).
static func big_button(text: String, color: Color, icon: Texture2D = null, size := Vector2(420, 86), font_size := 32) -> Button:
    var b := Button.new()
    b.custom_minimum_size = size
    style_button(b, color, 24, 8, font_size)
    var hb := HBoxContainer.new()
    hb.set_anchors_preset(Control.PRESET_FULL_RECT)
    hb.offset_left = 22
    hb.offset_right = -22
    hb.offset_bottom = -8
    hb.add_theme_constant_override("separation", 16)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(hb)
    if icon:
        var ib := PanelContainer.new()
        ib.add_theme_stylebox_override("panel", sb(color.darkened(0.18), 16, 0, Color(0, 0, 0, 0), Vector4(6, 6, 6, 6)))
        ib.mouse_filter = Control.MOUSE_FILTER_IGNORE
        ib.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        var tr := TextureRect.new()
        tr.texture = icon
        tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        tr.custom_minimum_size = Vector2(size.y - 32, size.y - 32)
        tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
        ib.add_child(tr)
        hb.add_child(ib)
    var l := label(text, font_size, Color.WHITE, 8, color.darkened(0.5), FONT_BLACK)
    l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(l)
    b.button_down.connect(func(): press_shift(hb, 6.0, -2.0))
    b.button_up.connect(func(): press_shift(hb, 0.0, -8.0))
    juicy(b, 1.04)
    return b

## Square icon button (settings, stats, exit...).
static func icon_button(icon: Texture2D, color: Color, size := 64, tooltip := "") -> Button:
    var b := Button.new()
    b.custom_minimum_size = Vector2(size, size + 6)
    style_button(b, color, 18, 6)
    b.tooltip_text = tooltip
    var tr := TextureRect.new()
    tr.texture = icon
    tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    tr.set_anchors_preset(Control.PRESET_FULL_RECT)
    var m := size * 0.2
    tr.offset_left = m
    tr.offset_top = m - 2
    tr.offset_right = -m
    tr.offset_bottom = -m - 4
    tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(tr)
    b.button_down.connect(func(): press_shift(tr, m + 2, -m))
    b.button_up.connect(func(): press_shift(tr, m - 2, -m - 4))
    juicy(b, 1.08)
    return b

static func press_shift(c: Control, top: float, bottom: float) -> void:
    var old: Tween = c.get_meta("press_tween", null)
    if old and old.is_valid(): old.kill()
    var tw := c.create_tween().set_parallel(true)
    c.set_meta("press_tween", tw)
    tw.tween_property(c, "offset_top", top, 0.12).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tw.tween_property(c, "offset_bottom", bottom, 0.12).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

static func _scale_to(c: Control, scale_value: float) -> void:
    var old: Tween = c.get_meta("scale_tween", null)
    if old and old.is_valid(): old.kill()
    var tw := c.create_tween()
    c.set_meta("scale_tween", tw)
    tw.tween_property(c, "scale", Vector2.ONE * scale_value, 0.17).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

static func juicy(c: Control, hover_scale := 1.05, sound := "ui_click") -> void:
    c.pivot_offset = c.custom_minimum_size * 0.5
    c.resized.connect(func(): c.pivot_offset = c.size * 0.5)
    var gentle := 1.0 + (hover_scale - 1.0) * 0.6
    c.mouse_entered.connect(func():
        if c is BaseButton and (c as BaseButton).disabled: return
        Game.sfx("ui_hover", -8.0)
        _scale_to(c, gentle))
    c.mouse_exited.connect(func(): _scale_to(c, 1.0))
    if c is BaseButton:
        (c as BaseButton).button_down.connect(func(): _scale_to(c, 0.98))
        (c as BaseButton).button_up.connect(func(): _scale_to(c, 1.0))
        if sound != "": (c as BaseButton).pressed.connect(func(): Game.sfx(sound, -2.0))

## Largest font size <= size at which text fits into max_w pixels.
static func fit_size(text: String, font: Font, size: int, max_w: float, min_size := 16) -> int:
    var s := size
    while s > min_size and font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, s).x > max_w:
        s -= 1
    return s

static func label(text: String, size := 24, color := Color.WHITE, outline := 0, outline_color := Color(0, 0, 0, 0.45), font: Font = null, shadow := false) -> Label:
    var l := Label.new()
    l.text = text
    var ls := LabelSettings.new()
    ls.font = font if font else FONT
    ls.font_size = size
    ls.font_color = color
    if outline > 0:
        ls.outline_size = mini(outline, 3)
        ls.outline_color = Color.BLACK
    if shadow:
        ls.shadow_size = 1
        ls.shadow_color = Color(0, 0, 0, 0.35)
        ls.shadow_offset = Vector2(0, 4)
    l.label_settings = ls
    return l

static func title(text: String, size := 48, color := Color.WHITE, outline_color := Color("2f3357")) -> Label:
    var l := label(text, size, color, 12, outline_color, FONT_BLACK, true)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    return l

static func panel(color := NAVY, radius := 28, pad := 24, border := 0, border_color := Color.WHITE) -> PanelContainer:
    var p := PanelContainer.new()
    var s := sb(color, radius, 0, Color(0, 0, 0, 0), Vector4(pad, pad, pad, pad))
    s.shadow_color = Color(0, 0, 0, 0.28)
    s.shadow_size = 14
    s.shadow_offset = Vector2(0, 8)
    if border > 0:
        s.set_border_width_all(border)
        s.border_color = Color.BLACK
    p.add_theme_stylebox_override("panel", s)
    return p

static func flat_panel(color: Color, radius := 16, pad := 10) -> PanelContainer:
    var p := PanelContainer.new()
    p.add_theme_stylebox_override("panel", sb(color, radius, 0, Color(0, 0, 0, 0), Vector4(pad, pad, pad, pad)))
    return p

## Rounded "pill" with an icon and a number; returns [panel, label].
static func pill(icon: Texture2D, text: String, color := Color(0.16, 0.18, 0.33, 0.75), font_size := 26) -> Array:
    var p := PanelContainer.new()
    p.add_theme_stylebox_override("panel", sb(color, 30, 0, Color(0, 0, 0, 0), Vector4(10, 6, 20, 6)))
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    p.add_child(hb)
    var tr := TextureRect.new()
    tr.texture = icon
    tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    tr.custom_minimum_size = Vector2(font_size + 14, font_size + 14)
    hb.add_child(tr)
    var l := label(text, font_size, Color.WHITE, 6, Color(0, 0, 0, 0.35), FONT_BLACK)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hb.add_child(l)
    return [p, l]

static func tex_rect(tex: Texture2D, size: Vector2) -> TextureRect:
    var tr := TextureRect.new()
    tr.texture = tex
    tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    tr.custom_minimum_size = size
    tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return tr

## Full-screen dimmer with a centered content holder; returns [overlay, center].
static func modal(parent: Control, dim := 0.5) -> Array:
    var ov := ColorRect.new()
    ov.color = Color(0.08, 0.09, 0.2, dim)
    ov.set_anchors_preset(Control.PRESET_FULL_RECT)
    ov.mouse_filter = Control.MOUSE_FILTER_STOP
    parent.add_child(ov)
    var cc := CenterContainer.new()
    cc.set_anchors_preset(Control.PRESET_FULL_RECT)
    ov.add_child(cc)
    ov.modulate.a = 0.0
    ov.create_tween().tween_property(ov, "modulate:a", 1.0, 0.22)
    return [ov, cc]

static func pop_in(c: Control, delay := 0.0) -> void:
    c.pivot_offset = c.size * 0.5
    c.scale = Vector2(0.94, 0.94)
    c.modulate.a = 0.0
    var tw := c.create_tween().set_parallel(true)
    tw.tween_property(c, "scale", Vector2.ONE, 0.28).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT).set_delay(delay)
    tw.tween_property(c, "modulate:a", 1.0, 0.22).set_delay(delay)
    if c.size == Vector2.ZERO:
        c.resized.connect(func(): c.pivot_offset = c.size * 0.5, CONNECT_ONE_SHOT)

static func close_modal(ov: Control) -> void:
    if not is_instance_valid(ov):
        return
    ov.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var tw := ov.create_tween()
    tw.tween_property(ov, "modulate:a", 0.0, 0.20)
    tw.tween_callback(ov.queue_free)

static func bar(width: float, height: float, fill_color: Color, bg := Color(0, 0, 0, 0.35)) -> ProgressBar:
    var pb := ProgressBar.new()
    pb.custom_minimum_size = Vector2(width, height)
    pb.show_percentage = false
    pb.max_value = 1.0
    pb.step = 0.0
    pb.add_theme_stylebox_override("background", sb(bg, int(height * 0.5), 0, Color(0, 0, 0, 0), Vector4.ZERO))
    var f := sb(fill_color, int(height * 0.5), 0, Color(0, 0, 0, 0), Vector4.ZERO)
    pb.add_theme_stylebox_override("fill", f)
    pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return pb

static func spacer(h := 10.0, w := 0.0) -> Control:
    var c := Control.new()
    c.custom_minimum_size = Vector2(w, h)
    c.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return c

static func fmt_time(sec: float) -> String:
    var s := int(ceil(max(sec, 0.0)))
    return "%d:%02d" % [s / 60, s % 60]

## Toggle group (e.g. difficulty). Returns HBox; calls on_pick(index).
static func toggle_group(options: Array, selected: int, color: Color, on_pick: Callable, size := Vector2(150, 54)) -> HBoxContainer:
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    var btns: Array = []
    for i in options.size():
        var b := Button.new()
        b.text = str(options[i])
        b.custom_minimum_size = size
        hb.add_child(b)
        btns.append(b)
    var refresh := func(sel: int):
        for j in btns.size():
            var bb: Button = btns[j]
            style_button(bb, color if j == sel else Color("8a8fb0"), 16, 5, 22)
    refresh.call(selected)
    for i in btns.size():
        var bb: Button = btns[i]
        juicy(bb, 1.05)
        bb.pressed.connect(func():
            refresh.call(i)
            on_pick.call(i))
    return hb
