extends Node
## CapyMS — global game state (autoload "Game").
## Save data, skins & chests, translations, audio, theme, scene switching.

const SAVE_PATH := "user://capyms_save.json"
const VERSION := "1.0"

## Fonts are loaded at runtime (not preloaded) so the autoload compiles
## even before the editor has finished the very first asset import.
var FONT: Font
var FONT_BLACK: Font

const SCENE_MENU := "res://scenes/main_menu.tscn"
const SCENE_FOOTBALL := "res://scenes/football.tscn"
const SCENE_ZOMBIE := "res://scenes/zombie_run.tscn"

# ---------------------------------------------------------------- skins
const RARITIES := ["common", "rare", "epic", "legendary"]
const RARITY_COLORS := {
    "common": Color("8a9bc4"),
    "rare": Color("3f8fe0"),
    "epic": Color("a05ed8"),
    "legendary": Color("f2b02c"),
}
const SKINS := [
    {"id": "classic", "rarity": "common", "acc": [], "en": "Classic", "ru": "Классика"},
    {"id": "cool", "rarity": "common", "acc": ["Acc_Glasses"], "en": "Neo", "ru": "Нео"},
    {"id": "sporty", "rarity": "common", "acc": ["Acc_Cap"], "en": "Sporty", "ru": "Спортсмен"},
    {"id": "party", "rarity": "common", "acc": ["Acc_Party"], "en": "Partymaker(PICA)", "ru": "Патимейкер(PICA)"},
    {"id": "fan", "rarity": "rare", "acc": ["Acc_Scarf"], "en": "Football Fan", "ru": "Фанат"},
    {"id": "dj", "rarity": "rare", "acc": ["Acc_Headphones"], "en": "DJ Capy", "ru": "Диджей"},
    {"id": "ninja", "rarity": "rare", "acc": ["Acc_Ninja"], "en": "Ninja", "ru": "Ниндзя"},
    {"id": "hoodie", "rarity": "epic", "acc": ["Acc_Hood", "Acc_HoodieBody"], "hide_ears": true, "en": "Hoodie", "ru": "Худи"},
    {"id": "pirate", "rarity": "epic", "acc": ["Acc_Pirate"], "en": "Pirate", "ru": "Пират"},
    {"id": "gentleman", "rarity": "epic", "acc": ["Acc_Gentleman"], "en": "Gentleman", "ru": "Джентльмен"},
    {"id": "zombie", "rarity": "epic", "acc": [], "fur": "zombie", "en": "I eat mushrooms", "ru": "ем грибы"},
    {"id": "king", "rarity": "legendary", "acc": ["Acc_Crown"], "en": "King", "ru": "Король"},
    {"id": "golden", "rarity": "legendary", "acc": ["Acc_Glasses"], "fur": "golden", "en": "Golden Capy", "ru": "Золотой"},
]
# material name -> [albedo, metallic, roughness]
const FUR := {
    "zombie": {
        "Fur": [Color("7cb65a"), 0.0, 0.8], "FurDark": [Color("5b9140"), 0.0, 0.8],
        "Snout": [Color("679c49"), 0.0, 0.8], "Feet": [Color("3f5e33"), 0.0, 0.8],
    },
    "golden": {
        "Fur": [Color("f2c14e"), 0.75, 0.3], "FurDark": [Color("d9a336"), 0.75, 0.3],
        "Snout": [Color("d9a336"), 0.75, 0.32], "Feet": [Color("a8781f"), 0.7, 0.35],
    },
}
const CHESTS := [
    {"id": "wood", "price": 100, "odds": [65, 28, 6, 1], "color": Color("9b694d"), "en": "Wooden Chest", "ru": "Деревянный сундук"},
    {"id": "epic", "price": 250, "odds": [20, 45, 28, 7], "color": Color("8a55d6"), "en": "Epic Chest", "ru": "Эпический сундук"},
    {"id": "mystic", "price": 500, "odds": [0, 30, 45, 25], "color": Color("54547c"), "en": "Mystic Chest", "ru": "Мистический сундук"},
]
const REFUND := {"common": 20, "rare": 40, "epic": 80, "legendary": 150}

# ---------------------------------------------------------------- text
const TEXT := {
    "big_football": ["BIG FOOTBALL", "БОЛЬШОЙ ФУТБОЛ"],
    "zombie_run": ["ZOMBIE RUN", "ЗОМБИ-ПОБЕГ"],
    "skins_chests": ["SKINS & CHESTS", "СКИНЫ И СУНДУКИ"],
    "play": ["PLAY", "ИГРАТЬ"],
    "back": ["BACK", "НАЗАД"],
    "close": ["CLOSE", "ЗАКРЫТЬ"],
    "settings": ["SETTINGS", "НАСТРОЙКИ"],
    "stats": ["STATS", "СТАТИСТИКА"],
    "quit_q": ["Quit the game?", "Выйти из игры?"],
    "yes": ["YES", "ДА"],
    "no": ["NO", "НЕТ"],
    "difficulty": ["Difficulty", "Сложность"],
    "diff0": ["Easy", "Легко"],
    "diff1": ["Normal", "Нормально"],
    "diff2": ["Hard", "Сложно"],
    "music": ["Music", "Музыка"],
    "sounds": ["Sounds", "Звуки"],
    "language": ["Language", "Язык"],
    "fullscreen": ["Fullscreen", "Полный экран"],
    "reset": ["Reset progress", "Сбросить прогресс"],
    "reset_q": ["Reset all coins, skins and stats?", "Сбросить все монеты, скины и статистику?"],
    "fb_desc": ["3 vs 3 football with a HUGE ball! Score more goals than your opponents in 3 minutes.", "Футбол 3 на 3 огромным мячом! Забей больше голов соперникам за 3 минуты."],
    "zr_desc": ["Green zombie capybaras took over the city! Run to the rescue bus, save your friends and grab coins.", "Зелёные зомби-капибары захватили город! Добеги до спасательного автобуса, спаси друзей и собери монеты."],
    "controls": ["Controls", "Управление"],
    "c_move": ["Move", "Бег"],
    "c_sprint": ["Sprint", "Ускорение"],
    "c_jump": ["Jump", "Прыжок"],
    "c_shoot": ["Shoot", "Удар"],
    "c_pass": ["Pass", "Пас"],
    "c_pause": ["Pause", "Пауза"],
    "rewards": ["Rewards", "Награды"],
    "fb_rewards": ["+30 per goal · +120 for a win", "+30 за гол · +120 за победу"],
    "zr_rewards": ["Coins you grab + escape bonus", "Собранные монеты + бонус за побег"],
    "skins": ["SKINS", "СКИНЫ"],
    "chests": ["CHESTS", "СУНДУКИ"],
    "equip": ["EQUIP", "НАДЕТЬ"],
    "equipped": ["EQUIPPED", "НАДЕТО"],
    "locked": ["Find it in chests", "Выпадает из сундуков"],
    "open": ["OPEN", "ОТКРЫТЬ"],
    "not_enough": ["Not enough coins!", "Недостаточно монет!"],
    "odds": ["Chances", "Шансы"],
    "common": ["Common", "Обычный"],
    "rare": ["Rare", "Редкий"],
    "epic": ["Epic", "Эпический"],
    "legendary": ["Legendary", "Легендарный"],
    "new_skin": ["NEW SKIN!", "НОВЫЙ СКИН!"],
    "duplicate": ["Duplicate! +%d coins", "Повтор! +%d монет"],
    "awesome": ["AWESOME!", "КРУТО!"],
    "collection": ["Collection %d/%d", "Коллекция %d/%d"],
    "earn_hint": ["Earn coins in Big Football and Zombie Run!", "Зарабатывай монеты в Футболе и Зомби-побеге!"],
    "loading": ["Loading...", "Загрузка..."],
    "st_football": ["Big Football", "Большой футбол"],
    "st_zombie": ["Zombie Run", "Зомби-побег"],
    "st_other": ["Collection", "Коллекция"],
    "st_played": ["Matches played", "Сыграно матчей"],
    "st_wins": ["Wins", "Победы"],
    "st_draws": ["Draws", "Ничьи"],
    "st_losses": ["Losses", "Поражения"],
    "st_goals": ["Goals scored", "Забито голов"],
    "st_runs": ["Runs", "Забегов"],
    "st_escapes": ["Escapes", "Успешных побегов"],
    "st_best": ["Best distance", "Лучшая дистанция"],
    "st_best_time": ["Best escape time", "Лучшее время побега"],
    "st_saved": ["Friends saved", "Спасено друзей"],
    "st_chests": ["Chests opened", "Открыто сундуков"],
    "st_coins": ["Coins earned", "Заработано монет"],
    "st_skins": ["Skins collected", "Собрано скинов"],
    "you": ["YOU", "ТЫ"],
    "blue": ["BLUE", "СИНИЕ"],
    "red": ["RED", "КРАСНЫЕ"],
    "goal": ["GOAL!", "ГОЛ!"],
    "scores": ["%s scores!", "%s забивает!"],
    "ready": ["READY?", "ГОТОВЫ?"],
    "go": ["GO!", "ВПЕРЁД!"],
    "time_up": ["FULL TIME!", "КОНЕЦ МАТЧА!"],
    "victory": ["VICTORY!", "ПОБЕДА!"],
    "draw": ["DRAW", "НИЧЬЯ"],
    "defeat": ["DEFEAT", "ПОРАЖЕНИЕ"],
    "r_goals": ["Your goals x%d", "Твои голы x%d"],
    "r_win": ["Victory bonus", "Бонус за победу"],
    "r_draw": ["Draw bonus", "Бонус за ничью"],
    "r_play": ["For playing", "За участие"],
    "r_total": ["TOTAL", "ИТОГО"],
    "r_diff": ["Difficulty", "Сложность"],
    "play_again": ["PLAY AGAIN", "ЕЩЁ РАЗ"],
    "menu": ["MENU", "МЕНЮ"],
    "resume": ["RESUME", "ПРОДОЛЖИТЬ"],
    "restart": ["RESTART", "ЗАНОВО"],
    "paused": ["PAUSED", "ПАУЗА"],
    "run": ["RUN!", "БЕГИ!"],
    "to_bus": ["Get to the rescue bus!", "Беги к спасательному автобусу!"],
    "caught": ["CAUGHT!", "ПОЙМАЛИ!"],
    "escaped": ["ESCAPED!", "СПАСЕНИЕ!"],
    "infected": ["%s got infected!", "%s теперь зомби!"],
    "friend_saved": ["%s is safe!", "%s спасён!"],
    "horde": ["The horde is close!", "Орда близко!"],
    "boost": ["SPEED BOOST!", "УСКОРЕНИЕ!"],
    "plus_heart": ["+1 HEART", "+1 ЖИЗНЬ"],
    "r_coins": ["Coins collected", "Собрано монет"],
    "r_escape": ["Escape bonus", "Бонус за побег"],
    "r_friends": ["Friends saved x%d", "Спасено друзей x%d"],
    "r_distance": ["Distance bonus", "Бонус за дистанцию"],
    "r_time": ["Time", "Время"],
    "dist": ["%d m", "%d м"],
    "new_record": ["NEW RECORD!", "НОВЫЙ РЕКОРД!"],
    "hint_fb": ["WASD move · Shift sprint · E / LMB shoot · Q / RMB pass · Space jump", "WASD бег · Shift ускорение · E / ЛКМ удар · Q / ПКМ пас · Пробел прыжок"],
    "hint_zr": ["WASD move · Shift sprint · Space jump over obstacles", "WASD бег · Shift ускорение · Пробел — прыжок через препятствия"],
    "click_capy": ["Click the capybara!", "Нажми на капибару!"],
    "fb_sub": ["3 vs 3 football", "Футбол 3 на 3"],
    "zr_sub": ["Escape the zombie horde!", "Убеги от орды зомби!"],
    "on": ["ON", "ВКЛ"],
    "off": ["OFF", "ВЫКЛ"],
    "k_space": ["Space", "Пробел"],
    "k_lmb": ["LMB", "ЛКМ"],
    "k_rmb": ["RMB", "ПКМ"],
    "best": ["Best", "Рекорд"],
    "bonk": ["BONK!", "БАЦ!"],
    "drag_rotate": ["Drag to spin your capybara", "Потяни, чтобы покрутить капибару"],
    "new_badge": ["NEW", "НОВЫЙ"],
    "reset_done": ["Progress reset", "Прогресс сброшен"],
    "save": ["SAVE!", "ОТБИЛ!"],
    "you_scored": ["YOU SCORED!", "ТЫ ЗАБИЛ!"],
    "own_goal": ["Own goal!", "Автогол!"],
    "background_music": ["Background music", "Фоновая музыка"],
    "boombox": ["BOOMBOX", "БУМБОКС"],
    "boombox_buy": ["UNLOCK · 100 COINS", "ОТКРЫТЬ · 100 МОНЕТ"],
    "boombox_unlock_desc": ["Unlock once for 100 coins. Then choose or change your menu music for free.", "Открой один раз за 100 монет. Потом выбирай и меняй музыку в меню бесплатно."],
    "boombox_choose": ["CHOOSE TRACK", "ВЫБРАТЬ ТРЕК"],
    "boombox_replace": ["CHANGE TRACK", "СМЕНИТЬ ТРЕК"],
    "boombox_mute": ["STOP MUSIC", "ВЫКЛЮЧИТЬ МУЗЫКУ"],
    "boombox_resume": ["PLAY", "ВКЛЮЧИТЬ"],
    "boombox_no_track": ["Choose an MP3, OGG Vorbis or WAV file (up to 32 MB). It stays on this device.", "Выбери MP3, OGG Vorbis или WAV до 32 МБ. Файл останется на устройстве."],
    "boombox_track": ["Your track is saved on this device.", "Твой трек сохранён на этом устройстве."],
    "boombox_off": ["Music is off.", "Музыка выключена."],
    "boombox_invalid": ["Could not read the audio. Try MP3, OGG Vorbis or WAV up to 32 MB.", "Не удалось прочитать файл. Попробуй MP3, OGG Vorbis или WAV до 32 МБ."],
    "boombox_saved": ["Track saved!", "Трек сохранён!"],
    "boombox_unlocked": ["Boombox unlocked!", "Бумбокс открыт!"],
    "bus_sign": ["BUS", "АВТОБУС"],
    "daily_title": ["DAILY GOALS", "ЦЕЛИ НА ДЕНЬ"],
    "daily_button": ["GOALS  %d/3", "ЗАДАНИЯ  %d/3"],
    "daily_football": ["Finish a football match", "Сыграй футбольный матч"],
    "daily_zombie": ["Finish a zombie run", "Заверши зомби-побег"],
    "daily_goal": ["Score a goal in football", "Забей гол в футболе"],
    "daily_coins": ["Collect 8 coins in Zombie Run", "Собери 8 монет в зомби-побеге"],
    "daily_games": ["Finish 3 games in any mode", "Заверши 3 игры в любом режиме"],
    "daily_reward": ["Daily goals", "Цели дня"],
    "daily_done": ["DONE", "ГОТОВО"],
    "daily_stars": ["CAPY JOURNEY  ·  %d / %d stars", "ПУТЬ КАПИБАРЫ  ·  %d / %d звёзд"],
    "daily_next": ["Next reward: %d coins", "Следующая награда: %d монет"],
    "daily_complete": ["All journey rewards collected!", "Все награды пути получены!"],
    "daily_note": ["Counted after each game · New goals each local day", "Награды после игры · Новые задания каждый день"],
    "daily_award": ["+%d coins · 1 star", "+%d монет · 1 звезда"],
    "daily_collection": ["Big goal: collect all skins  %d/%d", "Большая цель: собери все скины  %d/%d"],
    "profile": ["PLAYER NAME", "НИК ИГРОКА"],
    "profile_first": ["Choose your nickname", "Придумай свой ник"],
    "profile_identity": ["Your nickname will appear in matches", "Этот ник будет виден в матчах"],
    "match_vibe": ["Teams are ready for the match!", "Команды готовы к матчу!"],
    "run_vibe": ["The survivor team is ready!", "Команда выживших готова!"],
    "box_hint_short": ["♪ Tap the boombox!", "♪ Нажми на бумбокс!"],
    "telegram_channel": ["Game channel: @splanetcom ↗", "Канал игры: @splanetcom ↗"],
    "profile_rules": ["3–16 letters or digits, _ and -; no spaces or emoji", "3–16 букв и цифр, _ и -; без пробелов и эмодзи"],
    "profile_invalid": ["Use 3–16 letters, digits, _ or -", "От 3 до 16 букв, цифр, _ или -"],
    "profile_save": ["SAVE", "СОХРАНИТЬ"],
    "profile_color": ["Nickname color", "Цвет ника"],
    "profile_color_locked": ["Colored nickname is a journey reward", "Цвет ника — награда Пути капибары"],
    "profile_button": ["Change nickname", "Изменить ник"],
    "color_white": ["WHITE", "БЕЛЫЙ"],
    "color_blue": ["BLUE", "ГОЛУБОЙ"],
    "color_green": ["GREEN", "ЗЕЛЁНЫЙ"],
    "color_pink": ["PINK", "РОЗОВЫЙ"],
    "color_gold": ["GOLD", "ЗОЛОТОЙ"],
    "next_nick": ["NEXT: colored nickname + %d coins", "ДАЛЕЕ: цветной ник + %d монет"],
    "next_box": ["NEXT: boombox + %d coins", "ДАЛЕЕ: бумбокс + %d монет"],
    "nick_unlocked": ["UNLOCKED: colored nickname!", "ОТКРЫТО: цветной ник!"],
    "box_unlocked": ["UNLOCKED: boombox!", "ОТКРЫТО: бумбокс!"],
    "box_locked": ["A Capy Journey reward. Check your goals!", "Награда Пути капибары. Загляни в задания!"],
    "box_locked_next": ["Unlock at 12 stars on the Capy Journey", "Откроется за 12 звёзд Пути капибары"],
    "box_hint": ["♪ Tap the boombox for music", "♪ Нажми на бумбокс — музыка"],
    "track_menu": ["MENU", "МЕНЮ"],
    "track_football": ["FOOTBALL", "ФУТБОЛ"],
    "track_zombie": ["ZOMBIE", "ЗОМБИ"],
    "track_custom": ["MY TRACK", "МОЙ ТРЕК"],
    "track_current": ["Now playing: %s", "Сейчас играет: %s"],
    "track_choose": ["Choose music for the menu", "Выбери музыку для меню"],
    "track_off": ["OFF", "ВЫКЛ"],
}

# ---------------------------------------------------------------- state
var data := {}
var lang := "en"
var theme: Theme
var autotest := ""
var shots_dir := ""
var force_lang := ""
var force_diff := -1
var last_result := {}
var last_journey_unlocks: Array = []

var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _music_name := ""
var _music_tween: Tween
var _sfx_pool: Array = []
var _sfx_next := 0
var _stream_cache := {}
var force_touch := false
var _fade_layer: CanvasLayer
var _fade_rect: ColorRect
var _fade_label: Label
var _busy := false

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    FONT = load("res://assets/fonts/Rubik-Bold.ttf")
    FONT_BLACK = load("res://assets/fonts/Rubik-Black.ttf")
    randomize()
    _parse_args()
    _setup_input()
    _setup_audio()
    load_game()
    _build_theme()
    _build_fade()
    apply_settings()

# ---------------------------------------------------------------- args / autotest
func _parse_args() -> void:
    for a in OS.get_cmdline_user_args():
        if a == "--touch":
            force_touch = true
        elif a.begins_with("--autotest="):
            autotest = a.get_slice("=", 1)
        elif a.begins_with("--shots="):
            shots_dir = a.get_slice("=", 1)
        elif a.begins_with("--lang="):
            force_lang = a.get_slice("=", 1)
        elif a.begins_with("--diff="):
            force_diff = clampi(int(a.get_slice("=", 1)), 0, 2)
    if autotest != "" and shots_dir != "":
        # slow software renderers: let physics catch up so test matches finish
        Engine.max_physics_steps_per_frame = 40

func shot(name: String) -> void:
    if shots_dir == "":
        return
    await RenderingServer.frame_post_draw
    var img := get_viewport().get_texture().get_image()
    img.save_png(shots_dir.path_join(name + ".png"))
    print("[autotest] shot ", name)

# ---------------------------------------------------------------- input
func _key(k: int) -> InputEventKey:
    var e := InputEventKey.new()
    e.physical_keycode = k
    return e

func _mouse(b: int) -> InputEventMouseButton:
    var e := InputEventMouseButton.new()
    e.button_index = b
    return e

func _joy_btn(b: int) -> InputEventJoypadButton:
    var e := InputEventJoypadButton.new()
    e.button_index = b
    return e

func _joy_axis(axis: int, v: float) -> InputEventJoypadMotion:
    var e := InputEventJoypadMotion.new()
    e.axis = axis
    e.axis_value = v
    return e

func _setup_input() -> void:
    var defs := {
        "move_left": [_key(KEY_A), _key(KEY_LEFT), _joy_axis(JOY_AXIS_LEFT_X, -1.0), _joy_btn(JOY_BUTTON_DPAD_LEFT)],
        "move_right": [_key(KEY_D), _key(KEY_RIGHT), _joy_axis(JOY_AXIS_LEFT_X, 1.0), _joy_btn(JOY_BUTTON_DPAD_RIGHT)],
        "move_up": [_key(KEY_W), _key(KEY_UP), _joy_axis(JOY_AXIS_LEFT_Y, -1.0), _joy_btn(JOY_BUTTON_DPAD_UP)],
        "move_down": [_key(KEY_S), _key(KEY_DOWN), _joy_axis(JOY_AXIS_LEFT_Y, 1.0), _joy_btn(JOY_BUTTON_DPAD_DOWN)],
        "jump": [_key(KEY_SPACE), _joy_btn(JOY_BUTTON_A)],
        "sprint": [_key(KEY_SHIFT), _joy_btn(JOY_BUTTON_RIGHT_SHOULDER), _joy_btn(JOY_BUTTON_LEFT_SHOULDER)],
        "kick": [_key(KEY_E), _key(KEY_J), _mouse(MOUSE_BUTTON_LEFT), _joy_btn(JOY_BUTTON_X)],
        "pass": [_key(KEY_Q), _key(KEY_K), _mouse(MOUSE_BUTTON_RIGHT), _joy_btn(JOY_BUTTON_B)],
        "pause": [_key(KEY_ESCAPE), _key(KEY_P), _joy_btn(JOY_BUTTON_START)],
    }
    for action in defs:
        if InputMap.has_action(action):
            InputMap.erase_action(action)
        InputMap.add_action(action, 0.25)
        for ev in defs[action]:
            if ev is InputEventMouseButton and (OS.has_feature("mobile") or force_touch): continue
            InputMap.action_add_event(action, ev)

func move_vector() -> Vector2:
    return Input.get_vector("move_left", "move_right", "move_up", "move_down")

# ---------------------------------------------------------------- save
func default_data() -> Dictionary:
    return {
        "coins": 150,
        "boombox_unlocked": false,
        "boombox_format": "",
        "boombox_enabled": false,
        "music_choice": "menu",
        "nickname": "",
        "nickname_color": "white",
        "owned": ["classic"],
        "equipped": "classic",
        "seen": ["classic"],
        "daily": {"day": "", "football": 0, "zombie": 0, "goals": 0, "run_coins": 0, "games": 0, "stars": 0},
        "stats": {
            "fb_played": 0, "fb_wins": 0, "fb_draws": 0, "fb_losses": 0, "fb_goals": 0,
            "zr_played": 0, "zr_escapes": 0, "zr_best": 0, "zr_best_time": 0.0, "zr_saved": 0,
            "chests": 0, "coins_earned": 0,
        },
        "settings": {"music": 0.7, "sfx": 0.85, "lang": "", "difficulty": 1, "fullscreen": false},
    }

func load_game() -> void:
    data = default_data()
    if FileAccess.file_exists(SAVE_PATH):
        var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
        if f:
            var parsed = JSON.parse_string(f.get_as_text())
            if parsed is Dictionary:
                _merge(data, parsed)
                # Existing custom music remains selected after the update.
                if not parsed.has("music_choice") and bool(parsed.get("boombox_enabled", false)) and str(parsed.get("boombox_format", "")) != "":
                    data.music_choice = "custom"
    # Grant rewards retroactively to players who already earned enough stars.
    if int(data.daily.stars) >= 12:
        data.boombox_unlocked = true
    data.coins = int(data.coins)
    for k in data.stats:
        if k != "zr_best_time":
            data.stats[k] = int(data.stats[k])
    if not data.owned.has("classic"):
        data.owned.append("classic")
    if not data.owned.has(data.equipped):
        data.equipped = "classic"
    var l: String = str(data.settings.get("lang", ""))
    if l == "":
        l = "ru" if OS.get_locale_language() in ["ru", "uk", "be", "kk"] else "en"
        data.settings.lang = l
    lang = l
    if force_lang == "en" or force_lang == "ru":
        lang = force_lang
    if autotest != "":
        data.coins = max(int(data.coins), 1500)

func _merge(dst: Dictionary, src: Dictionary) -> void:
    for k in src:
        if dst.has(k) and dst[k] is Dictionary and src[k] is Dictionary:
            _merge(dst[k], src[k])
        elif dst.has(k):
            dst[k] = src[k]

func save_game() -> void:
    if autotest != "":
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data, "  "))

func reset_progress() -> void:
    var keep: Dictionary = data.settings.duplicate(true)
    # Reset of game progress does not revoke the separately purchased boombox.
    var keep_box := {"unlocked": data.boombox_unlocked, "format": data.boombox_format, "enabled": data.boombox_enabled, "choice": data.music_choice}
    var keep_name := str(data.nickname)
    data = default_data()
    data.settings = keep
    data.boombox_unlocked = keep_box.unlocked
    data.boombox_format = keep_box.format
    data.boombox_enabled = keep_box.enabled
    data.music_choice = keep_box.choice
    data.nickname = keep_name
    save_game()

# ---------------------------------------------------------------- daily goals
# Local calendar day; no streak is lost if the player takes a break.
const DAILY_MILESTONES := [[5, 100], [12, 200], [24, 350], [40, 500]]

func ensure_daily(day_override := "") -> void:
    var today := day_override if day_override != "" else Time.get_date_string_from_system()
    var d: Dictionary = data.daily
    var previous := str(d.get("day", ""))
    # Moving the device clock backwards never grants an extra reset.
    if previous == "" or today > previous:
        d.day = today
        for k in ["football", "zombie", "goals", "run_coins", "games"]:
            d[k] = 0
        save_game()

func daily_variant() -> int:
    return posmod(str(data.daily.day).hash(), 3)

func daily_goals() -> Array:
    ensure_daily()
    var d: Dictionary = data.daily
    var third: Dictionary = [
        {"key": "goals", "title": "daily_goal", "target": 1},
        {"key": "run_coins", "title": "daily_coins", "target": 8},
        {"key": "games", "title": "daily_games", "target": 3},
    ][daily_variant()]
    return [
        {"key": "football", "title": "daily_football", "target": 1, "reward": 35},
        {"key": "zombie", "title": "daily_zombie", "target": 1, "reward": 35},
        {"key": third.key, "title": third.title, "target": third.target, "reward": 50},
    ]

func daily_completed_count() -> int:
    var count := 0
    for goal in daily_goals():
        if int(data.daily.get(goal.key, 0)) >= int(goal.target): count += 1
    return count

func daily_next_milestone() -> Array:
    var stars := int(data.daily.stars)
    for m in DAILY_MILESTONES:
        if stars < int(m[0]): return m
    # After the fixed milestones, keep the journey going without resetting it.
    var step := int((stars - 40) / 15) + 1
    return [40 + step * 15, 300]

# Called exactly once at the end of a completed match/run. The caller adds the
# returned rewards to its existing result and saves everything in one write.
func record_daily(mode: String, goals := 0, run_coins := 0) -> int:
    last_journey_unlocks.clear()
    ensure_daily()
    var tasks := daily_goals()
    var d: Dictionary = data.daily
    var before: Array = []
    for goal in tasks:
        before.append(int(d.get(goal.key, 0)) >= int(goal.target))
    if mode == "football":
        d.football = int(d.football) + 1
        d.goals = int(d.goals) + maxi(0, goals)
    elif mode == "zombie":
        d.zombie = int(d.zombie) + 1
        d.run_coins = int(d.run_coins) + maxi(0, run_coins)
    else:
        return 0
    d.games = int(d.games) + 1
    var reward := 0
    var old_stars := int(d.stars)
    for i in tasks.size():
        var g: Dictionary = tasks[i]
        if not before[i] and int(d.get(g.key, 0)) >= int(g.target):
            reward += int(g.reward)
            d.stars = int(d.stars) + 1
    for milestone in DAILY_MILESTONES:
        if old_stars < int(milestone[0]) and int(d.stars) >= int(milestone[0]):
            reward += int(milestone[1])
    if old_stars < 5 and int(d.stars) >= 5:
        last_journey_unlocks.append("nick_unlocked")
    if old_stars < 12 and int(d.stars) >= 12:
        if not bool(data.boombox_unlocked):
            data.boombox_unlocked = true
            last_journey_unlocks.append("box_unlocked")
    var first_repeat := maxi(1, int(floor(float(old_stars - 40) / 15.0)) + 1)
    var last_repeat := int(floor(float(int(d.stars) - 40) / 15.0))
    if last_repeat >= first_repeat:
        reward += (last_repeat - first_repeat + 1) * 300
    return reward

# ---------------------------------------------------------------- economy
func coins() -> int:
    return int(data.coins)

func add_coins(n: int) -> void:
    data.coins = int(data.coins) + n
    if n > 0:
        data.stats.coins_earned = int(data.stats.coins_earned) + n
    save_game()

func stat_add(key: String, n = 1) -> void:
    data.stats[key] = data.stats.get(key, 0) + n

func get_skin(id: String) -> Dictionary:
    for s in SKINS:
        if s.id == id:
            return s
    return SKINS[0]

func skin_name(id: String) -> String:
    var s := get_skin(id)
    return s.ru if lang == "ru" else s.en

func get_chest(id: String) -> Dictionary:
    for c in CHESTS:
        if c.id == id:
            return c
    return CHESTS[0]

func chest_name(id: String) -> String:
    var c := get_chest(id)
    return c.ru if lang == "ru" else c.en

func is_owned(id: String) -> bool:
    return data.owned.has(id)

func equip(id: String) -> void:
    if is_owned(id):
        data.equipped = id
        save_game()

func equipped() -> String:
    return str(data.equipped)

const NAMES_RU := {"Alex": "Алекс", "Max": "Макс", "Nick": "Ник", "Sam": "Сэм", "Ben": "Бен"}

## Localized character name.
# Nicknames intentionally use only Latin/Cyrillic letters, digits, _ and -.
const NICK_COLORS := {"white": Color("ffffff"), "blue": Color("83ddff"), "green": Color("a5f47b"), "pink": Color("ffa9d4"), "gold": Color("ffe16b")}
const BOT_NAMES := ["ШИПОКРЫЛ", "unstoppable", "xX_VOLODYA_Xx", "Тихий_ёж", "HeadShot", "Baton228", "Пельмень", "neon_rush", "КАПИБОСС", "OldSchool", "Без_паники", "KOT_B_TAPKE", "NightWolf", "Пуля_дура", "NoScope", "Кексик", "ShadowFox", "Мокрый_кот", "AimMonster", "Тапок_судьбы", "S1mpleKapy", "Мистер_Пух", "Frostbite", "Огурец", "Boomer", "Колючка", "RedStorm", "Лютый_Пончик", "Sn1per", "Косой", "LuckyDuck", "Рыжий_лиc", "D1no", "Малыш", "TurboKeks", "Лесной", "V1PER", "Сонный_зверь", "N0Mercy", "Кефирыч", "SilentShot", "ПЫШКА", "DarkHunter", "Квасной", "FireFox", "Батя_на_базе", "BunnyHop", "Безымянный", "Лесник", "Fantom", "ZloyKotik", "Пирожок", "LuckyOne", "Шустрый", "Odin", "CrazyFox", "Капи_Танкист", "Mr_Boom", "Хруст", "IceCold"]

func valid_nickname(value: String) -> bool:
    if value.length() < 3 or value.length() > 16: return false
    for i in value.length():
        var c := value.unicode_at(i)
        if not ((c >= 48 and c <= 57) or (c >= 65 and c <= 90) or (c >= 97 and c <= 122) or (c >= 0x410 and c <= 0x44f) or c == 0x401 or c == 0x451 or c == 45 or c == 95):
            return false
    return true

func player_nickname() -> String:
    return str(data.nickname) if valid_nickname(str(data.nickname)) else "Capy"

func player_nick_color() -> Color:
    if int(data.daily.stars) < 5: return Color.WHITE
    return NICK_COLORS.get(str(data.nickname_color), Color.WHITE)

func random_bot_names(count: int) -> Array:
    var pool := BOT_NAMES.duplicate()
    pool.shuffle()
    var result: Array = []
    for n in pool:
        if str(n).to_lower() != player_nickname().to_lower(): result.append(n)
        if result.size() >= count: break
    return result

func journey_reward_text(milestone: Array) -> String:
    var goal := int(milestone[0])
    if goal == 5: return t("next_nick") % int(milestone[1])
    if goal == 12: return t("next_box") % int(milestone[1])
    return t("daily_next") % int(milestone[1])

func cname(n: String) -> String:
    return str(NAMES_RU.get(n, n)) if lang == "ru" else n

func difficulty() -> int:
    if force_diff >= 0:
        return force_diff
    return int(data.settings.difficulty)

func roll_chest(chest_id: String) -> Dictionary:
    var c := get_chest(chest_id)
    if coins() < int(c.price):
        return {}
    data.coins = coins() - int(c.price)
    var r := randi() % 100
    var acc := 0
    var rarity := "common"
    for i in 4:
        acc += int(c.odds[i])
        if r < acc:
            rarity = RARITIES[i]
            break
    var pool: Array = []
    for s in SKINS:
        if s.rarity == rarity and s.id != "classic":
            pool.append(s)
    var unowned: Array = pool.filter(func(s): return not is_owned(s.id))
    var res := {"rarity": rarity, "new": false, "refund": 0, "chest": chest_id}
    if unowned.size() > 0:
        var pick: Dictionary = unowned.pick_random()
        res.skin = pick.id
        res.new = true
        data.owned.append(pick.id)
    else:
        var pick2: Dictionary = pool.pick_random()
        res.skin = pick2.id
        res.refund = int(REFUND[rarity])
        data.coins = coins() + res.refund
    stat_add("chests")
    save_game()
    return res

# ---------------------------------------------------------------- text
func t(key: String) -> String:
    var e = TEXT.get(key)
    if e == null:
        return key
    return e[1] if lang == "ru" else e[0]

func set_lang(l: String) -> void:
    lang = l
    data.settings.lang = l
    save_game()

# ---------------------------------------------------------------- settings
func apply_settings() -> void:
    var mi := AudioServer.get_bus_index("Music")
    var si := AudioServer.get_bus_index("SFX")
    var mv := float(data.settings.music)
    var sv := float(data.settings.sfx)
    AudioServer.set_bus_volume_db(mi, linear_to_db(max(mv, 0.0001)) - 4.0)
    AudioServer.set_bus_mute(mi, mv <= 0.01)
    AudioServer.set_bus_volume_db(si, linear_to_db(max(sv, 0.0001)))
    AudioServer.set_bus_mute(si, sv <= 0.01)
    if autotest == "":
        var fs: bool = data.settings.fullscreen
        var mode := DisplayServer.window_get_mode()
        var is_fs := mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN
        if fs and not is_fs:
            DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
        elif not fs and is_fs:
            DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _unhandled_key_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_F11:
        data.settings.fullscreen = not data.settings.fullscreen
        apply_settings()
        save_game()

# ---------------------------------------------------------------- audio
func _setup_audio() -> void:
    for bus in ["Music", "SFX"]:
        if AudioServer.get_bus_index(bus) == -1:
            AudioServer.add_bus()
            var i := AudioServer.bus_count - 1
            AudioServer.set_bus_name(i, bus)
            AudioServer.set_bus_send(i, "Master")
    _music_a = AudioStreamPlayer.new()
    _music_b = AudioStreamPlayer.new()
    for p in [_music_a, _music_b]:
        p.bus = "Music"
        p.volume_db = -80.0
        add_child(p)
    for i in 16:
        var p := AudioStreamPlayer.new()
        p.bus = "SFX"
        add_child(p)
        _sfx_pool.append(p)

func _stream(path: String) -> AudioStream:
    if _stream_cache.has(path):
        return _stream_cache[path]
    var s: AudioStream = null
    if ResourceLoader.exists(path):
        s = load(path)
    _stream_cache[path] = s
    return s

func sfx(name: String, vol_db := 0.0, pitch := 1.0) -> void:
    var path := "res://assets/audio/%s.wav" % name
    if not ResourceLoader.exists(path):
        path = "res://assets/audio/%s.ogg" % name
    var s := _stream(path)
    if s == null:
        return
    var p: AudioStreamPlayer = _sfx_pool[_sfx_next]
    _sfx_next = (_sfx_next + 1) % _sfx_pool.size()
    p.stream = s
    p.volume_db = vol_db
    p.pitch_scale = pitch
    p.play()

func sfx_rand(name: String, vol_db := 0.0, spread := 0.08) -> void:
    sfx(name, vol_db, randf_range(1.0 - spread, 1.0 + spread))

const BOOMBOX_TRACK := "user://boombox_track.dat"
const BOOMBOX_TEMP := "user://boombox_pending.dat"
const BOOMBOX_BACKUP := "user://boombox_backup.dat"
const BOOMBOX_LIMIT := 32 * 1024 * 1024

func unlock_boombox() -> bool:
    if bool(data.boombox_unlocked): return true
    if int(data.daily.stars) < 12: return false
    data.boombox_unlocked = true
    save_game()
    return true

func _audio_from_bytes(bytes: PackedByteArray, kind: String) -> AudioStream:
    var stream: AudioStream = null
    match kind:
        "mp3": stream = AudioStreamMP3.load_from_buffer(bytes)
        "ogg": stream = AudioStreamOggVorbis.load_from_buffer(bytes)
        "wav": stream = AudioStreamWAV.load_from_buffer(bytes)
    if stream == null or stream.get_length() <= 0.0: return null
    if stream is AudioStreamMP3: (stream as AudioStreamMP3).loop = true
    if stream is AudioStreamOggVorbis: (stream as AudioStreamOggVorbis).loop = true
    if stream is AudioStreamWAV:
        var wav := stream as AudioStreamWAV
        wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
        wav.loop_end = int(wav.get_length() * wav.mix_rate)
    return stream

# SAF content:// paths on Android are read only after the player selects a file.
# Validate before replacing the previous file so a failed selection is harmless.
func import_boombox_track(path: String) -> bool:
    if not bool(data.boombox_unlocked): return false
    var source := FileAccess.open(path, FileAccess.READ)
    if source == null: return false
    var length := source.get_length()
    if length < 4 or length > BOOMBOX_LIMIT: return false
    var bytes := source.get_buffer(length)
    if bytes.size() != length: return false
    var head := bytes.slice(0, 4).get_string_from_ascii()
    var kind := "ogg" if head == "OggS" else ("wav" if head == "RIFF" else "mp3")
    var stream := _audio_from_bytes(bytes, kind)
    if stream == null: return false
    var out := FileAccess.open(BOOMBOX_TEMP, FileAccess.WRITE)
    if out == null: return false
    out.store_buffer(bytes)
    out.flush()
    if out.get_error() != OK:
        out.close()
        DirAccess.remove_absolute(BOOMBOX_TEMP)
        return false
    out.close()
    var had_old := FileAccess.file_exists(BOOMBOX_TRACK)
    if had_old:
        DirAccess.remove_absolute(BOOMBOX_BACKUP)
        if DirAccess.rename_absolute(BOOMBOX_TRACK, BOOMBOX_BACKUP) != OK:
            DirAccess.remove_absolute(BOOMBOX_TEMP)
            return false
    if DirAccess.rename_absolute(BOOMBOX_TEMP, BOOMBOX_TRACK) != OK:
        if had_old: DirAccess.rename_absolute(BOOMBOX_BACKUP, BOOMBOX_TRACK)
        return false
    if had_old: DirAccess.remove_absolute(BOOMBOX_BACKUP)
    data.boombox_format = kind
    data.boombox_enabled = true
    data.music_choice = "custom"
    save_game()
    _start_music_stream(stream, "boombox", 0.4)
    return true

func play_menu_music() -> void:
    var choice := str(data.music_choice)
    if choice == "off":
        stop_music(0.4)
        return
    if choice == "custom" and bool(data.boombox_unlocked) and str(data.boombox_format) != "" and FileAccess.file_exists(BOOMBOX_TRACK):
        var f := FileAccess.open(BOOMBOX_TRACK, FileAccess.READ)
        if f != null and f.get_length() <= BOOMBOX_LIMIT:
            var stream := _audio_from_bytes(f.get_buffer(f.get_length()), str(data.boombox_format))
            if stream != null:
                _start_music_stream(stream, "boombox", 0.5)
                return
    if choice not in ["menu", "football", "zombie"]: choice = "menu"
    play_music(choice, 0.5)

func select_menu_music(choice: String) -> void:
    if not bool(data.boombox_unlocked): return
    if choice not in ["menu", "football", "zombie", "custom", "off"]: return
    if choice == "custom" and (str(data.boombox_format) == "" or not FileAccess.file_exists(BOOMBOX_TRACK)): return
    data.music_choice = choice
    data.boombox_enabled = choice == "custom"
    save_game()
    play_menu_music()

func set_boombox_enabled(value: bool) -> void:
    select_menu_music("custom" if value and str(data.boombox_format) != "" else ("menu" if value else "off"))

func play_music(name: String, fade := 1.0) -> void:
    if name == _music_name: return
    var stream := _stream("res://assets/audio/music_%s.ogg" % name)
    if stream is AudioStreamOggVorbis: (stream as AudioStreamOggVorbis).loop = true
    _start_music_stream(stream, name, fade)

func _start_music_stream(stream: AudioStream, name: String, fade: float) -> void:
    if _music_tween and _music_tween.is_valid(): _music_tween.kill()
    _music_name = name if stream else ""
    var old := _music_a
    var nw := _music_b
    _music_a = nw
    _music_b = old
    nw.stop()
    if stream:
        nw.stream = stream
        nw.volume_db = -40.0
        nw.play()
    _music_tween = create_tween().set_parallel(true)
    if stream: _music_tween.tween_property(nw, "volume_db", 0.0, fade)
    _music_tween.tween_property(old, "volume_db", -80.0, fade)
    _music_tween.chain().tween_callback(old.stop)

func stop_music(fade := 0.6) -> void:
    if _music_tween and _music_tween.is_valid(): _music_tween.kill()
    _music_name = ""
    _music_tween = create_tween().set_parallel(true)
    for player in [_music_a, _music_b]:
        _music_tween.tween_property(player, "volume_db", -80.0, fade)
    _music_tween.chain().tween_callback(func():
        _music_a.stop()
        _music_b.stop())

# ---------------------------------------------------------------- theme
func _sb(color: Color, radius := 14) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.set_corner_radius_all(radius)
    s.anti_aliasing = true
    return s

func _build_theme() -> void:
    theme = Theme.new()
    theme.default_font = FONT
    theme.default_font_size = 22
    theme.set_color("font_color", "Label", Color.WHITE)
    # sliders
    var track := _sb(Color(0, 0, 0, 0.3), 8)
    track.content_margin_top = 6
    track.content_margin_bottom = 6
    theme.set_stylebox("slider", "HSlider", track)
    var fill := _sb(Color("77ab60"), 8)
    fill.content_margin_top = 6
    fill.content_margin_bottom = 6
    theme.set_stylebox("grabber_area", "HSlider", fill)
    theme.set_stylebox("grabber_area_highlight", "HSlider", fill)
    theme.set_icon("grabber", "HSlider", _circle_tex(30, Color.WHITE))
    theme.set_icon("grabber_highlight", "HSlider", _circle_tex(30, Color("fff2c9")))
    # scroll bars
    var sc := _sb(Color(0, 0, 0, 0.18), 6)
    sc.content_margin_left = 5
    sc.content_margin_right = 5
    theme.set_stylebox("scroll", "VScrollBar", sc)
    theme.set_stylebox("grabber", "VScrollBar", _sb(Color(1, 1, 1, 0.55), 6))
    theme.set_stylebox("grabber_highlight", "VScrollBar", _sb(Color(1, 1, 1, 0.8), 6))
    theme.set_stylebox("grabber_pressed", "VScrollBar", _sb(Color(1, 1, 1, 0.9), 6))
    # tooltips
    var tip := _sb(Color("2f3357"), 10)
    tip.content_margin_left = 10
    tip.content_margin_right = 10
    tip.content_margin_top = 6
    tip.content_margin_bottom = 6
    theme.set_stylebox("panel", "TooltipPanel", tip)
    theme.set_color("font_color", "TooltipLabel", Color.WHITE)
    get_tree().root.theme = theme

func _circle_tex(sz: int, col: Color) -> ImageTexture:
    var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
    var c := (sz - 1) * 0.5
    for y in sz:
        for x in sz:
            var d := Vector2(x - c, y - c).length()
            var a := clampf(c - d, 0.0, 1.0)
            var shade := 1.0 if d < c - 3.0 else 0.85
            img.set_pixel(x, y, Color(col.r * shade, col.g * shade, col.b * shade, a))
    return ImageTexture.create_from_image(img)

# ---------------------------------------------------------------- scene switching
func _build_fade() -> void:
    _fade_layer = CanvasLayer.new()
    _fade_layer.layer = 100
    add_child(_fade_layer)
    _fade_rect = ColorRect.new()
    _fade_rect.color = Color(0.16, 0.18, 0.32, 0.0)
    _fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
    _fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _fade_layer.add_child(_fade_rect)
    _fade_label = Label.new()
    _fade_label.add_theme_font_size_override("font_size", 30)
    _fade_label.set_anchors_preset(Control.PRESET_FULL_RECT)
    _fade_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _fade_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _fade_label.modulate.a = 0.0
    _fade_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _fade_rect.add_child(_fade_label)

func goto(path: String) -> void:
    if _busy:
        return
    _busy = true
    _fade_label.text = t("loading")
    _fade_rect.mouse_filter = Control.MOUSE_FILTER_STOP
    var tw := create_tween().set_parallel(true)
    tw.tween_property(_fade_rect, "color:a", 1.0, 0.35)
    tw.tween_property(_fade_label, "modulate:a", 1.0, 0.35)
    await tw.finished
    get_tree().paused = false
    Engine.time_scale = 1.0
    get_tree().change_scene_to_file(path)
    await get_tree().process_frame
    await get_tree().process_frame
    await get_tree().process_frame
    var tw2 := create_tween().set_parallel(true)
    tw2.tween_property(_fade_rect, "color:a", 0.0, 0.5)
    tw2.tween_property(_fade_label, "modulate:a", 0.0, 0.25)
    await tw2.finished
    _fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _busy = false

func is_busy() -> bool:
    return _busy

func quit_game() -> void:
    save_game()
    get_tree().quit()
