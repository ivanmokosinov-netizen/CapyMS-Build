extends Node
## One shared inverted-hull pass for opaque meshes; translucent FX remain untouched.
var outline_material: ShaderMaterial
var fine_outline: ShaderMaterial
var material_cache := {}
var icon_outline: ShaderMaterial

func _ready() -> void:
    var shader := Shader.new()
    shader.code = """
shader_type spatial;
render_mode unshaded, cull_front, depth_draw_never, shadows_disabled, fog_disabled;
uniform float line_width = 0.025;
void vertex() {
    VERTEX += NORMAL * line_width;
}
void fragment() { ALBEDO = vec3(0.0); }
"""
    outline_material = ShaderMaterial.new()
    outline_material.shader = shader
    fine_outline = ShaderMaterial.new()
    fine_outline.shader = shader
    fine_outline.set_shader_parameter("line_width", 0.006)
    var icon_shader := Shader.new()
    icon_shader.code = """
shader_type canvas_item;
varying vec4 vertex_tint;
void vertex() { vertex_tint = COLOR; }
void fragment() {
    vec4 src = texture(TEXTURE, UV);
    vec2 d = TEXTURE_PIXEL_SIZE * 2.0;
    float a = src.a;
    a = max(a, texture(TEXTURE, UV + vec2(d.x, 0.0)).a);
    a = max(a, texture(TEXTURE, UV - vec2(d.x, 0.0)).a);
    a = max(a, texture(TEXTURE, UV + vec2(0.0, d.y)).a);
    a = max(a, texture(TEXTURE, UV - vec2(0.0, d.y)).a);
    a = max(a, texture(TEXTURE, UV + d).a);
    a = max(a, texture(TEXTURE, UV - d).a);
    a = max(a, texture(TEXTURE, UV + vec2(d.x, -d.y)).a);
    a = max(a, texture(TEXTURE, UV + vec2(-d.x, d.y)).a);
    vec3 rgb = src.rgb * src.a / max(a, 0.0001);
    COLOR = vec4(rgb * vertex_tint.rgb, a * vertex_tint.a);
}
"""
    icon_outline = ShaderMaterial.new()
    icon_outline.shader = icon_shader
    get_tree().node_added.connect(_on_node_added)

func _on_node_added(node: Node) -> void:
    if node is MeshInstance3D or node is TextureRect:
        _apply_id.call_deferred(node.get_instance_id())

func _apply_id(id: int) -> void:
    var instance := instance_from_id(id)
    if not is_instance_valid(instance) or not instance.is_inside_tree(): return
    if instance is MeshInstance3D:
        apply_mesh(instance)
    elif instance is TextureRect:
        var tex: Texture2D = instance.texture
        if tex and not instance.material:
            var path := tex.resource_path
            if path.contains("/ui/icons/") or path.contains("/ui/chests/") or path.contains("/ui/skins/"):
                instance.material = icon_outline

func apply_tree(node: Node) -> void:
    if node is MeshInstance3D:
        apply_mesh(node)
    for child in node.get_children():
        apply_tree(child)

func apply_mesh(instance: MeshInstance3D) -> void:
    if not instance.mesh or instance.mesh is QuadMesh or instance.mesh is PlaneMesh:
        return
    if instance.material_override:
        return
    # A thinner silhouette for the hero and crates; avoid outlining their small
    # material details, which otherwise makes seams and scratches on the faces.
    var is_capy := false
    var is_boombox := false
    var ancestor: Node = instance
    while ancestor:
        if ancestor.has_meta("outline_boombox"):
            is_boombox = true
        var script: Script = ancestor.get_script()
        if script and script.resource_path == "res://scripts/capy_model.gd":
            is_capy = true
            break
        ancestor = ancestor.get_parent()
    var is_crate := str(instance.name).begins_with("Crate_mesh")
    # Outline only the main cabinet, not the many tiny speaker and trim meshes.
    if is_boombox and instance.name != "Cabinet":
        return
    var chosen_outline := fine_outline if is_capy or is_crate or is_boombox else outline_material
    for i in instance.mesh.get_surface_count():
        var original: Material = instance.get_surface_override_material(i)
        if not original:
            original = instance.mesh.surface_get_material(i)
        if not original is BaseMaterial3D:
            continue
        var base := original as BaseMaterial3D
        if base.transparency != BaseMaterial3D.TRANSPARENCY_DISABLED or base.albedo_color.a < 0.99:
            continue
        if base.shading_mode == BaseMaterial3D.SHADING_MODE_UNSHADED:
            continue
        if (is_capy and base.resource_name not in ["Fur", "FurDark", "Snout", "Feet"]) or (is_crate and base.resource_name != "Crate"):
            continue
        if base.next_pass == outline_material or base.next_pass == fine_outline:
            continue
        # Preserve custom next passes rather than clobbering an existing effect.
        if base.next_pass != null:
            continue
        var key := str(base.get_instance_id()) + ("_fine" if chosen_outline == fine_outline else "_normal")
        if not material_cache.has(key):
            if material_cache.size() >= 512: material_cache.clear()
            var outlined: BaseMaterial3D = base.duplicate()
            outlined.next_pass = chosen_outline
            material_cache[key] = outlined
        instance.set_surface_override_material(i, material_cache[key])
