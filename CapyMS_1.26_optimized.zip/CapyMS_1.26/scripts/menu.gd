extends Node3D
## CapyMS — main menu.
## A floating sky island with your capybara, mode selection (Big Football,
## Zombie Run), settings, stats and the Skins & Chests screen with an
## animated chest opening.

const UI := preload("res://scripts/ui.gd")
const FX := preload("res://scripts/fx.gd")
const W := preload("res://scripts/world.gd")
const CapyModel := preload("res://scripts/capy_model.gd")
const ZombieModel := preload("res://scripts/zombie_model.gd")

const M_ISLAND := preload("res://assets/models/island.glb")
const M_TREE := preload("res://assets/models/tree.glb")
const M_BOOMBOX := preload("res://assets/models/boombox.glb")
const M_BENCH := preload("res://assets/models/bench.glb")
const M_LAMP := preload("res://assets/models/lamp.glb")
const M_CRATE := preload("res://assets/models/crate.glb")
const M_CONE := preload("res://assets/models/cone.glb")
const M_BALL := preload("res://assets/models/ball.glb")
const M_COIN := preload("res://assets/models/coin.glb")
const M_CLOUD := preload("res://assets/models/cloud.glb")
const M_CHEST := {
    "wood": preload("res://assets/models/chest_wood.glb"),
    "epic": preload("res://assets/models/chest_epic.glb"),
    "mystic": preload("res://assets/models/chest_mystic.glb"),
}
const LOGO := preload("res://assets/ui/logo.png")
const RAYS := preload("res://assets/ui/rays.png")
const GLOW := preload("res://assets/textures/glow.png")
const COIN_TEX := preload("res://assets/ui/icons/coin.png")
const MenuAmbience := preload("res://scripts/menu_ambience.gd")
const MENU_GLINT := preload("res://assets/ui/menu_glint.png")
const MENU_GLOSS := preload("res://assets/ui/menu_button_gloss.png")

## Camera views: [position, look-at point].
const VIEWS := {
    "main": [Vector3(-1.6, 2.7, 7.2), Vector3(-1.25, 1.05, 0.4)],
    "skins": [Vector3(-1.5, 2.2, 5.6), Vector3(-1.35, 1.0, 0.5)],
    "chest": [Vector3(-2.2, 2.3, 7.3), Vector3(-1.5, 0.7, 1.7)],
    "reveal": [Vector3(-3.2, 2.4, 7.5), Vector3(-3.0, 0.95, 1.4)],
}
const CAPY_POS := Vector3(0.3, 0.0, 0.6)
const CAPY_YAW := PI - 0.75
const CAPY_SCALE := 1.5
const CHEST_POS := Vector3(-1.9, 0.0, 2.4)
const BALL_Y := 0.33
const ZOMBIE_HIDE := Vector3(-0.75, -1.7, -3.3)
const ZOMBIE_PEEK := Vector3(-0.75, 0.0, -3.3)

# ---------------------------------------------------------------- 3D state
var cam: Camera3D
var cam_pos := Vector3.ZERO
var cam_look := Vector3.ZERO
var view := "main"
var shake := 0.0
var t := 0.0
var capy
var capy_yaw := CAPY_YAW
var zombie
var zombie_state := 0
var zombie_t := 5.0
var boombox: Node3D
var ball: Node3D
var ball_hop := 0.0
var coins3d: Array = []
var clouds: Array = []
var far_islands: Array = []
var pokes := 0
var mouse_seen := false
var mouse_down := false
var dragging := false
var press_pos := Vector2.ZERO

# chest opening
var busy := false
var chest_stage := 0
var chest_node: Node3D = null
var chest_fx: Array = []
var beam_tex: Texture2D

# ---------------------------------------------------------------- UI state
var layer: CanvasLayer
var toast_box: VBoxContainer
var root: Control
var main_ui: Control
var skins_ui: Control
var logo_rect: TextureRect
var logo_glint: TextureRect
var ambience: Control
var coin_glows: Array = []
var coin_pill: Control
var coin_label: Label
var daily_button: Button
var daily_refresh_timer := 0.0
var coin_tween: Tween
var shown_coins := 0.0
var menu_btns: Control
var hint_box: Control
var skins_sub: Label
var skins_badge: Control
var modal_ov: Control = null
var profile_required := false
var confirm_ov: Control = null
var reveal_ov: Control = null
var tab := "skins"
var tab_btns := {}
var content: VBoxContainer
var cards := {}
var icon_cache: Dictionary = {}
var sel_skin := ""
var info_name: Label
var info_rarity: Label
var info_action: HBoxContainer

func _ready() -> void:
    _build_world()
    var ambience_layer := CanvasLayer.new()
    ambience_layer.layer = 3
    add_child(ambience_layer)
    ambience = MenuAmbience.new()
    ambience_layer.add_child(ambience)
    layer = CanvasLayer.new()
    layer.layer = 5
    add_child(layer)
    var tl := CanvasLayer.new()
    tl.layer = 8
    add_child(tl)
    toast_box = VBoxContainer.new()
    toast_box.set_anchors_preset(Control.PRESET_TOP_WIDE)
    toast_box.offset_top = 104
    toast_box.add_theme_constant_override("separation", 8)
    toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    tl.add_child(toast_box)
    _build_ui()
    var v0: Array = VIEWS["main"]
    cam_pos = v0[0] + Vector3(2.0, 2.2, 5.0)
    cam_look = v0[1] + Vector3(0.0, 0.8, 0.0)
    _update_camera(0.0)
    Game.play_menu_music()
    var ret: Dictionary = Game.last_result.duplicate()
    Game.last_result = {}
    shown_coins = float(Game.coins())
    var gained := int(ret.get("coins", 0))
    if gained > 0:
        shown_coins = float(maxi(0, Game.coins() - gained))
        _later(1.0, func():
            _toast("+%d" % gained, UI.GOLD, "coin")
            Game.sfx("coin")
            _refresh_coins())
    _update_coin_label()
    if Game.autotest != "":
        _autotest(ret)
    elif not Game.valid_nickname(str(Game.data.nickname)):
        _open_profile.call_deferred(true)

func _icon(n: String) -> Texture2D:
    if not icon_cache.has(n):
        icon_cache[n] = load("res://assets/ui/icons/%s.png" % n)
    return icon_cache[n]

func _later(sec: float, f: Callable) -> void:
    var tw := create_tween()
    tw.tween_interval(sec)
    tw.tween_callback(f)

func _wait(sec: float) -> void:
    await get_tree().create_timer(sec).timeout

# ================================================================ world
func _build_world() -> void:
    W.environment(self, Color("69beff"), Color("b5e1ff"), Color("b5d8f0"), {
        "ambient": 0.9, "exposure": 1.0, "glow": 0.3, "curve": 0.15, "sat": 1.18,
        "sky_contrib": 0.45, "amb_color": Color(1.0, 0.9, 0.8),
        "mobile_ambient_scale": 0.76, "mobile_exposure_scale": 0.85,
        "mobile_sat": 1.16, "mobile_contrast": 1.07, "mobile_bright": 1.0, "mobile_bloom": 0.012,
        "fog": Color("cbe8fb"), "fog_density": 0.0045, "fog_sky": 0.0,
    })
    W.sun(self, Vector3(-50, -35, 0), 1.4, Color(1.0, 0.94, 0.85), 45.0)
    cam = Camera3D.new()
    cam.fov = 40.0
    cam.near = 0.1
    cam.far = 400.0
    add_child(cam)
    cam.make_current()
    # Soft, inexpensive sky halo, placed well behind the floating island.
    var sky_glow := _additive_quad(GLOW, Vector2(32, 32), Color(1.0, 0.96, 0.85, 0.22), BaseMaterial3D.BILLBOARD_ENABLED)
    sky_glow.position = Vector3(4.0, 6.0, -35.0)
    add_child(sky_glow)
    var island: Node3D = M_ISLAND.instantiate()
    W.mature_island(island)
    W.recolor(island, "IslandGrass", Color("356900"))
    W.recolor(island, "IslandGrassSide", Color("2b5300"))
    add_child(island)
    # props on the island
    _prop(M_TREE, Vector3(-3.7, 0, -2.2), 0.5)
    _prop(M_TREE, Vector3(3.6, 0, -3.2), -0.9, 0.8)
    _prop(M_LAMP, Vector3(3.4, 0, -1.4), 0.3)
    _prop(M_BENCH, Vector3(1.5, 0, -2.9), -0.2)
    _prop(M_CRATE, Vector3(2.95, 0, -0.2), 0.35)
    _prop(M_CRATE, Vector3(3.0, 1.0, -0.25), 0.9, 0.72)
    _prop(M_CONE, Vector3(-2.7, 0, 2.4), 0.0)
    _prop(M_CONE, Vector3(2.4, 0, 2.6), 0.6)
    ball = _prop(M_BALL, Vector3(1.7, BALL_Y, 2.0), 0.0, 0.6)
    _build_boombox()
    _prop(M_CHEST["mystic"], Vector3(-1.9, 0, -1.5), 0.45)
    for i in 3:
        var c: Node3D = M_COIN.instantiate()
        c.position = Vector3(-1.9 + (i - 1) * 0.7, 1.45, -1.5)
        c.scale = Vector3.ONE * 0.75
        add_child(c)
        coins3d.append(c)
    # Small, inexpensive warm glows around the rotating coins.
    for c in coins3d:
        var cg := _additive_quad(GLOW, Vector2(0.9, 0.9), Color(1.0, 0.72, 0.25, 0.26), BaseMaterial3D.BILLBOARD_ENABLED)
        cg.position = c.position
        add_child(cg)
        coin_glows.append(cg)
    _add_ambient_sparks()
    # A restrained warm halo separates the hero from the background without a costly light.
    var hero_halo := _additive_quad(GLOW, Vector2(3.0, 3.0), Color(1.0, 0.84, 0.58, 0.20), BaseMaterial3D.BILLBOARD_ENABLED)
    hero_halo.position = Vector3(0.3, 1.35, -0.85)
    add_child(hero_halo)
    # the hero
    capy = CapyModel.new()
    capy.position = CAPY_POS
    capy.rotation.y = CAPY_YAW
    capy.scale = Vector3.ONE * CAPY_SCALE
    add_child(capy)
    _apply_menu_skin(Game.equipped())
    # a sneaky zombie that pops out of the ground now and then
    zombie = ZombieModel.new()
    zombie.position = ZOMBIE_HIDE
    zombie.rotation.y = PI + 0.15
    zombie.visible = false
    add_child(zombie)
    # The hidden zombie has no visible animation; resume it when it peeks out.
    zombie.set_process(false)
    # clouds drifting around
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    for i in 12:
        var cl: Node3D = M_CLOUD.instantiate()
        if i < 2:
            cl.position = Vector3(rng.randf_range(-18.0, 10.0), rng.randf_range(-13.0, -10.0), rng.randf_range(-16.0, -4.0))
        else:
            cl.position = Vector3(rng.randf_range(-55.0, 55.0), rng.randf_range(-6.0, 14.0), rng.randf_range(-62.0, -16.0))
        var s := rng.randf_range(1.0, 2.6)
        cl.scale = Vector3(s, s * rng.randf_range(0.8, 1.1), s)
        cl.rotation.y = rng.randf_range(-0.4, 0.4)
        W.set_shadows(cl, false)
        add_child(cl)
        clouds.append([cl, rng.randf_range(0.25, 0.7)])
    # small far-away islands
    var defs := [[Vector3(-19.0, -3.5, -26.0), 0.34, 0.6], [Vector3(18.0, 1.5, -34.0), 0.26, 2.1]]
    for d in defs:
        var fi := Node3D.new()
        fi.position = d[0]
        fi.scale = Vector3.ONE * float(d[1])
        add_child(fi)
        var distant_island: Node3D = M_ISLAND.instantiate()
        W.mature_island(distant_island)
        W.recolor(distant_island, "IslandGrass", Color("356900"))
        W.recolor(distant_island, "IslandGrassSide", Color("2b5300"))
        fi.add_child(distant_island)
        var tr: Node3D = M_TREE.instantiate()
        W.mature_tree(tr)
        tr.position = Vector3(-1.0, 0, -0.5)
        fi.add_child(tr)
        W.set_shadows(fi, false)
        far_islands.append([fi, d[0], float(d[2])])

# Match the reference's warmer, deeper natural fur in the menu only.
# Unusual coloured skins retain their own palettes.
func _apply_menu_skin(id: String) -> void:
    capy.apply_skin(id)
    if str(Game.get_skin(id).get("fur", "")) == "":
        capy.set_material("Fur", Color("64371f"))
        capy.set_material("FurDark", Color("512a1b"))
        capy.set_material("Snout", Color("5a3020"))
        capy.set_material("Feet", Color("361c11"))

func _prop(scene: PackedScene, pos: Vector3, rot_y := 0.0, s := 1.0) -> Node3D:
    var n: Node3D = scene.instantiate()
    if scene == M_TREE:
        W.mature_tree(n)
    n.position = pos
    n.rotation.y = rot_y
    n.scale = Vector3.ONE * s
    add_child(n)
    return n

# A single low-count particle system: drifting golden dust, no dynamic lights/shadows.
func _add_ambient_sparks() -> void:
    var p := CPUParticles3D.new()
    var qm := QuadMesh.new()
    qm.size = Vector2(0.11, 0.11)
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.albedo_texture = MENU_GLINT
    mat.vertex_color_use_as_albedo = true
    qm.material = mat
    p.mesh = qm
    p.amount = 22
    p.lifetime = 4.0
    p.preprocess = 4.0
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    p.emission_box_extents = Vector3(3.0, 0.75, 1.2)
    p.position = Vector3(0.0, 1.0, -0.5)
    p.direction = Vector3(0.1, 1.0, 0.0)
    p.spread = 35.0
    p.initial_velocity_min = 0.10
    p.initial_velocity_max = 0.35
    p.gravity = Vector3.ZERO
    p.scale_amount_min = 0.45
    p.scale_amount_max = 1.1
    var ramp := Gradient.new()
    ramp.offsets = PackedFloat32Array([0.0, 0.24, 0.75, 1.0])
    ramp.colors = PackedColorArray([Color(1.0, 0.81, 0.47, 0.0), Color(1.0, 0.81, 0.47, 0.7), Color(1.0, 0.81, 0.47, 0.6), Color(1.0, 0.81, 0.47, 0.0)])
    p.color_ramp = ramp
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(p)

# A low-poly, warm-toned boombox made to match the other island props.
func _build_boombox() -> void:
    boombox = M_BOOMBOX.instantiate()
    boombox.set_meta("outline_boombox", true)
    boombox.position = Vector3(-0.95, 0.0, 0.9)
    boombox.rotation.y = -0.18
    add_child(boombox)
    # Keep one grounding shadow rather than many small shadows on mobile.
    W.set_shadows(boombox, false)
    var cabinet := boombox.find_child("Cabinet", true, false)
    if cabinet is GeometryInstance3D:
        cabinet.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON

# ================================================================ update
func _process(delta: float) -> void:
    daily_refresh_timer += delta
    if daily_refresh_timer >= 15.0:
        daily_refresh_timer = 0.0
        _refresh_daily_button()
    t += delta
    _update_camera(delta)
    _update_capy(delta)
    _update_zombie(delta)
    for i in coins3d.size():
        var c: Node3D = coins3d[i]
        c.rotation.y += delta * 2.2
        c.position.y = 1.45 + sin(t * 1.8 + i * 1.3) * 0.12 + (i % 2) * 0.22
        if i < coin_glows.size():
            var glow: Node3D = coin_glows[i]
            glow.position = c.position
            glow.scale = Vector3.ONE * (0.9 + 0.1 * sin(t * 2.4 + i))
    for e in clouds:
        var cl: Node3D = e[0]
        cl.position.x += float(e[1]) * delta
        if cl.position.x > 62.0:
            cl.position.x = -62.0
    for e in far_islands:
        var fi: Node3D = e[0]
        var base: Vector3 = e[1]
        fi.position.y = base.y + sin(t * 0.5 + float(e[2])) * 0.5
    if ball_hop > 0.0:
        ball_hop = maxf(0.0, ball_hop - delta * 1.5)
        var k := 1.0 - ball_hop
        ball.position.y = BALL_Y + absf(sin(k * PI * 2.0)) * 1.2 * (1.0 - k * 0.6)
        ball.rotation.x -= delta * 9.0 * ball_hop
        if ball_hop == 0.0:
            ball.position.y = BALL_Y
    if ambience:
        var show_ambience := view == "main" and not busy
        if ambience.visible != show_ambience:
            ambience.visible = show_ambience
    if logo_glint and logo_rect.is_visible_in_tree():
        var cycle := fmod(t, 5.0)
        logo_glint.position = Vector2(28.0 + cycle * 51.0, 80.0 - cycle * 8.0)
        logo_glint.modulate.a = 0.60 * sin(minf(cycle / 3.5, 1.0) * PI) if cycle < 3.5 else 0.0
    if logo_rect and logo_rect.is_visible_in_tree():
        logo_rect.rotation = sin(t * 1.3) * 0.022
        logo_rect.scale = Vector2.ONE * (1.0 + sin(t * 2.1) * 0.012)

func _update_camera(delta: float) -> void:
    var v: Array = VIEWS[view]
    var k := 1.0 - exp(-delta * 3.0)
    var sway := Vector3(sin(t * 0.31) * 0.12, sin(t * 0.43) * 0.07, 0.0)
    var tp: Vector3 = v[0]
    var tl: Vector3 = v[1]
    cam_pos = cam_pos.lerp(tp + sway, k)
    cam_look = cam_look.lerp(tl, k)
    var sh := Vector3.ZERO
    if shake > 0.0:
        shake = maxf(0.0, shake - delta * 2.5)
        sh = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * shake * 0.1
    cam.look_at_from_position(cam_pos + sh, cam_look + sh * 0.5, Vector3.UP)

func _update_capy(delta: float) -> void:
    capy.rotation.y = lerp_angle(capy.rotation.y, capy_yaw, 1.0 - exp(-delta * 8.0))
    var look: Vector3 = cam.global_position
    if zombie_state == 1 and view == "main":
        look = zombie.global_position + Vector3(0, 0.9, 0)
    elif busy and chest_node:
        look = chest_node.global_position + Vector3(0, 0.6, 0)
    elif mouse_seen and not dragging:
        look = cam.project_position(get_viewport().get_mouse_position(), 7.0)
    var lp: Vector3 = capy.to_local(look)
    capy.head_yaw = clampf(atan2(-lp.x, -lp.z), -0.85, 0.85)

func _update_zombie(delta: float) -> void:
    zombie_t -= delta
    match zombie_state:
        0:
            if zombie_t <= 0.0:
                if view == "main" and not busy and modal_ov == null:
                    _zombie_peek()
                else:
                    zombie_t = 3.0
        1:
            zombie.move_amount = 0.2
            if zombie_t <= 0.0:
                _zombie_hide(false)
        2:
            if zombie_t <= 0.0:
                zombie.visible = false
                zombie.set_process(false)
                zombie_state = 0
                zombie_t = randf_range(8.0, 14.0)

func _zombie_peek() -> void:
    zombie_state = 1
    zombie_t = 3.4
    zombie.set_process(true)
    zombie.visible = true
    zombie.position = ZOMBIE_HIDE
    var tw := create_tween()
    tw.tween_property(zombie, "position", ZOMBIE_PEEK, 0.75).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    FX.puff(self, Vector3(ZOMBIE_PEEK.x, 0.1, ZOMBIE_PEEK.z), Color(0.62, 0.5, 0.38), 10, 0.5, 1.6)
    Game.sfx(["groan1", "groan2", "groan3"].pick_random(), -9.0, randf_range(0.9, 1.1))
    _later(0.45, func():
        if zombie_state == 1:
            capy.do_hop()
            Game.sfx("jump", -10.0, 1.4))

func _zombie_hide(bonked: bool) -> void:
    zombie_state = 2
    zombie_t = 0.75
    var tw := create_tween()
    if bonked:
        zombie.do_lunge()
        tw.tween_property(zombie, "position", ZOMBIE_HIDE, 0.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    else:
        tw.tween_property(zombie, "position", ZOMBIE_HIDE, 0.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)

# ================================================================ input
func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        var mb := event as InputEventMouseButton
        if mb.button_index != MOUSE_BUTTON_LEFT:
            return
        if mb.pressed:
            mouse_down = true
            dragging = false
            press_pos = mb.position
        elif mouse_down:
            mouse_down = false
            if not dragging:
                _click(mb.position)
            dragging = false
    elif event is InputEventMouseMotion:
        var mm := event as InputEventMouseMotion
        mouse_seen = true
        if mouse_down and view == "skins" and not busy and modal_ov == null:
            if not dragging and mm.position.distance_to(press_pos) > 6.0:
                dragging = true
            if dragging:
                capy_yaw += mm.relative.x * 0.012
    elif event.is_action_pressed("ui_cancel"):
        _on_escape()

func _click(pos: Vector2) -> void:
    if busy or modal_ov != null or confirm_ov != null:
        return
    var o := cam.project_ray_origin(pos)
    var d := cam.project_ray_normal(pos)
    if view == "main" and boombox and _ray_hit(o, d, boombox.global_position + Vector3(0, 0.40, 0), 0.65):
        _open_boombox()
    elif zombie_state == 1 and _ray_hit(o, d, zombie.global_position + Vector3(0, 0.9, 0), 0.75):
        _bonk_zombie()
    elif _ray_hit(o, d, capy.global_position + Vector3(0, 0.62 * CAPY_SCALE, 0), 0.85 * CAPY_SCALE):
        _poke_capy()
    elif view == "main" and _ray_hit(o, d, ball.global_position, 0.5):
        _kick_ball()

func _ray_hit(o: Vector3, d: Vector3, c: Vector3, r: float) -> bool:
    var oc := c - o
    var tca := oc.dot(d)
    if tca < 0.0:
        return false
    return oc.length_squared() - tca * tca <= r * r

func _poke_capy() -> void:
    pokes += 1
    capy.do_hop()
    if pokes % 3 == 0:
        capy.do_spin()
        Game.sfx("whoosh", -6.0, 1.3)
    Game.sfx("jump", -3.0, randf_range(1.05, 1.3))
    FX.sparkle(self, capy.global_position + Vector3(0, 1.9, 0), Color(1.0, 0.85, 0.45), 12, 2.5, 0.35)

func _kick_ball() -> void:
    if ball_hop > 0.0:
        return
    ball_hop = 1.0
    Game.sfx("kick", -3.0)
    FX.puff(self, ball.global_position - Vector3(0, 0.3, 0), Color(0.9, 0.95, 0.85), 6, 0.35, 1.2)
    capy.happy = true
    _later(0.8, func(): capy.happy = false)

func _bonk_zombie() -> void:
    Game.sfx("bump", -1.0)
    Game.sfx("groan2", -8.0, 1.3)
    var p: Vector3 = zombie.global_position + Vector3(0, 1.1, 0)
    FX.burst(self, p, Color("8fd16a"), 14, 4.0, 0.12)
    FX.float_text(self, p + Vector3(0, 0.5, 0), Game.t("bonk"), Color("b6f27a"), 72)
    _zombie_hide(true)
    capy.happy = true
    _later(1.1, func(): capy.happy = false)

func _on_escape() -> void:
    if profile_required: return
    if busy:
        if reveal_ov != null:
            _close_reveal()
        return
    if confirm_ov != null:
        UI.close_modal(confirm_ov)
        confirm_ov = null
        Game.sfx("ui_back")
    elif modal_ov != null:
        _close_modal()
        Game.sfx("ui_back")
    elif view == "skins":
        Game.sfx("ui_back")
        _show_main()
    else:
        _confirm(Game.t("quit_q"), Game.quit_game)

# ================================================================ UI: build
func _full(c: Control) -> void:
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _clear(n: Node) -> void:
    for ch in n.get_children():
        if ch is CanvasItem:
            (ch as CanvasItem).visible = false
        ch.queue_free()

func _build_ui() -> void:
    root = Control.new()
    _full(root)
    layer.add_child(root)
    main_ui = Control.new()
    _full(main_ui)
    root.add_child(main_ui)
    skins_ui = Control.new()
    _full(skins_ui)
    skins_ui.visible = false
    root.add_child(skins_ui)
    _build_main_ui()
    _build_skins_ui()
    _build_top_bar()
    if view == "skins":
        main_ui.visible = false
        skins_ui.visible = true
        menu_btns.visible = false
        _set_tab(tab)

func _build_main_ui() -> void:
    logo_rect = TextureRect.new()
    logo_rect.texture = LOGO
    logo_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    logo_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    logo_rect.position = Vector2(60, 8)
    logo_rect.size = Vector2(320, 248)
    logo_rect.pivot_offset = Vector2(160, 150)
    logo_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    main_ui.add_child(logo_rect)
    logo_glint = UI.tex_rect(MENU_GLINT, Vector2(42, 42))
    logo_glint.size = Vector2(42, 42)
    logo_glint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    logo_rect.add_child(logo_glint)
    var v := VBoxContainer.new()
    v.position = Vector2(36, 268)
    v.add_theme_constant_override("separation", 14)
    v.mouse_filter = Control.MOUSE_FILTER_IGNORE
    main_ui.add_child(v)
    var defs := [
        ["football", Game.t("big_football"), Game.t("fb_sub"), UI.GREEN, _icon("ball")],
        ["zombie", Game.t("zombie_run"), Game.t("zr_sub"), UI.PURPLE, _icon("zombie")],
        ["skins", Game.t("skins_chests"), "", UI.ORANGE, load("res://assets/ui/chests/wood.png")],
    ]
    for i in defs.size():
        var d: Array = defs[i]
        var b := _mode_button(str(d[1]), str(d[2]), d[3], d[4])
        v.add_child(b)
        var id: String = d[0]
        b.pressed.connect(func(): _on_main_button(id))
        UI.pop_in(b, 0.06 + 0.08 * i)
        if id == "skins":
            skins_sub = b.get_meta("sub")
            skins_badge = PanelContainer.new()
            skins_badge.add_theme_stylebox_override("panel", UI.sb(UI.RED, 16, 3, Color("9c2f2c"), Vector4(11, 0, 11, 2)))
            skins_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
            var bl := UI.label("!", 22, Color.WHITE, 4, Color(0, 0, 0, 0.3), UI.FONT_BLACK)
            bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
            skins_badge.add_child(bl)
            b.add_child(skins_badge)
            skins_badge.position = Vector2(412, -12)
            skins_badge.pivot_offset = Vector2(16, 16)
            var bt := skins_badge.create_tween().set_loops()
            bt.tween_property(skins_badge, "scale", Vector2(1.18, 1.18), 0.45).set_trans(Tween.TRANS_SINE)
            bt.tween_property(skins_badge, "scale", Vector2.ONE, 0.45).set_trans(Tween.TRANS_SINE)
            _pause_tween_when_hidden(skins_badge, bt)
    # quit button (bottom-left)
    var ex := UI.icon_button(_icon("exit"), Color("c95b5b"), 58, Game.t("quit_q"))
    main_ui.add_child(ex)
    ex.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    ex.offset_left = 24
    ex.offset_right = 24 + 58
    ex.offset_top = -24 - 64
    ex.offset_bottom = -24
    ex.grow_vertical = Control.GROW_DIRECTION_BEGIN
    ex.pressed.connect(func(): _confirm(Game.t("quit_q"), Game.quit_game))
    # A compact entry to goals, separate from the main mode buttons.
    Game.ensure_daily()
    daily_button = UI.button(Game.t("daily_button") % Game.daily_completed_count(), UI.BLUE, Vector2(264, 58), 21)
    main_ui.add_child(daily_button)
    daily_button.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    daily_button.offset_left = 100
    daily_button.offset_right = 364
    daily_button.offset_top = -82
    daily_button.offset_bottom = -24
    daily_button.grow_vertical = Control.GROW_DIRECTION_BEGIN
    daily_button.pressed.connect(_open_daily)
    # One rotating hint keeps the original corner uncluttered.
    hint_box = UI.flat_panel(Color(0.16, 0.18, 0.33, 0.72), 20, 10)
    hint_box.name = "RotatingHint"
    hint_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var hh := HBoxContainer.new()
    hh.add_theme_constant_override("separation", 8)
    hint_box.add_child(hh)
    var hint_icon := UI.tex_rect(_icon("capy"), Vector2(34, 34))
    hh.add_child(hint_icon)
    var hl := UI.label(Game.t("box_hint_short"), 21, Color.WHITE, 0)
    hl.name = "HintText"
    hl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hh.add_child(hl)
    hint_icon.visible = false
    main_ui.add_child(hint_box)
    hint_box.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
    hint_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    hint_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
    var hint_timer := Timer.new()
    hint_timer.wait_time = 4.5
    hint_timer.autostart = true
    hint_box.add_child(hint_timer)
    var hint_state := {"capy": false}
    hint_timer.timeout.connect(func():
        if not is_instance_valid(hint_box): return
        var tw := hint_box.create_tween()
        tw.tween_property(hint_box, "modulate:a", 0.0, 0.18)
        tw.tween_callback(func():
            hint_state.capy = not hint_state.capy
            hint_icon.visible = hint_state.capy
            hl.text = Game.t("click_capy" if hint_state.capy else "box_hint_short"))
        tw.tween_property(hint_box, "modulate:a", 1.0, 0.22))
    _refresh_main()

## Big chunky menu button: icon, title, subtitle and a play arrow.
func _mode_button(title: String, sub: String, color: Color, icon: Texture2D) -> Button:
    var b := Button.new()
    b.custom_minimum_size = Vector2(440, 92)
    UI.style_button(b, color, 24, 8, 30)
    # Gentle depth and a glossy top highlight; text and touch targets are unchanged.
    for style_name in ["normal", "hover"]:
        var bs: StyleBoxFlat = b.get_theme_stylebox(style_name)
        bs.shadow_color = Color(0.03, 0.07, 0.08, 0.28)
        bs.shadow_size = 6
        bs.shadow_offset = Vector2(0, 3)
    var gloss := TextureRect.new()
    gloss.texture = MENU_GLOSS
    gloss.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    gloss.stretch_mode = TextureRect.STRETCH_SCALE
    gloss.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    gloss.offset_bottom = -8
    gloss.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(gloss)
    var hb := HBoxContainer.new()
    hb.set_anchors_preset(Control.PRESET_FULL_RECT)
    hb.offset_left = 14
    hb.offset_right = -16
    hb.offset_bottom = -8
    hb.add_theme_constant_override("separation", 14)
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(hb)
    var ib := PanelContainer.new()
    ib.add_theme_stylebox_override("panel", UI.sb(color.darkened(0.2), 18, 0, Color(0, 0, 0, 0), Vector4(6, 6, 6, 6)))
    ib.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ib.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    ib.add_child(UI.tex_rect(icon, Vector2(56, 56)))
    hb.add_child(ib)
    var vb := VBoxContainer.new()
    vb.alignment = BoxContainer.ALIGNMENT_CENTER
    vb.add_theme_constant_override("separation", -2)
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(vb)
    var tsz := UI.fit_size(title, UI.FONT_BLACK, 30, 272.0, 20)
    vb.add_child(UI.label(title, tsz, Color.WHITE, 8, color.darkened(0.5), UI.FONT_BLACK))
    var s := UI.label(sub, 17, Color(1, 1, 1, 0.9), 4, color.darkened(0.45))
    vb.add_child(s)
    b.set_meta("sub", s)
    var arrow := UI.tex_rect(_icon("play"), Vector2(28, 28))
    arrow.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    arrow.modulate = Color(1, 1, 1, 0.85)
    hb.add_child(arrow)
    arrow.pivot_offset = Vector2(14, 14)
    var arrow_tw := arrow.create_tween().set_loops()
    arrow_tw.tween_property(arrow, "scale", Vector2(1.08, 1.08), 0.85).set_trans(Tween.TRANS_SINE)
    arrow_tw.tween_property(arrow, "scale", Vector2.ONE, 0.85).set_trans(Tween.TRANS_SINE)
    _pause_tween_when_hidden(arrow, arrow_tw)
    b.button_down.connect(func(): UI.press_shift(hb, 6.0, -2.0))
    b.button_up.connect(func(): UI.press_shift(hb, 0.0, -8.0))
    UI.juicy(b, 1.04)
    return b

func _build_top_bar() -> void:
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    hb.alignment = BoxContainer.ALIGNMENT_END
    hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hb)
    var pill := UI.pill(COIN_TEX, str(Game.coins()), Color(0.16, 0.18, 0.33, 0.78), 28)
    coin_pill = pill[0]
    coin_label = pill[1]
    coin_label.custom_minimum_size = Vector2(66, 0)
    coin_pill.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    coin_pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(coin_pill)
    menu_btns = HBoxContainer.new()
    menu_btns.add_theme_constant_override("separation", 12)
    menu_btns.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hb.add_child(menu_btns)
    var st := UI.icon_button(_icon("stats"), UI.BLUE, 60, Game.t("stats"))
    st.pressed.connect(_open_stats)
    menu_btns.add_child(st)
    var se := UI.icon_button(_icon("settings"), UI.SLATE, 60, Game.t("settings"))
    se.pressed.connect(_open_settings)
    menu_btns.add_child(se)
    hb.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 20)
    hb.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    _update_coin_label()

func _refresh_main() -> void:
    _refresh_daily_button()
    if is_instance_valid(skins_sub):
        skins_sub.text = Game.t("collection") % [Game.data.owned.size(), Game.SKINS.size()]
    if is_instance_valid(skins_badge):
        skins_badge.visible = _has_news()

func _refresh_daily_button() -> void:
    if is_instance_valid(daily_button):
        daily_button.text = Game.t("daily_button") % Game.daily_completed_count()

func _has_news() -> bool:
    for id in Game.data.owned:
        if not Game.data.seen.has(id):
            return true
    var cheapest := 1000000
    for c in Game.CHESTS:
        cheapest = mini(cheapest, int(c.price))
    return Game.coins() >= cheapest

func _on_main_button(id: String) -> void:
    if busy or Game.is_busy():
        return
    if id == "skins":
        _show_skins("skins")
    else:
        _open_mode(id)

# Decorative loops stop only when their control (or an ancestor) is hidden.
# The current pose is kept so the same animation resumes when visible again.
func _pause_tween_when_hidden(target: CanvasItem, tween: Tween) -> void:
    target.set_meta("decorative_tween", tween)
    var sync := func():
        if tween.is_valid():
            if target.is_visible_in_tree(): tween.play()
            else: tween.pause()
    target.visibility_changed.connect(sync)
    target.tree_entered.connect(sync)
    sync.call()

func _fade(c: Control, on: bool, dur := 0.25) -> void:
    if c.has_meta("fade_tw"):
        var old = c.get_meta("fade_tw")
        if old is Tween and (old as Tween).is_valid():
            (old as Tween).kill()
    if on:
        if not c.visible:
            c.modulate.a = 0.0
        c.visible = true
    var tw := c.create_tween()
    tw.tween_property(c, "modulate:a", 1.0 if on else 0.0, dur)
    if not on:
        tw.tween_callback(c.hide)
    c.set_meta("fade_tw", tw)

# ================================================================ coins / toasts
func _update_coin_label() -> void:
    if is_instance_valid(coin_label):
        coin_label.text = str(int(round(shown_coins)))

func _set_shown_coins(v: float) -> void:
    shown_coins = v
    _update_coin_label()

func _refresh_coins() -> void:
    var target := float(Game.coins())
    if coin_tween and coin_tween.is_valid():
        coin_tween.kill()
    coin_tween = create_tween()
    coin_tween.tween_method(_set_shown_coins, shown_coins, target, 0.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    if is_instance_valid(coin_pill):
        coin_pill.pivot_offset = coin_pill.size * 0.5
        var tw := coin_pill.create_tween()
        tw.tween_property(coin_pill, "scale", Vector2(1.15, 1.15), 0.1)
        tw.tween_property(coin_pill, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    _refresh_main()

func _toast(text: String, color := UI.RED, icon := "") -> void:
    var p := PanelContainer.new()
    p.add_theme_stylebox_override("panel", UI.sb(color, 22, 5, color.darkened(0.35), Vector4(22, 10, 22, 10)))
    p.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    p.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 8)
    p.add_child(hb)
    if icon != "":
        hb.add_child(UI.tex_rect(_icon(icon), Vector2(34, 34)))
    var l := UI.label(text, 26, Color.WHITE, 6, color.darkened(0.5), UI.FONT_BLACK)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hb.add_child(l)
    toast_box.add_child(p)
    UI.pop_in(p)
    var tw := p.create_tween()
    tw.tween_interval(1.7)
    tw.tween_property(p, "modulate:a", 0.0, 0.3)
    tw.tween_callback(p.queue_free)

func _shake_control(c: Control) -> void:
    var tw := c.create_tween()
    for i in 4:
        tw.tween_property(c, "rotation", 0.07 * (1.0 if i % 2 == 0 else -1.0), 0.05)
    tw.tween_property(c, "rotation", 0.0, 0.05)

# ================================================================ modals
func _modal_panel(width: float, title := "") -> VBoxContainer:
    var m := UI.modal(root, 0.45)
    var ov: Control = m[0]
    modal_ov = ov
    var p := UI.panel(UI.NAVY, 30, 26)
    p.custom_minimum_size = Vector2(width, 0)
    (m[1] as Control).add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    p.add_child(v)
    if title != "":
        v.add_child(UI.title(title, 46))
    UI.pop_in(p)
    Game.sfx("whoosh", -12.0, 1.4)
    ov.gui_input.connect(func(e: InputEvent):
        if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT and modal_ov == ov:
            Game.sfx("ui_back")
            _close_modal())
    return v

func _close_modal() -> void:
    if modal_ov != null:
        UI.close_modal(modal_ov)
        modal_ov = null

func _confirm(text: String, on_yes: Callable, yes_color := UI.RED) -> void:
    if confirm_ov != null:
        return
    var m := UI.modal(root, 0.45)
    var ov: Control = m[0]
    confirm_ov = ov
    var p := UI.panel(UI.NAVY, 28, 26)
    p.custom_minimum_size = Vector2(470, 0)
    (m[1] as Control).add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 20)
    p.add_child(v)
    var l := UI.label(text, 28, Color.WHITE, 6, Color(0, 0, 0, 0.3), UI.FONT_BLACK)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size = Vector2(410, 0)
    v.add_child(l)
    var hb := HBoxContainer.new()
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_theme_constant_override("separation", 16)
    v.add_child(hb)
    var no := UI.button(Game.t("no"), UI.SLATE, Vector2(170, 64), 26, "ui_back")
    var yes := UI.button(Game.t("yes"), yes_color, Vector2(170, 64), 26)
    hb.add_child(no)
    hb.add_child(yes)
    no.pressed.connect(func():
        UI.close_modal(ov)
        confirm_ov = null)
    yes.pressed.connect(func():
        UI.close_modal(ov)
        confirm_ov = null
        on_yes.call())
    UI.pop_in(p)

func _key_chip(key: String, action: String) -> Control:
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 6)
    var kp := PanelContainer.new()
    kp.add_theme_stylebox_override("panel", UI.sb(Color("f4f1ea"), 10, 4, Color("aaa5c2"), Vector4(10, 3, 10, 3)))
    kp.add_child(UI.label(key, 18, Color("363a63"), 0, Color(0, 0, 0, 0), UI.FONT_BLACK))
    hb.add_child(kp)
    var al := UI.label(action, 18, Color(1, 1, 1, 0.9), 0)
    al.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hb.add_child(al)
    return hb

func _open_mode(mode: String) -> void:
    if modal_ov != null or busy:
        return
    var fb := mode == "football"
    var col: Color = UI.GREEN if fb else UI.PURPLE
    var v := _modal_panel(680)
    var hh := HBoxContainer.new()
    hh.alignment = BoxContainer.ALIGNMENT_CENTER
    hh.add_theme_constant_override("separation", 14)
    v.add_child(hh)
    var ib := UI.flat_panel(col, 18, 8)
    ib.add_child(UI.tex_rect(_icon("ball" if fb else "zombie"), Vector2(56, 56)))
    hh.add_child(ib)
    hh.add_child(UI.title(Game.t("big_football" if fb else "zombie_run"), 46, Color.WHITE, col.darkened(0.5)))
    var d := UI.label(Game.t("fb_desc" if fb else "zr_desc"), 21, Color(1, 1, 1, 0.92), 0)
    d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    d.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    d.custom_minimum_size = Vector2(620, 0)
    v.add_child(d)
    var ready := UI.label(Game.t("match_vibe" if fb else "run_vibe"), 17, Color("ffe8af"))
    ready.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(ready)
    var box := UI.flat_panel(Color(0, 0, 0, 0.2), 18, 14)
    v.add_child(box)
    var bv := VBoxContainer.new()
    bv.add_theme_constant_override("separation", 10)
    box.add_child(bv)
    var rw := HBoxContainer.new()
    rw.add_theme_constant_override("separation", 8)
    bv.add_child(rw)
    rw.add_child(UI.tex_rect(COIN_TEX, Vector2(28, 28)))
    var rl := UI.label(Game.t("fb_rewards" if fb else "zr_rewards"), 19, Color.WHITE, 0)
    rl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    rl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    rw.add_child(rl)
    var st: Dictionary = Game.data.stats
    var rec := ""
    if fb:
        rec = "%s: %d" % [Game.t("st_wins"), int(st.fb_wins)]
    else:
        rec = "%s: %s" % [Game.t("best"), Game.t("dist") % int(st.zr_best)]
    rw.add_child(UI.tex_rect(_icon("trophy"), Vector2(26, 26)))
    var rcl := UI.label(rec, 19, Color("ffd84a"), 0)
    rcl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    rw.add_child(rcl)
    var dh := HBoxContainer.new()
    dh.alignment = BoxContainer.ALIGNMENT_CENTER
    dh.add_theme_constant_override("separation", 14)
    v.add_child(dh)
    var dl := UI.label(Game.t("difficulty"), 22, Color.WHITE, 0)
    dl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    dh.add_child(dl)
    dh.add_child(UI.toggle_group([Game.t("diff0"), Game.t("diff1"), Game.t("diff2")], Game.difficulty(), col.darkened(0.05), _set_difficulty, Vector2(140, 52)))
    var bh := HBoxContainer.new()
    bh.alignment = BoxContainer.ALIGNMENT_CENTER
    bh.add_theme_constant_override("separation", 16)
    v.add_child(bh)
    var back := UI.button(Game.t("back"), UI.SLATE, Vector2(180, 80), 26, "ui_back")
    back.pressed.connect(_close_modal)
    bh.add_child(back)
    var play := UI.big_button(Game.t("play"), col, _icon("play"), Vector2(300, 84), 34)
    play.pressed.connect(func(): _start_mode(mode))
    bh.add_child(play)

func _set_difficulty(i: int) -> void:
    Game.data.settings.difficulty = i
    Game.save_game()

func _start_mode(mode: String) -> void:
    if Game.is_busy():
        return
    Game.sfx("go", -4.0)
    Game.goto(Game.SCENE_FOOTBALL if mode == "football" else Game.SCENE_ZOMBIE)

# ---------------------------------------------------------------- boombox
func _open_boombox() -> void:
    if modal_ov != null or busy or view != "main": return
    var v := _modal_panel(680, Game.t("boombox"))
    var unlocked := bool(Game.data.boombox_unlocked)
    if not unlocked:
        var locked := UI.label(Game.t("box_locked_next" if int(Game.data.daily.stars) >= 5 else "box_locked"), 21, Color.WHITE)
        locked.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        locked.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        v.add_child(locked)
    else:
        var choice := str(Game.data.music_choice)
        var current := UI.label(Game.t("track_current") % Game.t("track_" + choice), 20, Color("ffe8af"))
        current.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        v.add_child(current)
        var row := HBoxContainer.new()
        row.alignment = BoxContainer.ALIGNMENT_CENTER
        row.add_theme_constant_override("separation", 10)
        v.add_child(row)
        for key in ["menu", "football", "zombie"]:
            var button := UI.button(Game.t("track_" + key), UI.GREEN if choice == key else UI.SLATE, Vector2(185, 55), 18)
            button.pressed.connect(func(): _pick_music(key))
            row.add_child(button)
        var extra := HBoxContainer.new()
        extra.alignment = BoxContainer.ALIGNMENT_CENTER
        extra.add_theme_constant_override("separation", 10)
        v.add_child(extra)
        var choose := UI.button(Game.t("boombox_replace") if str(Game.data.boombox_format) != "" else Game.t("boombox_choose"), UI.BLUE, Vector2(200, 55), 17)
        choose.pressed.connect(_choose_boombox_track)
        extra.add_child(choose)
        if str(Game.data.boombox_format) != "" and FileAccess.file_exists(Game.BOOMBOX_TRACK):
            var custom := UI.button(Game.t("track_custom"), UI.GREEN if choice == "custom" else UI.SLATE, Vector2(160, 55), 17)
            custom.pressed.connect(func(): _pick_music("custom"))
            extra.add_child(custom)
        var off := UI.button(Game.t("track_off"), UI.GREEN if choice == "off" else UI.SLATE, Vector2(140, 55), 17)
        off.pressed.connect(func(): _pick_music("off"))
        extra.add_child(off)
    var close := UI.button(Game.t("close"), UI.SLATE, Vector2(200, 56), 20, "ui_back")
    close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    close.pressed.connect(_close_modal)
    v.add_child(close)

func _pick_music(choice: String) -> void:
    Game.select_menu_music(choice)
    _close_modal()
    _open_boombox()

func _choose_boombox_track() -> void:
    var dialog := FileDialog.new()
    dialog.access = FileDialog.ACCESS_FILESYSTEM
    dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
    dialog.use_native_dialog = true
    dialog.add_filter("*.mp3,*.ogg,*.wav", "MP3, OGG, WAV", "audio/mpeg,audio/ogg,audio/wav,audio/x-wav")
    dialog.file_selected.connect(func(path: String):
        if Game.import_boombox_track(path):
            _toast(Game.t("boombox_saved"), UI.GREEN)
            _close_modal()
            _open_boombox()
        else:
            _toast(Game.t("boombox_invalid"), UI.RED)
        dialog.queue_free())
    dialog.canceled.connect(func(): dialog.queue_free())
    add_child(dialog)
    dialog.popup_centered_ratio(0.85)

# ---------------------------------------------------------------- player profile
func _open_profile(required := false) -> void:
    if modal_ov != null or busy: return
    profile_required = required
    var m := UI.modal(root, 0.45)
    modal_ov = m[0]
    var p := UI.panel(UI.NAVY, 30, 26)
    p.custom_minimum_size = Vector2(650, 0)
    (m[1] as Control).add_child(p)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    p.add_child(v)
    v.add_child(UI.title(Game.t("profile_first" if required else "profile"), 38))
    var identity := UI.label(Game.t("profile_identity"), 18, Color.WHITE)
    identity.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    identity.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    v.add_child(identity)
    var rules := UI.label(Game.t("profile_rules"), 18, Color("d2e5f2"))
    rules.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    rules.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    v.add_child(rules)
    var entry := LineEdit.new()
    entry.name = "NicknameInput"
    entry.max_length = 16
    entry.placeholder_text = Game.t("profile")
    entry.text = str(Game.data.nickname)
    entry.custom_minimum_size = Vector2(0, 58)
    entry.add_theme_font_override("font", UI.FONT)
    entry.add_theme_font_size_override("font_size", 24)
    entry.add_theme_stylebox_override("normal", UI.sb(Color("273f54"), 14, 2))
    entry.add_theme_stylebox_override("focus", UI.sb(Color("273f54"), 14, 2))
    v.add_child(entry)
    var selected := {"color": str(Game.data.nickname_color)}
    var preview := UI.label(entry.text if entry.text != "" else "Capy", 25, Game.player_nick_color(), 2, Color.BLACK)
    preview.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(preview)
    if int(Game.data.daily.stars) >= 5:
        var colors := HBoxContainer.new()
        colors.alignment = BoxContainer.ALIGNMENT_CENTER
        colors.add_theme_constant_override("separation", 6)
        v.add_child(colors)
        for key in ["white", "blue", "green", "pink", "gold"]:
            var color_button := UI.button(Game.t("color_" + key), UI.SLATE, Vector2(108, 46), 13)
            color_button.add_theme_color_override("font_color", Game.NICK_COLORS[key])
            color_button.add_theme_color_override("font_hover_color", Game.NICK_COLORS[key])
            color_button.pressed.connect(func():
                selected.color = key
                preview.label_settings.font_color = Game.NICK_COLORS[key])
            colors.add_child(color_button)
    else:
        var locked := UI.label(Game.t("profile_color_locked"), 16, Color("ffe8af"))
        locked.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        v.add_child(locked)
    var buttons := HBoxContainer.new()
    buttons.alignment = BoxContainer.ALIGNMENT_CENTER
    buttons.add_theme_constant_override("separation", 12)
    v.add_child(buttons)
    if not required:
        var cancel := UI.button(Game.t("back"), UI.SLATE, Vector2(180, 56), 20, "ui_back")
        cancel.pressed.connect(_close_modal)
        buttons.add_child(cancel)
    var save := UI.button(Game.t("profile_save"), UI.GREEN, Vector2(220, 56), 20)
    save.name = "SaveNickname"
    save.disabled = not Game.valid_nickname(entry.text)
    buttons.add_child(save)
    entry.text_changed.connect(func(value: String):
        preview.text = value if value != "" else "Capy"
        save.disabled = not Game.valid_nickname(value))
    save.pressed.connect(func():
        if not Game.valid_nickname(entry.text): return
        Game.data.nickname = entry.text
        if int(Game.data.daily.stars) >= 5: Game.data.nickname_color = selected.color
        Game.save_game()
        profile_required = false
        _close_modal())
    entry.text_submitted.connect(func(_value: String):
        if not save.disabled: save.pressed.emit())
    UI.pop_in(p)

# ---------------------------------------------------------------- settings
func _open_settings() -> void:
    if modal_ov != null or busy:
        return
    var v := _modal_panel(700, Game.t("settings"))
    var g := GridContainer.new()
    g.columns = 2
    g.add_theme_constant_override("h_separation", 26)
    g.add_theme_constant_override("v_separation", 10)
    v.add_child(g)
    var profile := UI.button(Game.t("profile_button"), UI.BLUE, Vector2(260, 48), 18)
    profile.pressed.connect(func():
        _close_modal()
        _open_profile(false))
    _setting_row(g, Game.t("profile"), profile)
    _setting_row(g, Game.t("music"), _slider("music"))
    _setting_row(g, Game.t("sounds"), _slider("sfx"))
    var background_music := UI.button(Game.t("boombox"), UI.SLATE, Vector2(260, 52), 18)
    background_music.pressed.connect(func():
        _close_modal()
        _open_boombox())
    _setting_row(g, Game.t("background_music"), background_music)
    _setting_row(g, Game.t("language"), UI.toggle_group(["English", "Русский"], 1 if Game.lang == "ru" else 0, UI.BLUE, _on_lang, Vector2(150, 52)))
    _setting_row(g, Game.t("difficulty"), UI.toggle_group([Game.t("diff0"), Game.t("diff1"), Game.t("diff2")], Game.difficulty(), UI.ORANGE, _set_difficulty, Vector2(134, 52)))
    _setting_row(g, Game.t("fullscreen"), UI.toggle_group([Game.t("off"), Game.t("on")], 1 if bool(Game.data.settings.fullscreen) else 0, UI.GREEN, _on_fullscreen, Vector2(134, 52)))
    v.add_child(UI.spacer(4))
    var bh := HBoxContainer.new()
    bh.alignment = BoxContainer.ALIGNMENT_CENTER
    bh.add_theme_constant_override("separation", 16)
    v.add_child(bh)
    var rb := UI.button(Game.t("reset"), Color("b5524e"), Vector2(300, 62), 20)
    rb.pressed.connect(func(): _confirm(Game.t("reset_q"), _do_reset))
    bh.add_child(rb)
    var cb := UI.button(Game.t("close"), UI.GREEN, Vector2(210, 62), 24, "ui_back")
    cb.pressed.connect(_close_modal)
    bh.add_child(cb)
    var channel := LinkButton.new()
    channel.name = "TelegramChannel"
    channel.text = Game.t("telegram_channel")
    channel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    channel.add_theme_font_override("font", UI.FONT)
    channel.add_theme_font_size_override("font_size", 16)
    channel.add_theme_color_override("font_color", Color("c3d9e7"))
    channel.add_theme_color_override("font_hover_color", Color.WHITE)
    channel.pressed.connect(func(): OS.shell_open("https://t.me/splanetcom"))
    v.add_child(channel)

func _setting_row(g: GridContainer, text: String, ctrl: Control) -> void:
    var l := UI.label(text, 24, Color.WHITE, 6, Color(0, 0, 0, 0.3), UI.FONT_BLACK)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.size_flags_vertical = Control.SIZE_FILL
    g.add_child(l)
    g.add_child(ctrl)

func _slider(key: String) -> HSlider:
    var s := HSlider.new()
    s.min_value = 0.0
    s.max_value = 1.0
    s.step = 0.05
    s.value = float(Game.data.settings[key])
    s.custom_minimum_size = Vector2(380, 36)
    s.focus_mode = Control.FOCUS_NONE
    s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    s.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
    s.value_changed.connect(func(val: float):
        Game.data.settings[key] = val
        Game.apply_settings())
    s.drag_ended.connect(func(_changed: bool):
        Game.save_game()
        if key == "sfx":
            Game.sfx("coin"))
    return s

func _on_lang(i: int) -> void:
    var l := "ru" if i == 1 else "en"
    if l == Game.lang:
        return
    Game.set_lang(l)
    _rebuild_ui.call_deferred("settings")

func _rebuild_ui(reopen := "") -> void:
    modal_ov = null
    confirm_ov = null
    if is_instance_valid(root):
        root.hide()
        root.queue_free()
    _build_ui()
    if reopen == "settings":
        _open_settings()

func _on_fullscreen(i: int) -> void:
    Game.data.settings.fullscreen = i == 1
    Game.apply_settings()
    Game.save_game()

func _do_reset() -> void:
    Game.reset_progress()
    sel_skin = Game.equipped()
    _apply_menu_skin(Game.equipped())
    capy.flash()
    _refresh_coins()
    _refresh_daily_button()
    _toast(Game.t("reset_done"), UI.BLUE)

# ---------------------------------------------------------------- daily goals
func _open_daily() -> void:
    if modal_ov != null or busy:
        return
    Game.ensure_daily()
    _refresh_daily_button()
    var v := _modal_panel(720, Game.t("daily_title"))
    v.add_theme_constant_override("separation", 9)
    var icons := ["ball", "zombie", "trophy"]
    var tasks: Array = Game.daily_goals()
    for i in tasks.size():
        var goal: Dictionary = tasks[i]
        var current := mini(int(Game.data.daily.get(goal.key, 0)), int(goal.target))
        var done := current >= int(goal.target)
        var card := UI.flat_panel(Color("31495e"), 16, 9)
        v.add_child(card)
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 12)
        card.add_child(row)
        var icon := UI.tex_rect(_icon(icons[i]), Vector2(36, 36))
        icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        row.add_child(icon)
        var details := VBoxContainer.new()
        details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        details.add_theme_constant_override("separation", 4)
        row.add_child(details)
        details.add_child(UI.label(Game.t(goal.title), 21, Color.WHITE, 3, Color.BLACK, UI.FONT_BLACK))
        var bar := UI.bar(0, 11, UI.GREEN if done else UI.BLUE)
        bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        bar.value = float(current) / float(goal.target)
        details.add_child(bar)
        var meta := VBoxContainer.new()
        meta.custom_minimum_size = Vector2(190, 0)
        meta.alignment = BoxContainer.ALIGNMENT_CENTER
        row.add_child(meta)
        var count := UI.label(Game.t("daily_done") if done else "%d / %d" % [current, goal.target], 19, Color("a5edba") if done else Color.WHITE, 2, Color.BLACK, UI.FONT_BLACK)
        count.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
        meta.add_child(count)
        var award := UI.label(Game.t("daily_award") % int(goal.reward), 15, Color("ffe5a1"), 2, Color.BLACK)
        award.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
        meta.add_child(award)
    var milestone: Array = Game.daily_next_milestone()
    var stars := int(Game.data.daily.stars)
    var journey := UI.flat_panel(Color("273f54"), 16, 10)
    v.add_child(journey)
    var jv := VBoxContainer.new()
    jv.add_theme_constant_override("separation", 4)
    journey.add_child(jv)
    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 10)
    jv.add_child(head)
    var trophy := UI.tex_rect(_icon("trophy"), Vector2(32, 32))
    head.add_child(trophy)
    var path_label := UI.label(Game.t("daily_stars") % [stars, int(milestone[0])], 21, Color("ffdd73"), 2, Color.BLACK, UI.FONT_BLACK)
    path_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    path_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    head.add_child(path_label)
    var path_bar := UI.bar(0, 12, UI.GOLD)
    path_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    path_bar.value = minf(1.0, float(stars) / float(milestone[0]))
    jv.add_child(path_bar)
    jv.add_child(UI.label(Game.journey_reward_text(milestone), 17, Color("ffe8af"), 2, Color.BLACK))
    var collection := UI.label(Game.t("daily_collection") % [Game.data.owned.size(), Game.SKINS.size()], 18, Color.WHITE, 2, Color.BLACK)
    collection.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(collection)
    var note := UI.label(Game.t("daily_note"), 15, Color("d2e5f2"), 0)
    note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(note)
    var close := UI.button(Game.t("close"), UI.GREEN, Vector2(230, 48), 23)
    close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    close.pressed.connect(_close_modal)
    v.add_child(close)

# ---------------------------------------------------------------- stats
func _open_stats() -> void:
    if modal_ov != null or busy:
        return
    var v := _modal_panel(980, Game.t("stats"))
    var st: Dictionary = Game.data.stats
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 14)
    v.add_child(hb)
    var bt := float(st.zr_best_time)
    hb.add_child(_stat_card(Game.t("st_football"), "ball", UI.GREEN, [
        [Game.t("st_played"), str(st.fb_played)],
        [Game.t("st_wins"), str(st.fb_wins)],
        [Game.t("st_draws"), str(st.fb_draws)],
        [Game.t("st_losses"), str(st.fb_losses)],
        [Game.t("st_goals"), str(st.fb_goals)],
    ]))
    hb.add_child(_stat_card(Game.t("st_zombie"), "zombie", UI.PURPLE, [
        [Game.t("st_runs"), str(st.zr_played)],
        [Game.t("st_escapes"), str(st.zr_escapes)],
        [Game.t("st_best"), Game.t("dist") % int(st.zr_best)],
        [Game.t("st_best_time"), UI.fmt_time(bt) if bt > 0.0 else "-"],
        [Game.t("st_saved"), str(st.zr_saved)],
    ]))
    hb.add_child(_stat_card(Game.t("st_other"), "trophy", UI.ORANGE, [
        [Game.t("st_skins"), "%d/%d" % [Game.data.owned.size(), Game.SKINS.size()]],
        [Game.t("st_chests"), str(st.chests)],
        [Game.t("st_coins"), str(st.coins_earned)],
    ]))
    var cb := UI.button(Game.t("close"), UI.GREEN, Vector2(220, 62), 24, "ui_back")
    cb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    cb.pressed.connect(_close_modal)
    v.add_child(cb)

func _stat_card(title: String, icon: String, col: Color, rows: Array) -> Control:
    var p := UI.flat_panel(Color(0, 0, 0, 0.22), 20, 14)
    p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 9)
    p.add_child(v)
    var hh := HBoxContainer.new()
    hh.add_theme_constant_override("separation", 10)
    v.add_child(hh)
    var ib := UI.flat_panel(col, 12, 5)
    ib.add_child(UI.tex_rect(_icon(icon), Vector2(34, 34)))
    hh.add_child(ib)
    var tl := UI.label(title, 22, Color.WHITE, 6, col.darkened(0.5), UI.FONT_BLACK)
    tl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hh.add_child(tl)
    for r in rows:
        var row := HBoxContainer.new()
        var a := UI.label(str(r[0]), 17, Color(1, 1, 1, 0.8), 0)
        a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        a.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        row.add_child(a)
        row.add_child(UI.label(str(r[1]), 21, Color.WHITE, 5, Color(0, 0, 0, 0.3), UI.FONT_BLACK))
        v.add_child(row)
    return p

# ================================================================ skins & chests screen
func _build_skins_ui() -> void:
    var top := HBoxContainer.new()
    top.position = Vector2(28, 18)
    top.add_theme_constant_override("separation", 12)
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    skins_ui.add_child(top)
    var back := UI.button(Game.t("back"), UI.SLATE, Vector2(150, 62), 24, "ui_back")
    back.pressed.connect(_show_main)
    top.add_child(back)
    top.add_child(UI.spacer(0, 10))
    tab_btns = {}
    for id in ["skins", "chests"]:
        var tb := Button.new()
        tb.text = Game.t(id)
        tb.custom_minimum_size = Vector2(196, 62)
        UI.style_button(tb, Color("5d5f8a"), 18, 6, 24)
        UI.juicy(tb, 1.05)
        var tid: String = id
        tb.pressed.connect(func(): _set_tab(tid))
        top.add_child(tb)
        tab_btns[id] = tb
    var p := UI.panel(Color(0.17, 0.19, 0.37, 0.88), 28, 18)
    p.position = Vector2(28, 98)
    p.custom_minimum_size = Vector2(716, 0)
    skins_ui.add_child(p)
    content = VBoxContainer.new()
    content.add_theme_constant_override("separation", 12)
    p.add_child(content)
    var rh := UI.flat_panel(Color(0.16, 0.18, 0.33, 0.6), 18, 8)
    rh.mouse_filter = Control.MOUSE_FILTER_IGNORE
    rh.add_child(UI.label(Game.t("drag_rotate"), 19, Color(1, 1, 1, 0.9), 0))
    skins_ui.add_child(rh)
    rh.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 24)
    rh.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    rh.grow_vertical = Control.GROW_DIRECTION_BEGIN

func _show_skins(tab_id := "skins") -> void:
    if busy:
        return
    view = "skins"
    _fade(main_ui, false, 0.18)
    _fade(skins_ui, true)
    menu_btns.visible = false
    sel_skin = Game.equipped()
    capy_yaw = CAPY_YAW
    _set_tab(tab_id)
    Game.sfx("whoosh", -6.0)

func _show_main() -> void:
    if busy:
        return
    view = "main"
    _fade(skins_ui, false, 0.18)
    _fade(main_ui, true)
    menu_btns.visible = true
    capy_yaw = CAPY_YAW
    if capy.skin_id != Game.equipped():
        _apply_menu_skin(Game.equipped())
        capy.flash()
    _refresh_main()

func _set_tab(id: String) -> void:
    tab = id
    for k in tab_btns:
        var b: Button = tab_btns[k]
        UI.style_button(b, UI.ORANGE if k == id else Color("5d5f8a"), 18, 6, 24)
    _clear(content)
    cards = {}
    if id == "skins":
        _build_skins_tab()
    else:
        _build_chests_tab()

# ---------------------------------------------------------------- skins tab
func _build_skins_tab() -> void:
    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 12)
    content.add_child(head)
    var cl := UI.label(Game.t("collection") % [Game.data.owned.size(), Game.SKINS.size()], 24, Color.WHITE, 6, Color(0, 0, 0, 0.3), UI.FONT_BLACK)
    cl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head.add_child(cl)
    for r in Game.RARITIES:
        var rc: Color = Game.RARITY_COLORS[r]
        var dot := PanelContainer.new()
        dot.add_theme_stylebox_override("panel", UI.sb(rc, 7, 0, Color(0, 0, 0, 0), Vector4(7, 7, 7, 7)))
        dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        head.add_child(dot)
        var rl := UI.label(Game.t(r), 15, rc.lightened(0.35), 0)
        rl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        head.add_child(rl)
    var sc := ScrollContainer.new()
    sc.custom_minimum_size = Vector2(680, 416)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    content.add_child(sc)
    var g := GridContainer.new()
    g.columns = 5
    g.add_theme_constant_override("h_separation", 10)
    g.add_theme_constant_override("v_separation", 10)
    sc.add_child(g)
    for s in Game.SKINS:
        g.add_child(_skin_card(s))
    var info := UI.flat_panel(Color(0, 0, 0, 0.22), 20, 12)
    content.add_child(info)
    var ih := HBoxContainer.new()
    ih.add_theme_constant_override("separation", 12)
    info.add_child(ih)
    var iv := VBoxContainer.new()
    iv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    iv.add_theme_constant_override("separation", 0)
    ih.add_child(iv)
    info_name = UI.label("", 30, Color.WHITE, 8, Color(0, 0, 0, 0.35), UI.FONT_BLACK)
    iv.add_child(info_name)
    info_rarity = UI.label("", 20, Color.WHITE, 5, Color(0, 0, 0, 0.35))
    iv.add_child(info_rarity)
    info_action = HBoxContainer.new()
    info_action.add_theme_constant_override("separation", 10)
    info_action.alignment = BoxContainer.ALIGNMENT_END
    ih.add_child(info_action)
    if sel_skin == "":
        sel_skin = Game.equipped()
    _refresh_skins()

func _skin_card(s: Dictionary) -> Button:
    var id: String = s.id
    var b := Button.new()
    b.custom_minimum_size = Vector2(126, 130)
    b.focus_mode = Control.FOCUS_NONE
    b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
    var v := VBoxContainer.new()
    v.set_anchors_preset(Control.PRESET_FULL_RECT)
    v.offset_top = 4
    v.offset_bottom = -9
    v.alignment = BoxContainer.ALIGNMENT_CENTER
    v.add_theme_constant_override("separation", 0)
    v.mouse_filter = Control.MOUSE_FILTER_IGNORE
    b.add_child(v)
    var img := UI.tex_rect(load("res://assets/ui/skins/%s.png" % id), Vector2(92, 92))
    img.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    v.add_child(img)
    var nl := UI.label(Game.skin_name(id), UI.fit_size(Game.skin_name(id), UI.FONT, 15, 105.0, 8), Color.WHITE, 4, Color(0, 0, 0, 0.45))
    nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    nl.clip_text = true
    nl.custom_minimum_size = Vector2(116, 0)
    nl.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    v.add_child(nl)
    var lock := UI.tex_rect(_icon("lock"), Vector2(30, 30))
    lock.position = Vector2(90, 6)
    lock.size = Vector2(30, 30)
    b.add_child(lock)
    var chk := UI.tex_rect(_icon("check"), Vector2(32, 32))
    chk.position = Vector2(88, 5)
    chk.size = Vector2(32, 32)
    b.add_child(chk)
    var nb := PanelContainer.new()
    nb.add_theme_stylebox_override("panel", UI.sb(UI.GOLD, 9, 0, Color(0, 0, 0, 0), Vector4(6, 1, 6, 2)))
    nb.mouse_filter = Control.MOUSE_FILTER_IGNORE
    nb.add_child(UI.label(Game.t("new_badge"), 13, Color("6b4a00"), 0, Color(0, 0, 0, 0), UI.FONT_BLACK))
    nb.position = Vector2(6, 6)
    b.add_child(nb)
    b.pressed.connect(func(): _select_skin(id))
    UI.juicy(b, 1.06)
    cards[id] = {"btn": b, "img": img, "lock": lock, "chk": chk, "new": nb}
    return b

func _style_card(b: Button, rc: Color, owned: bool, selected: bool) -> void:
    var bg: Color = rc.darkened(0.5) if owned else Color(0.24, 0.25, 0.38)
    var n := UI.sb(bg, 18, 6, rc.darkened(0.15) if owned else Color(0.16, 0.16, 0.27), Vector4(4, 4, 4, 4))
    if selected:
        n.border_width_left = 4
        n.border_width_right = 4
        n.border_width_top = 4
        n.border_width_bottom = 7
        n.border_color = Color.WHITE
    var h: StyleBoxFlat = n.duplicate()
    h.bg_color = bg.lightened(0.12)
    b.add_theme_stylebox_override("normal", n)
    b.add_theme_stylebox_override("hover", h)
    b.add_theme_stylebox_override("pressed", h)
    b.add_theme_stylebox_override("hover_pressed", h)
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())

func _refresh_skins() -> void:
    for id in cards:
        var c: Dictionary = cards[id]
        var s := Game.get_skin(id)
        var owned := Game.is_owned(id)
        var rc: Color = Game.RARITY_COLORS[s.rarity]
        _style_card(c.btn, rc, owned, id == sel_skin)
        (c.img as TextureRect).modulate = Color.WHITE if owned else Color(0.42, 0.43, 0.58, 0.95)
        (c.lock as Control).visible = not owned
        (c.chk as Control).visible = owned and id == Game.equipped()
        (c.new as Control).visible = owned and not Game.data.seen.has(id)
    if not is_instance_valid(info_name):
        return
    var sk := Game.get_skin(sel_skin)
    var src: Color = Game.RARITY_COLORS[sk.rarity]
    info_name.text = Game.skin_name(sel_skin)
    info_name.label_settings.font_size = UI.fit_size(info_name.text, UI.FONT_BLACK, 30, 390.0, 14)
    info_rarity.text = Game.t(sk.rarity)
    info_rarity.label_settings.font_color = src.lightened(0.3)
    _clear(info_action)
    if not Game.is_owned(sel_skin):
        var lh := HBoxContainer.new()
        lh.add_theme_constant_override("separation", 6)
        lh.add_child(UI.tex_rect(_icon("lock"), Vector2(28, 28)))
        var ll := UI.label(Game.t("locked"), 17, Color(1, 1, 1, 0.85), 0)
        ll.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        lh.add_child(ll)
        lh.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        info_action.add_child(lh)
        var cb := UI.button(Game.t("chests"), UI.ORANGE, Vector2(170, 60), 22)
        cb.pressed.connect(func(): _set_tab.call_deferred("chests"))
        info_action.add_child(cb)
    elif sel_skin == Game.equipped():
        var eb := UI.button(Game.t("equipped"), UI.GREEN, Vector2(210, 60), 22, "")
        eb.disabled = true
        info_action.add_child(eb)
    else:
        var eb2 := UI.button(Game.t("equip"), UI.GREEN, Vector2(210, 60), 24)
        eb2.pressed.connect(func(): _equip_selected.call_deferred())
        info_action.add_child(eb2)

func _select_skin(id: String) -> void:
    if busy:
        return
    if sel_skin != id:
        sel_skin = id
        _apply_menu_skin(id)
        capy.flash()
        capy.do_hop()
        Game.sfx("whoosh", -7.0, 1.25)
        var s := Game.get_skin(id)
        FX.sparkle(self, capy.global_position + Vector3(0, 1.3, 0), Game.RARITY_COLORS[s.rarity], 12, 2.5, 0.3)
    if Game.is_owned(id) and not Game.data.seen.has(id):
        Game.data.seen.append(id)
        Game.save_game()
    _refresh_skins()

func _equip_selected() -> void:
    if not Game.is_owned(sel_skin):
        return
    Game.equip(sel_skin)
    Game.sfx("powerup", -2.0)
    capy.do_hop()
    capy.flash(Color(1.0, 0.95, 0.6))
    FX.sparkle(self, capy.global_position + Vector3(0, 1.5, 0), Color(1.0, 0.9, 0.4), 22, 3.0, 0.35)
    _refresh_skins()
    _refresh_main()

# ---------------------------------------------------------------- chests tab
func _build_chests_tab() -> void:
    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 14)
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    content.add_child(hb)
    for c in Game.CHESTS:
        hb.add_child(_chest_card(c))
    var hint := UI.label(Game.t("earn_hint"), 19, Color(1, 1, 1, 0.85), 0)
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    hint.custom_minimum_size = Vector2(640, 0)
    content.add_child(hint)

func _chest_card(c: Dictionary) -> Control:
    var id: String = c.id
    var col: Color = c.color
    var price := int(c.price)
    var p := UI.panel(col.darkened(0.5), 24, 12, 3, col.lightened(0.1))
    p.custom_minimum_size = Vector2(216, 0)
    var v := VBoxContainer.new()
    v.alignment = BoxContainer.ALIGNMENT_CENTER
    v.add_theme_constant_override("separation", 8)
    p.add_child(v)
    var holder := Control.new()
    holder.custom_minimum_size = Vector2(150, 140)
    holder.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v.add_child(holder)
    var img := UI.tex_rect(load("res://assets/ui/chests/%s.png" % id), Vector2(150, 150))
    img.size = Vector2(150, 150)
    img.position = Vector2(0, -6)
    holder.add_child(img)
    var bob := img.create_tween().set_loops()
    bob.tween_property(img, "position:y", -14.0, 0.9 + randf() * 0.3).set_trans(Tween.TRANS_SINE)
    bob.tween_property(img, "position:y", -2.0, 0.9 + randf() * 0.3).set_trans(Tween.TRANS_SINE)
    _pause_tween_when_hidden(img, bob)
    var nl := UI.label(Game.chest_name(id), 21, Color.WHITE, 6, col.darkened(0.6), UI.FONT_BLACK)
    nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    nl.custom_minimum_size = Vector2(190, 52)
    nl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    v.add_child(nl)
    var ob := UI.flat_panel(Color(0, 0, 0, 0.22), 14, 8)
    v.add_child(ob)
    var ov := VBoxContainer.new()
    ov.add_theme_constant_override("separation", 3)
    ob.add_child(ov)
    ov.add_child(UI.label(Game.t("odds"), 15, Color(1, 1, 1, 0.7), 0))
    var odds: Array = c.odds
    for i in 4:
        var r: String = Game.RARITIES[i]
        var rc: Color = Game.RARITY_COLORS[r]
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 6)
        var dot := PanelContainer.new()
        dot.add_theme_stylebox_override("panel", UI.sb(rc, 6, 0, Color(0, 0, 0, 0), Vector4(6, 6, 6, 6)))
        dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
        row.add_child(dot)
        var rl := UI.label(Game.t(r), 16, rc.lightened(0.35), 0)
        rl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        row.add_child(rl)
        row.add_child(UI.label("%d%%" % int(odds[i]), 16, Color.WHITE, 0, Color(0, 0, 0, 0), UI.FONT_BLACK))
        if int(odds[i]) <= 0:
            row.modulate = Color(1, 1, 1, 0.35)
        ov.add_child(row)
    var can := Game.coins() >= price
    var btn := Button.new()
    btn.custom_minimum_size = Vector2(186, 78)
    UI.style_button(btn, UI.GREEN if can else Color("7d80a3"), 20, 6, 20)
    var bv := VBoxContainer.new()
    bv.set_anchors_preset(Control.PRESET_FULL_RECT)
    bv.offset_bottom = -6
    bv.alignment = BoxContainer.ALIGNMENT_CENTER
    bv.add_theme_constant_override("separation", 0)
    bv.mouse_filter = Control.MOUSE_FILTER_IGNORE
    btn.add_child(bv)
    var bl := UI.label(Game.t("open"), 20, Color.WHITE, 6, Color(0, 0, 0, 0.3), UI.FONT_BLACK)
    bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    bv.add_child(bl)
    var ph := HBoxContainer.new()
    ph.alignment = BoxContainer.ALIGNMENT_CENTER
    ph.add_theme_constant_override("separation", 4)
    ph.mouse_filter = Control.MOUSE_FILTER_IGNORE
    bv.add_child(ph)
    ph.add_child(UI.tex_rect(COIN_TEX, Vector2(26, 26)))
    ph.add_child(UI.label(str(price), 22, Color("ffe27a") if can else Color(1, 1, 1, 0.85), 6, Color(0, 0, 0, 0.35), UI.FONT_BLACK))
    btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    UI.juicy(btn, 1.05, "")
    btn.pressed.connect(func(): _open_chest(id, btn))
    v.add_child(btn)
    return p

# ---------------------------------------------------------------- chest opening
func _open_chest(id: String, btn: Control = null) -> void:
    if busy:
        return
    var c := Game.get_chest(id)
    if Game.coins() < int(c.price):
        Game.sfx("error")
        _toast(Game.t("not_enough"), UI.RED, "coin")
        if btn:
            _shake_control(btn)
        return
    var res := Game.roll_chest(id)
    if res.is_empty():
        return
    busy = true
    chest_stage = 1
    Game.sfx("purchase")
    _refresh_coins()
    _fade(skins_ui, false, 0.2)
    view = "chest"
    capy_yaw = CAPY_YAW - 0.1
    var rarity: String = res.rarity
    var rc: Color = Game.RARITY_COLORS[rarity]
    var ch: Node3D = M_CHEST[id].instantiate()
    chest_node = ch
    ch.position = CHEST_POS + Vector3(0, 7.0, 0)
    ch.rotation.y = PI - 0.12
    add_child(ch)
    var lid: Node3D = ch.find_child("Lid", true, false)
    await _wait(0.25)
    Game.sfx("whoosh", -2.0, 0.8)
    var tw := create_tween()
    tw.tween_property(ch, "position", CHEST_POS, 0.5).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    await tw.finished
    Game.sfx("land", 0.0, 0.8)
    Game.sfx("bump", -4.0)
    shake = 1.0
    FX.puff(self, CHEST_POS + Vector3(0, 0.1, 0), Color(0.95, 0.92, 0.85), 14, 0.6, 2.4)
    capy.do_hop()
    var tw2 := create_tween()
    tw2.tween_property(ch, "scale", Vector3(1.25, 0.72, 1.25), 0.07)
    tw2.tween_property(ch, "scale", Vector3.ONE, 0.45).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
    await _wait(0.6)
    for i in 3:
        Game.sfx("chest_shake", -1.0, 1.0 + i * 0.1)
        var amp := 0.1 + i * 0.05
        var tw3 := create_tween()
        tw3.tween_property(ch, "rotation:z", amp, 0.06)
        tw3.tween_property(ch, "rotation:z", -amp, 0.1)
        tw3.tween_property(ch, "rotation:z", amp * 0.6, 0.08)
        tw3.tween_property(ch, "rotation:z", 0.0, 0.08)
        var tw4 := create_tween()
        tw4.tween_property(ch, "position:y", 0.22 + i * 0.1, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        tw4.tween_property(ch, "position:y", 0.0, 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
        if lid:
            var tl := create_tween()
            tl.tween_property(lid, "rotation:x", 0.22 + i * 0.06, 0.1)
            tl.tween_property(lid, "rotation:x", 0.0, 0.16)
        FX.sparkle(self, CHEST_POS + Vector3(0, 0.9, 0), rc, 5 + i * 5, 2.0 + i, 0.25)
        await _wait(0.5 + i * 0.05)
    await _wait(0.15)
    # open!
    chest_stage = 2
    Game.sfx("chest_open")
    Game.sfx("reward_big" if rarity == "epic" or rarity == "legendary" else "reward", -2.0)
    shake = 0.8
    if lid:
        var tl2 := create_tween()
        tl2.tween_property(lid, "rotation:x", 1.95, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    _chest_burst(rc, rarity)
    capy.happy = true
    await _wait(1.0)
    capy.happy = false
    _apply_menu_skin(str(res.skin))
    capy.flash(rc.lightened(0.4))
    FX.sparkle(self, capy.global_position + Vector3(0, 1.3, 0), rc, 20, 3.0, 0.35)
    chest_stage = 3
    view = "reveal"
    _show_reveal(res)

func _make_beam_tex() -> Texture2D:
    var img := Image.create(32, 128, false, Image.FORMAT_RGBA8)
    for y in 128:
        var fv := pow(float(y) / 127.0, 1.4)
        for x in 32:
            var fu := pow(maxf(0.0, 1.0 - absf(float(x) - 15.5) / 15.5), 1.7)
            img.set_pixel(x, y, Color(1, 1, 1, fu * fv))
    return ImageTexture.create_from_image(img)

func _additive_quad(tex: Texture2D, size: Vector2, col: Color, billboard: int) -> MeshInstance3D:
    var qm := QuadMesh.new()
    qm.size = size
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    m.billboard_mode = billboard
    m.albedo_texture = tex
    m.albedo_color = col
    m.disable_receive_shadows = true
    qm.material = m
    var mi := MeshInstance3D.new()
    mi.mesh = qm
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    return mi

func _chest_burst(rc: Color, rarity: String) -> void:
    var top := CHEST_POS + Vector3(0, 0.75, 0)
    var light := OmniLight3D.new()
    light.light_color = rc.lightened(0.35)
    light.omni_range = 7.0
    light.light_energy = 0.0
    light.position = top + Vector3(0, 0.4, 0.4)
    add_child(light)
    chest_fx.append(light)
    var tl := create_tween()
    tl.tween_property(light, "light_energy", 7.0, 0.12)
    tl.tween_property(light, "light_energy", 2.2, 0.9)
    if beam_tex == null:
        beam_tex = _make_beam_tex()
    var beam := _additive_quad(beam_tex, Vector2(1.5, 7.0), Color(rc.r, rc.g, rc.b, 0.85), BaseMaterial3D.BILLBOARD_FIXED_Y)
    beam.position = top + Vector3(0, 3.2, 0)
    beam.scale = Vector3(0.05, 1.0, 1.0)
    add_child(beam)
    chest_fx.append(beam)
    var tb := create_tween()
    tb.tween_property(beam, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    var glow := _additive_quad(GLOW, Vector2(3.2, 3.2), Color(rc.r, rc.g, rc.b, 0.9), BaseMaterial3D.BILLBOARD_ENABLED)
    glow.position = top + Vector3(0, 0.1, 0)
    glow.scale = Vector3.ONE * 0.2
    add_child(glow)
    chest_fx.append(glow)
    var tg := create_tween()
    tg.tween_property(glow, "scale", Vector3.ONE * 1.3, 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tg.tween_property(glow, "scale", Vector3.ONE * 0.85, 0.8).set_trans(Tween.TRANS_SINE)
    var big := rarity == "epic" or rarity == "legendary"
    FX.confetti(self, top + Vector3(0, 0.5, 0), 120 if big else 70, Vector3(1.2, 0.3, 1.2), 7.5)
    FX.sparkle(self, top, rc, 30, 4.5, 0.4)
    FX.ring(self, CHEST_POS + Vector3(0, 0.05, 0), rc, 4.0, 0.6)
    FX.burst(self, top, rc.lightened(0.3), 24, 6.0, 0.12)

func _show_reveal(res: Dictionary) -> void:
    var id: String = res.skin
    var rarity: String = res.rarity
    var rc: Color = Game.RARITY_COLORS[rarity]
    var is_new: bool = res.new
    reveal_ov = Control.new()
    _full(reveal_ov)
    reveal_ov.mouse_filter = Control.MOUSE_FILTER_STOP
    root.add_child(reveal_ov)
    var p := UI.panel(Color(0.14, 0.15, 0.3, 0.93), 30, 22, 4, rc)
    p.position = Vector2(48, 64)
    p.custom_minimum_size = Vector2(470, 0)
    reveal_ov.add_child(p)
    var v := VBoxContainer.new()
    v.alignment = BoxContainer.ALIGNMENT_CENTER
    v.add_theme_constant_override("separation", 8)
    p.add_child(v)
    if is_new:
        v.add_child(UI.title(Game.t("new_skin"), 46, Color("ffd84a")))
    else:
        v.add_child(UI.title(Game.t(rarity).to_upper(), 42, rc.lightened(0.35)))
    var stack := Control.new()
    stack.custom_minimum_size = Vector2(300, 250)
    stack.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v.add_child(stack)
    var rays := TextureRect.new()
    rays.texture = RAYS
    rays.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    rays.stretch_mode = TextureRect.STRETCH_SCALE
    rays.size = Vector2(330, 330)
    rays.position = Vector2(-15, -40)
    rays.pivot_offset = Vector2(165, 165)
    rays.modulate = Color(rc.r, rc.g, rc.b, 0.9).lightened(0.2)
    rays.mouse_filter = Control.MOUSE_FILTER_IGNORE
    stack.add_child(rays)
    var rt := rays.create_tween().set_loops()
    rt.tween_property(rays, "rotation", TAU, 9.0).from(0.0)
    var img := UI.tex_rect(load("res://assets/ui/skins/%s.png" % id), Vector2(220, 220))
    img.size = Vector2(220, 220)
    img.position = Vector2(40, 15)
    img.pivot_offset = Vector2(110, 110)
    stack.add_child(img)
    img.scale = Vector2(0.2, 0.2)
    var it := img.create_tween()
    it.tween_property(img, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    v.add_child(UI.title(Game.skin_name(id), UI.fit_size(Game.skin_name(id), UI.FONT_BLACK, 40, 405.0, 18), Color.WHITE, rc.darkened(0.55)))
    var rp := UI.flat_panel(rc, 16, 6)
    rp.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    var rpl := UI.label(Game.t(rarity).to_upper(), 20, Color.WHITE, 6, rc.darkened(0.5), UI.FONT_BLACK)
    rpl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    rp.add_child(rpl)
    v.add_child(rp)
    if not is_new:
        var dh := HBoxContainer.new()
        dh.alignment = BoxContainer.ALIGNMENT_CENTER
        dh.add_theme_constant_override("separation", 6)
        dh.add_child(UI.label(Game.t("duplicate") % int(res.refund), 22, Color("ffe27a"), 6, Color(0, 0, 0, 0.35)))
        dh.add_child(UI.tex_rect(COIN_TEX, Vector2(30, 30)))
        v.add_child(dh)
        _refresh_coins()
        Game.sfx("coin")
    v.add_child(UI.spacer(4))
    var bh := HBoxContainer.new()
    bh.alignment = BoxContainer.ALIGNMENT_CENTER
    bh.add_theme_constant_override("separation", 12)
    v.add_child(bh)
    if is_new:
        var eb := UI.button(Game.t("equip"), UI.GREEN, Vector2(200, 66), 26)
        eb.pressed.connect(func():
            Game.equip(id)
            Game.sfx("powerup", -2.0)
            _close_reveal())
        bh.add_child(eb)
    var ok := UI.button(Game.t("awesome"), UI.ORANGE, Vector2(200, 66), 26)
    ok.pressed.connect(_close_reveal)
    bh.add_child(ok)
    UI.pop_in(p)
    sel_skin = id

func _close_reveal() -> void:
    if reveal_ov == null:
        return
    UI.close_modal(reveal_ov)
    reveal_ov = null
    if is_instance_valid(chest_node):
        var ch := chest_node
        var tw := create_tween()
        tw.tween_property(ch, "scale", Vector3.ONE * 0.01, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
        tw.tween_callback(ch.queue_free)
        FX.puff(self, CHEST_POS + Vector3(0, 0.4, 0), Color(0.95, 0.92, 0.85), 12, 0.5, 2.0)
    chest_node = null
    for f in chest_fx:
        if not is_instance_valid(f):
            continue
        var n: Node3D = f
        var tf := create_tween()
        if n is OmniLight3D:
            tf.tween_property(n, "light_energy", 0.0, 0.3)
        else:
            tf.tween_property(n, "scale", Vector3(0.01, 0.01, 0.01), 0.3)
        tf.tween_callback(n.queue_free)
    chest_fx.clear()
    if capy.skin_id != Game.equipped():
        _apply_menu_skin(Game.equipped())
        capy.flash()
    busy = false
    chest_stage = 0
    view = "skins"
    capy_yaw = CAPY_YAW
    _fade(skins_ui, true)
    _set_tab(tab)
    _refresh_main()

# ================================================================ autotest
func _autotest(ret: Dictionary) -> void:
    await _wait(1.8)
    if str(ret.get("mode", "")) == "zombie" and Game.autotest == "all":
        await Game.shot("menu_return")
        print("[autotest] ALL DONE")
        get_tree().quit()
        return
    if Game.autotest == "menu1":
        await Game.shot("menu_main")
        get_tree().quit()
        return
    if Game.autotest != "all" and Game.autotest != "menu":
        return
    await Game.shot("menu_main")
    _poke_capy()
    _zombie_peek()
    await _wait(1.1)
    await Game.shot("menu_zombie")
    _open_mode("football")
    await _wait(0.8)
    await Game.shot("menu_mode")
    _close_modal()
    await _wait(0.4)
    _open_mode("zombie")
    await _wait(0.8)
    await Game.shot("menu_mode_zr")
    _close_modal()
    await _wait(0.4)
    _show_skins("skins")
    await _wait(1.5)
    _select_skin("king")
    await _wait(0.8)
    await Game.shot("menu_skins")
    _set_tab("chests")
    await _wait(0.8)
    await Game.shot("menu_chests")
    _open_chest("mystic")
    while chest_stage < 2:
        await _wait(0.1)
    await _wait(0.35)
    await Game.shot("menu_chest_open")
    while chest_stage < 3:
        await _wait(0.1)
    await _wait(1.2)
    await Game.shot("menu_chest_reveal")
    _close_reveal()
    await _wait(1.0)
    _show_main()
    await _wait(1.2)
    _open_settings()
    await _wait(0.7)
    await Game.shot("menu_settings")
    _close_modal()
    await _wait(0.4)
    _open_stats()
    await _wait(0.7)
    await Game.shot("menu_stats")
    _close_modal()
    await _wait(0.3)
    print("[autotest] menu done")
    if Game.autotest == "all":
        Game.goto(Game.SCENE_FOOTBALL)
    else:
        get_tree().quit()
