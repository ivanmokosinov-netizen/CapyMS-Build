extends Control
## Lightweight animated screen-space rays and sparkles, below the menu controls.
const GLINT := preload("res://assets/ui/menu_glint.png")
const RAY := preload("res://assets/ui/menu_ray.png")
var elapsed := 0.0
var redraw_accum := 0.0
var mobile_redraw := false
const SPARKS := [
    Vector3(540, 181, 0.0), Vector3(722, 252, 1.7), Vector3(1020, 205, 3.1),
    Vector3(1150, 152, 2.4), Vector3(815, 342, 0.9), Vector3(995, 396, 3.8),
    Vector3(612, 480, 2.9), Vector3(1180, 435, 1.2), Vector3(730, 560, 4.2),
    Vector3(1052, 535, 2.1), Vector3(494, 126, 3.6), Vector3(900, 118, 0.5)
]
func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mobile_redraw = OS.has_feature("mobile") or Game.force_touch
    visibility_changed.connect(func():
        if is_visible_in_tree():
            redraw_accum = 0.0
            queue_redraw())

func _process(delta: float) -> void:
    elapsed += delta
    if not is_visible_in_tree(): return
    if not mobile_redraw:
        queue_redraw()
        return
    # Keep the same rays and sparkles; only regenerate their canvas commands at
    # up to 30 Hz on mobile. The rest of the menu remains full frame rate.
    redraw_accum += delta
    if redraw_accum >= 1.0 / 30.0:
        redraw_accum = fmod(redraw_accum, 1.0 / 30.0)
        queue_redraw()

func _draw() -> void:
    if size.x <= 0.0 or size.y <= 0.0: return
    var sc := Vector2(size.x / 1280.0, size.y / 720.0)
    draw_set_transform(Vector2.ZERO, 0.0, sc)
    # Soft angled beams, kept translucent so they do not wash out the world.
    var breathe := 0.8 + 0.2 * sin(elapsed * 0.42)
    draw_set_transform(Vector2(795, -65), -0.42, sc)
    draw_texture_rect(RAY, Rect2(-52, 0, 104, 590), false, Color(1, 1, 1, 0.48 * breathe))
    draw_set_transform(Vector2(910, -72), -0.38, sc)
    draw_texture_rect(RAY, Rect2(-40, 0, 80, 560), false, Color(1, 1, 1, 0.32 * breathe))
    draw_set_transform(Vector2.ZERO, 0.0, sc)
    for i in SPARKS.size():
        var sp: Vector3 = SPARKS[i]
        var pulse := pow(maxf(0.0, sin(elapsed * 1.15 + sp.z)), 5.0)
        var drift := sin(elapsed * 0.40 + sp.z) * 8.0
        var radius := 9.0 + 8.0 * pulse
        var pos := Vector2(sp.x + drift, sp.y + sin(elapsed * 0.5 + sp.z) * 5.0)
        draw_texture_rect(GLINT, Rect2(pos - Vector2.ONE * radius, Vector2.ONE * radius * 2.0), false, Color(1.0, 0.94, 0.76, 0.16 + 0.64 * pulse))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
